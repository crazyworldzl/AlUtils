/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define LOG_TAG "WLScomJNI"

#include "jni.h"
#include "WLScomJNI.h"
#include<android/log.h>
#include "JNIHelp.h"
#include "android_runtime/AndroidRuntime.h"
#include "wlscom.h"
#include "queues.h"

#define TAG "jni zlmsg =" // 这个是自定义的LOG的标识
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG ,__VA_ARGS__) // 定义LOGD类型
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,TAG ,__VA_ARGS__) // 定义LOGI类型
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,TAG ,__VA_ARGS__) // 定义LOGW类型
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,TAG ,__VA_ARGS__) // 定义LOGE类型
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL,TAG ,__VA_ARGS__) // 定义LOGF类型




JNIEXPORT jint JNICALL Java_com_huaqin_wlscom_WLScom_init
  (JNIEnv *env, jobject obj)
{
   
    LOGD("   init");
    return 0;
}

/*
 * Class:     com_huaqin_wlscom_WLScom
 * Method:    postJSON
 * Signature: (Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_com_huaqin_wlscom_WLScom_postJSON
  (JNIEnv *env, jobject obj, jstring json)
{
     jstring jstr = env->NewStringUTF("hello");
    LOGD("  postJSON");
    char * rx_queues_name = "rx_queues";
    char * tx_queues_name = "tx_queue";
    DQueues dqqueues(rx_queues_name,tx_queues_name);
    WLScom wlscom(dqqueues);
    int start = wlscom.start();
    LOGD("  start=%d",start);

    char* b = wlscom.processJson(jstringToChar(env,json));
    LOGD("  backmessage=%s",b);
    return jstr;
}


char* jstringToChar(JNIEnv* env, jstring jstr) {
    char* rtn = NULL;
    jclass clsstring = env->FindClass("java/lang/String");
    jstring strencode = env->NewStringUTF("GB2312");
    jmethodID mid = env->GetMethodID(clsstring, "getBytes", "(Ljava/lang/String;)[B");
    jbyteArray barr = (jbyteArray) env->CallObjectMethod(jstr, mid, strencode);
    jsize alen = env->GetArrayLength(barr);
    jbyte* ba = env->GetByteArrayElements(barr, JNI_FALSE);
    if (alen > 0) {
        rtn = (char*) malloc(alen + 1);
        memcpy(rtn, ba, alen);
        rtn[alen] = 0;
    }
    env->ReleaseByteArrayElements(barr, ba, 0);
    return rtn;
}


