#include <stdio.h>
#include <stdarg.h>
#include "evlog.h"
#include <time.h>


EvLog::EvLog()
{
	_level = EVL_INFO;
}
EvLog::~EvLog()
{

}

EvLog& EvLog::instance()
{
	static EvLog log;
	return log;
}

void EvLog::enable_level(int level)
{
	_level = level; 
}

void EvLog::log_printf(int level, const char* log, ...)
{
	if (level >= _level)
	{
		char buffer[1024+8];
		va_list arg_ptr;
		int size;
		va_start(arg_ptr, log);
		size = vsnprintf(buffer, sizeof(buffer)-1, log, arg_ptr);
		va_end(arg_ptr);

	//process buffer, 
	//currently, just output to standard output
	fprintf(stdout, "%s", buffer);
	}
}

void EvLog::trace_uart_rx_data(const unsigned char * buffer,int buff_nb)
{
	if (_level <= EVL_INFO)
	{
		fprintf(stdout, "UART RX: %d\n", buff_nb);
		for (int i = 0; i < buff_nb && i < 16; i++)
		fprintf(stdout, "%02X ", buffer[i]);
		fprintf(stdout, "\n");
	}
}

void EvLog::trace_uart_tx_data(const unsigned char * buffer,int buff_nb)
{
	if (_level <= EVL_INFO)
	{
		fprintf(stdout, "UART TX: %d\n", buff_nb);
		for (int i = 0; i < buff_nb && i < 16; i++)
		fprintf(stdout, "%02X ", buffer[i]);
		fprintf(stdout, "\n");
	}
}
void EvLog::trace_block_data_time_name(const   char *title, const unsigned char * buffer,int buff_nb)
{
	if (_level <= EVL_INFO)
	{
		struct timespec show_time;

		clock_gettime(CLOCK_REALTIME, &show_time); 
		fprintf(stdout, "%s tv_s =%d, n_sec=%d\n",title, show_time.tv_sec, show_time.tv_nsec);
		for (int i = 0; i < buff_nb; i++)
		//for (int i = 0; i < buff_nb; i++)
		fprintf(stdout, "%02X ", buffer[i]);
		fprintf(stdout, "\n");
	}
}


void EvLog::trace_time(const   char *title)
{
	if (_level <= EVL_INFO)
	{
		struct timespec show_time;

		clock_gettime(CLOCK_REALTIME, &show_time); 
		fprintf(stdout, "%s__tv_s =%d, n_sec=%d\n",title,show_time.tv_sec, show_time.tv_nsec);
	}
}
