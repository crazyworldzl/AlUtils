#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include "aes_defs.h"
#include "aes.h"
#include "aesalgo.h"
#include "commclient.h"
#include "evlog.h"
#include "WlMessageProcess.h"

#define AES_IV_KEY_SIZE (16)

const char* key_file_path = "/persist/wiselink/wiselink_comm.token";

/* dont change */
const u32 seed[9] = { 0xA5A5A5A5, 0xB5B5B5B5, 0x32499394, 0x89234932, 0x89789373, 
			0xCD987337, 0x67781234, 0xEFDA99CD, 0x7865DDAA};
const u32 s1 = 0x0A114598; //do not change
const u32 s2 = 0x1B498732; //do not change
const u32 p1 = 0xC0682292; //do not change
const u32 p2 = 0xFE042B8D; //do not change

void GenI(u8* Iv)
{
	srand(time(NULL));
	for (int i = 0; i < 16; i++)
	{
		Iv[i] = rand() & 0xFF;
	}
}

void GetK(u8* key)
{
	u32 x1,x2,x3,x4;
	x1 = s1; x2 = p2;
	x3 = s2; x4 = p1;
	x1 += x2;
	x2 += x3;
	x3 -= x1;
	x4 -= x2;
	memcpy(key, &x1, sizeof(x1));
	memcpy(key+4, &x2, sizeof(x2));
	memcpy(key+8, &x3, sizeof(x3));
	memcpy(key+12, &x4, sizeof(x4));
}


u32 calc_cs32(u8* data, int len)
{
	u32 sum = 0;
	for (int i = 0; i < len; i++)
	{
		sum += data[i];
	}
	return sum;
}


#if 0
void SaveKeys(u8* keys)
{
	u8 iv[16], key[16];
	u8 xorbuffer[36];
	u8 buffer[16+32+4];
	u32 cs32 = calc_cs32(keys, 32);
	GenI(iv);
	GetK(key);
	memcpy(buffer, iv, 16);
	memcpy(buffer+16, keys, 32);
	memcpy(buffer+16+32, &cs32, sizeof(cs32));	
	memcpy(xorbuffer, seed, sizeof(seed));

	aesCipherContext ctx;
	BulkCtx aesCtx = CreateAESCtx(&ctx, key, 16, TRUE);
	DoAES( aesCtx, xorbuffer, sizeof(xorbuffer), TRUE, iv);
	DeleteAESCtx(&ctx);
	
	for (int i = 0 ; i < sizeof(xorbuffer); i++)
	{
		buffer[16+i] = buffer[16+i] ^ xorbuffer[i];
	}	

	system("mkdir -p /persist/wiselink/");
	FILE* fp = fopen(key_file_path, "wb");
	if(fp){
		fwrite(buffer, sizeof(buffer), 1, fp);
		fsync(fileno(fp));
		fclose(fp);
	}
	
}

int ReadKeys(u8* keys)
{
	u8 iv[16], key[16];
	u8 xorbuffer[36];
	u8 buffer[16+32+4];
	FILE* fp = fopen(key_file_path, "rb");
	if (fp){
		fread(buffer, sizeof(buffer), 1, fp);
		fclose(fp);
		
		memcpy(iv, buffer, 16);
		GetK(key);
		memcpy(xorbuffer, seed, sizeof(seed));
		aesCipherContext ctx;
		BulkCtx aesCtx = CreateAESCtx(&ctx, key, 16, TRUE);
		DoAES( aesCtx, xorbuffer, sizeof(xorbuffer), TRUE, iv);
		DeleteAESCtx(&ctx);
		for(int i = 0 ; i < sizeof(xorbuffer); i++)
		{
			buffer[16+i] = buffer[16+i] ^ xorbuffer[i];
		} 
		u32 ocs32;
		memcpy(&ocs32, &buffer[32+16], sizeof(ocs32));
		u32 cs32 = calc_cs32(buffer+16, 32);
		if (cs32 == ocs32)
		{
			memcpy(keys, buffer+16, 32);
			return 1;
		}
	
	}
	return 0;
}

#else
#define KEY_HEX_LENGTH   64
#define KEY_LENGTH       32
void DeNibble(u8 ch, u8 * p1, u8 * p2)
{
	u8 temp = 0;

	temp = ch;
	temp >>= 4;
	temp &= 0x0f;
	if(temp >= 0 && temp <= 9){
		*p1 = '0' + temp;
	}else if(temp >= 0x0a && temp <= 0x0f){
		*p1 = 'a' + temp - 0x0a;
	}else{

	}

	
	temp = ch;
	//temp >>= 4;
	temp &= 0x0f;
	if(temp >= 0 && temp <= 9){
		*p2 = '0' + temp;
	}else if(temp >= 0x0a && temp <= 0x0f){
		*p2 = 'a' + temp - 0x0a;
	}else{

	}
}

void ConvertHex2String(u8 * in_ptr, u16 in_length, u8 * out_ptr, u16 out_length)
{	
	u16 i,j;
	
	i = 0;
	j = 0;

	
	u8 para1,para2;
	
	for(i = 0; i < in_length; i++){
		DeNibble( *(in_ptr + i), &para1, &para2);

		if(j < out_length - 1){
			out_ptr[j++] = para1;
		}else{
			out_ptr[j] = '\0';
			break;
		}
		
		if(j < out_length - 1){
			out_ptr[j++] = para2;
		}else{
			out_ptr[j] = '\0';
			break;
		}
	}
	
	out_ptr[j] = '\0'; 
}

u8 Nibble(char ch)
{
	if (ch >= '0' && ch <= '9') return (ch - '0' );
	else if (ch >='A' && ch <= 'F') return ((ch - 'A') + 0x0A);
	else if (ch >='a' && ch <= 'f') return ((ch - 'a') + 0x0a);
	else return 0;
}
int ConvertString2Hex(const char* hexStr, u8* hexDat, int len)
{
	int count = 0;
	while (*hexStr  != 0)
	{
		 if (*(hexStr +1) != 0)
		 {
			if (count < len) 
			{
				hexDat[count++] =  (Nibble(*hexStr) << 4) + Nibble(*(hexStr+1));
				hexStr += 2;
			}
			else 
			{
				return count;
			}
		 } else {
			return 0;
		 }
	}

	return count;
}

void SaveKeys(u8* keys)
{
	char buf[KEY_LENGTH*2+1]={0};
    char aesKeySet[128]={0};
    char* pAeskeyset = aesKeySet;
    if(keys == NULL)
    {
        printf("SaveKeys keys error =NULL \n");
        return ;
    }
    
    for(int i = 0;i<KEY_LENGTH;i++)
    {
        char element = 0;
        memcpy(&element,keys+i,1);
        sprintf(buf+2*i,"%02x",element);
        //printf("SaveKeys: c=%x\n",element);
    }
    
    //printf("SaveKeys: a = %s len = %d\n",buf,strlen(buf));
    
	if(For_Wiselink_Ap == get_programmer_mode()){
		sprintf(pAeskeyset,"facparam --WL_IV_KEY %s",buf);
	}else{
		sprintf(pAeskeyset,"facparam --IB2_IV_KEY %s",buf);
	}
    printf("pAeskeyset CMD=%s\n",pAeskeyset);
    system(pAeskeyset);
	
}

int ReadKeys(u8* keys)
{
#if 1
        FILE   *stream;
        u8 readBuf[128]={0};
        const char* pbuf = (const char* )readBuf;
        
		if(For_Wiselink_Ap == get_programmer_mode()){
			stream = popen( "facparam --WL_IV_KEY", "r" );
		}else{
			stream = popen( "facparam --IB2_IV_KEY", "r" );
		}
		
        if(NULL == stream)
        {
            printf("popen steam == NULL\n");
            return 0;
        }
        fread(readBuf, sizeof(char),KEY_HEX_LENGTH,stream);
        pclose(stream);
        
        //printf("ReadKeys Key=%s,len=%d\n",readBuf,strlen(pbuf));
        if (strlen(pbuf) < KEY_HEX_LENGTH)
        {
            //printf("ReadKeys len < %d byte\n",KEY_HEX_LENGTH);
            return 0;
        }
        for(int i=0;i<KEY_HEX_LENGTH;i++)
        {
            if(('0'<=readBuf[i]&&readBuf[i]<='9')||('a'<=readBuf[i]&&readBuf[i]<='f')||('A'<=readBuf[i]&&readBuf[i]<='F'))
            {continue;}
            else
            {
                return 0;
            }
        }
        
        //if (strlen(pbuf) == KEY_HEX_LENGTH)
        //{
            ConvertString2Hex((const char *)readBuf,keys,KEY_LENGTH);
            //printf("return 1 \n");
            return 1;
        //}
    #else
        return 0;
	#endif

}

#endif
void Do_AES_OFB(u8* data, int length, u8* pKey, u8* pIV)// encrypt==decrypt
{
    aesCipherContext ctx_aes128={0};
	uint8_t *input;
	uint8_t *outBuffer;
    sbyte4  i, numBlocks;
    ubyte4  block[AES_BLOCK_SIZE/4];  /* use a ubyte4[] for alignment */
	sbyte4 inputLen;
	uint8_t IV_instance[AES_IV_KEY_SIZE];// Xiao note IV need variable 
	memcpy(IV_instance,pIV,AES_IV_KEY_SIZE);
    ctx_aes128.keyLen = 128;
    ctx_aes128.encrypt = FALSE;
    ctx_aes128.mode = MODE_OFB;
	ctx_aes128.Nr = aesKeySetupEnc(ctx_aes128.rk, pKey, 128);
    inputLen=length*8;
    numBlocks = (inputLen+127)/128;// Xiao update to support ERR_AES_BAD_LENGTH
	input=data;
	outBuffer=data;
	{
		sbyte4 j;
		ubyte *tmpBlock = (ubyte *) block;
		for (i = numBlocks; i > 0; i--) {
			aesEncrypt(ctx_aes128.rk, ctx_aes128.Nr, IV_instance, tmpBlock);
			memcpy(IV_instance, tmpBlock, AES_BLOCK_SIZE);
			for (j = 0; j< AES_BLOCK_SIZE; j++) {
				outBuffer[j] = input[j] ^ tmpBlock[j];
				if(--length == 0)break;
			}
			outBuffer += AES_BLOCK_SIZE;
			input += AES_BLOCK_SIZE;
		}
	}
}


int WBB_AP_reset_black_box(DQueues& queues)
{
	//stm32 boot0 pin set
	system("echo out >/dev/wiselink/gpio-boot/direction");
	system("echo 0 >/dev/wiselink/gpio-boot/value");

	//reset
	system("echo out >/dev/wiselink/gpio-reset/direction");
    system("echo 1 >/dev/wiselink/gpio-reset/value");
    usleep(20*1000); 	//20ms wait
	system("echo 0 >/dev/wiselink/gpio-reset/value");
	usleep(20*1000); 	//20ms wait
	
	system("echo 1 >/dev/wiselink/gpio-reset/value");
	usleep(1000*200); 	//wait 200ms for stability

	return 1;
}

int IB2_reset_black_box(DQueues& queues)
{
	//stm32 boot0 pin set
	system("echo out >/dev/co-processor/gpio-boot/direction");
	system("echo 0 >/dev/co-processor/gpio-boot/value");

	//reset
	system("echo out >/dev/co-processor/gpio-reset/direction");
       system("echo 1 >/dev/co-processor/gpio-reset/value");
       usleep(20*1000); 	//20ms wait
	system("echo 0 >/dev/co-processor/gpio-reset/value");
	usleep(20*1000); 	//20ms wait
	
	system("echo 1 >/dev/co-processor/gpio-reset/value");
	usleep(1000*200); 	//wait 200ms for stability

	return 1;
}

int reset_to_bootloader(DQueues& queues, type_run_mode mode)
{
	int ret = 0;
	if (mode == For_Wiselink_Ap)
	{
		ret = WBB_AP_reset_black_box(queues);
		EvLog::instance().log_printf(EVL_INFO, "reset to wiselink bootloader\r\n");
	}
	else
	{
		set_ib2_reset_status(IB2_RESET_STATUS);
		ret = IB2_reset_black_box(queues);
		EvLog::instance().log_printf(EVL_INFO, "reset to ib2 bootloader\r\n");
		set_ib2_reset_status(IB2_NORMAL_STATUS);
	}

	return ret;
}

int reset_to_application(DQueues& queues, type_run_mode mode)
{
	reset_to_bootloader(queues, mode);
	
	if (mode == For_Wiselink_Ap)
	{
		EvLog::instance().log_printf(EVL_INFO, "run to wiselink app\r\n");
	}
	else
	{
		EvLog::instance().log_printf(EVL_INFO, "run to ib2 app\r\n");
	}

	/* start application code */
	REQ_JUMP2APP_MSG msg;
	msg.msg_id = E_DBGP_APP_SET_BOOT_START_APPLICATION;
	queues.put_tx_msg((const unsigned char*)&msg, sizeof(msg), FLG_DONT_ACK);
	usleep(1000*200); //200ms wait
	
	return 1;
}

