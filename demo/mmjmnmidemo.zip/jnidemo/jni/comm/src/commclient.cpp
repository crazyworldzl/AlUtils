#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <termio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <pthread.h>
#include <string.h>
#include "globdef.h"
#include "commclient.h"
#include "evlog.h" 
#include "queues.h"
#include "utils.h"
#include "WlMessageProcess.h"

#include <linux/types.h>
#include <linux/spi/spidev.h>
#include <sys/ioctl.h>
#include <sys/stat.h>


#define WISELINK_UART_PORT ("/dev/wiselink/uart")
#define CO_PRO_GPIO_IRQ_VALUE ("/dev/co-processor/gpio-irq/value")
#define SPI_INT_DEV_NAME ("/dev/uio0")


#define AES_IV_KEY_SIZE (16)
#define CRC32_LENGTH 4

#define PROGRAMMER_MODE_WISELINK_AP (0x00)
#define PROGRAMMER_MODE_IB2_AP (0x01)

extern void Do_AES_OFB(u8* data, int length, u8* pKey, u8* pIV);
extern int ReadKeys(u8* keys);
static u16 const crc_table [ 256 ] =
{
    0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
    0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
    0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
    0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
    0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
    0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
    0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
    0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
    0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
    0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
    0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
    0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
    0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
    0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
    0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
    0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
    0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
    0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
    0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
    0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
    0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
    0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
    0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
    0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
    0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
    0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
    0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
    0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
    0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
    0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
    0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
    0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0
} ;

DQueues spi_dqueues(SPI_RX_QUEUE_NAME, SPI_TX_QUEUE_NAME);

static type_run_mode programmer_for = For_Wiselink_Ap;

void set_programmer_mode(type_run_mode newMode)
{
	programmer_for = newMode;
}

type_run_mode get_programmer_mode()
{
	return programmer_for;
}


static ib2_reset_status_t ib2_reset_status = IB2_NORMAL_STATUS;

void set_ib2_reset_status(ib2_reset_status_t newMode)
{
	ib2_reset_status = newMode;	
}

ib2_reset_status_t get_ib2_reset_status(void)
{
	return ib2_reset_status;
}
void common_tool_pabort(const char *s)
{
	printf("%s\n",s);
	exit(1);
}

void common_tool_print_hex(char *head, unsigned char *data, int len)
{
	int i;

	printf("%s:\n", head);
	for (i = 0; i < len; i++) {
		if (i%16 == 0 && i != 0) {
			printf("\n");
		}
		//printf("0x%.2x ", data[i]);
		printf("0x%.2x ", data[i]);
	}
	printf("\n");
}

static u16 ccitt_crc16(u8* buf, int len)
{
	u8 da = 0;
	u16 ii = 0;
	u16 crchl = 0;
	
	crchl = 0x00 ;
	for ( ii = 0x00 ; ii < len ; ii ++ )
	{
		da = ( crchl / 256 ) ;					
		crchl <<= 0x08 ;						
		crchl ^= crc_table [ da ^ buf[ii]] ;  
	}
	return crchl;
	
}

uint16 get_UINT16 ( uint8_t* buf ) //
{
    uint16 tmp16, tmp8;
    
    tmp8 = *buf++;
    tmp16 =  *buf;
    tmp16 = ( tmp16 << 8 ) + tmp8;
    return tmp16;
}
uint32 get_UINT32 ( uint8_t* buf ) //
{
    uint32 tmp32, tmpbyte;
    
    tmp32 = *buf++;
    
    tmpbyte = *buf++;
    tmp32 += ( tmpbyte << 8 ) ;
    
    tmpbyte = *buf++;
    tmp32 += ( tmpbyte << 16 ) ;
    
    tmpbyte = *buf++;
    tmp32 += ( tmpbyte << 24 ) ;
    return tmp32;
}
void set_UINT16 ( uint8_t* buf, uint16 tmp16 ) //
{
    
    *buf++ = ( tmp16 & 0x00ff );
    tmp16 >>= 8;
    *buf++ = ( tmp16 & 0x00ff );
}
void set_UINT32 ( uint8_t* buf, uint32 tmp32 ) //
{
    *buf++ = ( tmp32 & 0x000000ff );
    tmp32 >>= 8;
    *buf++ = ( tmp32 & 0x000000ff );
    tmp32 >>= 8;
    *buf++ = ( tmp32 & 0x000000ff );
    tmp32 >>= 8;
    *buf++ = ( tmp32 & 0x000000ff );
}

bool SerialPort::open(const char* node_path) ///< open the uart port for use
{
	struct termios settings = {0}; 
	if (fd >= 0) close();

	fd = ::open(node_path, O_RDWR | O_NOCTTY);
	if (fd >= 0)
	{
		tcgetattr(fd, &settings);
		settings.c_iflag &= ~(IGNBRK|BRKINT|PARMRK |ISTRIP | INLCR|IGNCR|ICRNL|IXON);
		settings.c_oflag &= ~OPOST;
		settings.c_lflag &= ~(ECHO|ECHONL|ICANON|ISIG|IEXTEN);
		settings.c_cflag &= ~(CSIZE|PARENB|CSTOPB);
		settings.c_cflag |= CS8 |CLOCAL|CREAD;
		tcsetattr(fd, TCSANOW, &settings);
		flush();
		//setIOMode(BLOCK);
	} else {
		EvLog::instance().log_printf(EVL_CRITICAL, "Open serial port %s failed (%d:%s)\n", node_path, errno, strerror(errno));
	}

	return (fd>=0);
}

bool SerialPort::close()
{
	if (fd >= 0)
		::close(fd);
	fd =-1;
	return true;
}

bool SerialPort::setBaudRate(SpBaudRate rate)
{
	struct termios settings = {0};
	speed_t baudRate = 0;
	switch (rate)
	{
	case Br9600:
		baudRate = B9600;
		break;
	case Br38400:
		baudRate = B38400;
		break;
	case Br115200:
		baudRate = B115200;
		break;
	case Br1M:
		baudRate = B1000000;
		break;
	case Br2M:
		baudRate = B2000000;
		break;
	default:
		baudRate = B115200;
		break;
	}

	return ((fd >=0) && !tcgetattr(fd, &settings)
		&& !cfsetspeed(&settings, baudRate)
		&& !tcsetattr(fd, TCSANOW, &settings));
}

bool SerialPort::setParity(SpParity parity)
{
	tcflag_t val = 0;
	struct termios settings = {0};
	switch (parity)
	{
	case Even:
		val = PARENB;
		break;
	case Odd:
		val = PARENB | PARODD;
		break;
	case NoParity:
	default:
		break;
	}

	bool ret = (fd >=0) && !tcgetattr(fd, &settings);
	settings.c_cflag &= ~(PARENB|PARODD);
	settings.c_cflag |= val;

	return ret && !tcsetattr(fd, TCSANOW, &settings);
}

bool SerialPort::setDataBits(SpDataBits bits)
{
	tcflag_t val = 0;
	struct termios settings = {0};
	if (bits == Eight_Bits) val =CS8;
	else val = CS7;

	bool ret = (fd >= 0) && !tcgetattr(fd, &settings);
	settings.c_cflag &= ~(CSIZE);
	settings.c_cflag |= val;
	return ret && !tcsetattr(fd, TCSANOW, &settings);
}

bool SerialPort::setStop(SpStop stop)
{
	return true;
}

bool SerialPort::setIOMode(SpIOMode mode)
{
	if ( fd < 0 ) return false;
	if ( mode == NONBLOCK)
		fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
	else
		fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) & (~O_NONBLOCK));

	io_mode = mode;

	return true;
}
bool SerialPort::flush()
{
	return fd >= 0 ? (!tcflush(fd, TCIFLUSH)):false;
}

int SerialPort::get_fd()
{
	return fd;
}

int SerialPort::get_read_fd() 
{
	return fd;
}
int SerialPort::get_write_fd()
{
	return fd;
}

int SerialPort::read(u8* buffer, int buff_nb)
{
	if (fd < 0)  return -1; //error
	
S_READ:
	int ret = ::read(fd, buffer, buff_nb);
	if (io_mode == BLOCK)
	{
		if (ret >= 0) return ret;
		else if (ret == -1 && errno == EINTR) goto S_READ; //try again		
		else
			return ret;
	}
	else
	{
		if (ret >= 0) return ret;
		else if (ret == -1 && (errno == EINTR || errno == EAGAIN)) return 0;
		else return ret;
	}
}

int SerialPort::write(u8* buffer, int buff_nb)
{
	if (fd < 0) return -1; //error

	int ret = ::write(fd, buffer, buff_nb);
	if (io_mode == NONBLOCK)
	{
		if (ret > 0) return ret;
		else if (ret == -1 && (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)) return 0;
		else return ret;
	}
	else 
	{
		return ret;
	}
}

//Below is design for SPI serial port
int SPISerialPort::spi_adapter_init(struct spi_param *param)
{
	int fd;
	int ret = 0;

	fd = ::open(SPI_DEV, O_RDWR);
	if (fd < 0) {
		printf("open %s error\n",SPI_DEV);
		return -1;
	}

	ret = ioctl(fd, SPI_IOC_WR_MODE32, &param->spi_mode);
	if (ret < 0) {
		printf("SPI_IOC_WR_MODE32 0x%x error\n",param->spi_mode);
		::close(fd);
		return -1;
	}
	
	ret = ioctl(fd, SPI_IOC_RD_MODE32, &param->spi_mode);
	if (ret <0) {
		printf("SPI_IOC_RD_MODE32 0x%x error\n",param->spi_mode);
		::close(fd);
		return -1;
	}

	ret = ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &param->bits);
	if (ret < 0) {
		printf("SPI_IOC_WR_BITS_PER_WORD %d error\n",param->bits);
		::close(fd);
		return -1;
	}

	ret = ioctl(fd, SPI_IOC_RD_BITS_PER_WORD, &param->bits);
	if (ret < 0) {
		printf("SPI_IOC_RD_BITS_PER_WORD %d error\n",param->bits);
		::close(fd);
		return -1;
	}

	ret = ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &param->speed);
	if (ret < 0) {
		printf("SPI_IOC_WR_MAX_SPEED_HZ %d error\n",&param->speed);
		::close(fd);
		return -1;
	}

	ret = ioctl(fd, SPI_IOC_RD_MAX_SPEED_HZ, &param->speed);
	if (ret < 0) {
		printf("SPI_IOC_RD_MAX_SPEED_HZ %d error\n",&param->speed);
		::close(fd);
		return -1;
	}

	EvLog::instance().log_printf(EVL_INFO, "\nSpi mode: 0x%04x / bits per word: %d\n", param->spi_mode,param->bits); 
	EvLog::instance().log_printf(EVL_INFO, "Max speed: %d Hz (%d MHz)\n", param->speed, (param->speed)/1000/1000); 
	EvLog::instance().log_printf(EVL_INFO, "%s success\n\n",__FUNCTION__); 

	return fd;
}

int SPISerialPort::spi_transfer_data(int fd,struct spi_param *param,char *tx,char *rx,int len)
{
	int ret;
	struct spi_ioc_transfer transfer_data; 

	memset(&transfer_data,0x00,sizeof(transfer_data));
	//memset(rx,0xc0,len);

	transfer_data.tx_buf = (unsigned long)tx;
	transfer_data.rx_buf = (unsigned long)rx;
	transfer_data.len = len;
	transfer_data.speed_hz = param->speed,
	transfer_data.bits_per_word = param->bits,

	ret = ioctl(fd, SPI_IOC_MESSAGE(1), &transfer_data);
	if(ret < 0) {
		::close(fd);
		printf("send spi message error %d\n",errno);
		return -1;
	}
	return 0;
}

SPISerialPort::SPISerialPort()
{
	spi_fd = -1;
	spi_int_fd = -1;
}

bool SPISerialPort::open(void) ///< open the uart port for use
{
	if (spi_fd >= 0)
	{
		close();
	}

	memset(&spi_adap_param, 0x00, sizeof(struct spi_param));
	spi_adap_param.bits = SPI_BITS;
	spi_adap_param.speed = SPI_SPEED;

	spi_fd = spi_adapter_init(&spi_adap_param);

	if (spi_fd < 0)
	{
		return false;
	}

	//Init SPI INT PIN
	if (spi_int_fd >= 0)
	{
		::close(spi_int_fd);
	}

	spi_int_fd = ::open(SPI_INT_DEV_NAME, O_RDWR);
	if (spi_int_fd < 0)
	{
		return false;
	}

	//enable INT irq
	uint32_t info = 1;
	ssize_t nb;
	nb = ::write(spi_int_fd, &info, sizeof(info));

	if (nb < sizeof(info))
	{
		EvLog::instance().log_printf(EVL_CRITICAL, "Failed to enable uio0 irq\n", errno, strerror(errno));
		return false;
	}

	spi_int_irq_work = true;

	int err = pthread_create(&_spi_work_thread_id, NULL, _spi_work_thread, (void*)this);
	if (err != 0)
	{
		EvLog::instance().log_printf(EVL_CRITICAL, "Create _spi_work_thread failed(%d:%s)\n", errno, strerror(errno));
		return false;
	}

	spi_work_thread_run = true;

	return true;
}

bool SPISerialPort::close()
{
	//Stop spi work thread at first
	//EvLog::instance().log_printf(EVL_INFO, "[%s]-%d\r\n", __FUNCTION__, __LINE__);
	stop_work_thread();
	
	if (spi_fd >= 0)
		::close(spi_fd);
	spi_fd =-1;

	return true;
}


void* SPISerialPort::_spi_work_thread(void * parameter)
{
	SPISerialPort* self = (SPISerialPort*) parameter;
	if (self)
		self->SPI_workloop();
	
	return NULL; /* should not enter here */
}

void SPISerialPort::stop_work_thread()
{
	if (get_work_thread_flag())
	{
		//EvLog::instance().log_printf(EVL_INFO, "[%s]-%d\r\n", __FUNCTION__, __LINE__);
		void* status;
		clear_work_thread_flag();
		pthread_join(_spi_work_thread_id, &status);
	}
}

bool SPISerialPort::get_work_thread_flag()
{
	if (spi_work_thread_run && spi_int_irq_work)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void SPISerialPort::clear_work_thread_flag()
{
	spi_work_thread_run = false;
	spi_int_irq_work = false;
}


int SPISerialPort::get_fd()
{
	return spi_fd;
}

int SPISerialPort::get_read_fd()
{
	return spi_dqueues.rx_queue_fd();
}

int SPISerialPort::get_write_fd()
{
	return spi_dqueues.tx_queue_fd();
}


int SPISerialPort::get_spi_int_fd()
{
	return spi_int_fd;
}


//SPI read and wirite API need re-design
// read from SPI private FIFO
int SPISerialPort::read(u8* buffer, int buff_nb)
{
	//Todo:
	if (spi_fd < 0)
	{
		return -1;
	}

	//get data from queue
	int len = spi_dqueues.get_rx_msg(buffer, buff_nb);

	return len;
}

// wirte
int SPISerialPort::write(u8* buffer, int buff_nb)
{
	//Todo:
	if (spi_fd < 0)
	{
		return -1;
	}

	if (spi_dqueues.put_tx_msg((const u8 *)buffer, buff_nb, FLG_DONT_ACK) == 1)
	{
		return buff_nb;
	}
	else	
	{
		return -1;
	}
}

bool SPISerialPort::check_UIO0_State(void)
{
	char value_str[2];
	int fd_io;
	//struct timespec tv1,tv2;
	//clock_gettime(CLOCK_REALTIME, &tv1); 
	fd_io = ::open(CO_PRO_GPIO_IRQ_VALUE, O_RDONLY);

	if(fd_io == -1)
	{
		//error
		EvLog::instance().log_printf(EVL_INFO, "open /dev/co-processor/gpio-irq/value error\r\n");
	}
	::read(fd_io, value_str, 1);
	::close(fd_io);
	//clock_gettime(CLOCK_REALTIME, &tv2);
	#if 0
	EvLog::instance().log_printf(EVL_INFO, " tv1_s =%d, n_sec=%d\n", tv1.tv_sec, tv1.tv_nsec);
	EvLog::instance().log_printf(EVL_INFO, " tv2_s =%d, n_sec=%d\n", tv2.tv_sec, tv2.tv_nsec);
	EvLog::instance().log_printf(EVL_INFO, " det_ns =%9d \n\n", tv2.tv_nsec- tv1.tv_nsec);
	#endif

	if (value_str[0] == '1')
	{
		return true;
	}
	else
	{
		return false;
	}
}

int spi_send_data_cnt = 0;
int SPISerialPort::spi_data_exchange(int tx_len)// return read len
{
	int ret;
	u8 * tmp_buff = NULL;
	#define MAX_TX_SIZE (64)

	int cnt = 0;

	if(tx_len==0)
	{
		tx_len = MAX_TX_SIZE;
		memset(txbuffer,CommClientCtrl::SLIP_END,tx_len);
	}

	memset(rxbuffer,0,tx_len);

	EvLog::instance().log_printf(EVL_INFO, "SPI TRX(data length %d)\r\n", tx_len);
	EvLog::instance().trace_block_data_time_name("SPI TX",txbuffer, tx_len);
	#ifdef __DEBUG__
	if (tx_len != MAX_TX_SIZE)
		fprintf(stdout, "=====(put data to SPI) _spiport.write(len: %d) =====\n", tx_len);
	#endif

	spi_send_data_cnt++;
	#ifdef __DEBUG__
	fprintf(stdout, ">>>>>>>>>>>>>>>>>>>>>>>>>spi_send_data_cnt(%d) =====\n", spi_send_data_cnt);
	for (cnt = 0; cnt < tx_len; cnt++)
	{
		fprintf(stdout, "0x%x ", txbuffer[cnt]);
	}
	#endif
	ret = spi_transfer_data(spi_fd, &spi_adap_param, (char*)txbuffer, (char*)rxbuffer, tx_len);

	EvLog::instance().log_printf(EVL_INFO, "SPI write data to queue for APP(len: %d)\r\n", tx_len);
	EvLog::instance().trace_block_data_time_name("SPI RX",rxbuffer, tx_len);
	tmp_buff = (u8*)malloc(tx_len);
	memset(tmp_buff, CommClientCtrl::SLIP_END, tx_len);
	if (memcmp(rxbuffer, tmp_buff, tx_len) == 0)
	{
		free(tmp_buff);
		tmp_buff = NULL;

		return 0;
	}

	#ifdef __DEBUG__
	fprintf(stdout, "=====(put spi data to rx msg) _spiport.read(len: %d) =====\n", tx_len);
	for (cnt = 0; cnt < tx_len; cnt++)
	{
		fprintf(stdout, "0x%x ", rxbuffer[cnt]);
	}
	#endif
	spi_dqueues.put_rx_msg(rxbuffer, tx_len);

	free(tmp_buff);
	tmp_buff = NULL;
	return 1;
}

void SPISerialPort::SPI_workloop()
{
	int retry_flg;
	struct timespec cur_t;

	struct timeval tv;
	fd_set rfds, wfds;
	int max_fd;
	int rc;
	int ret;
	
	int info;

	int uio0_fd = get_spi_int_fd();
	int tx_queue_fd = spi_dqueues.tx_queue_fd();
	max_fd = uio0_fd > tx_queue_fd? uio0_fd:tx_queue_fd;

	int len_spidata;
	int flag = 0;// no use
	int spi_action = 0;

	usleep(10*1000);//wait co-processor finish initialization

	while(spi_work_thread_run || spi_int_irq_work)
	{
		FD_ZERO(&rfds);
		FD_ZERO(&wfds);
		FD_SET(uio0_fd, &rfds);
		FD_SET(tx_queue_fd, &rfds);

		tv.tv_sec = 0;
		tv.tv_usec = 1000*10;//1000*100;

		//must enable ui0 irq at first
		info = 1;
		::write(uio0_fd, &info, sizeof(info));

		rc = select(max_fd + 1, &rfds, NULL, NULL, &tv);
		clock_gettime(CLOCK_REALTIME, &cur_t);
		//EvLog::instance().log_printf(EVL_INFO, " cur_time =%d.%6d\n", cur_t.tv_sec, cur_t.tv_nsec/1000);
		spi_action = 0;
		len_spidata = 0;

		if (rc > 0)
		{
			#if 1
			if (FD_ISSET(uio0_fd, &rfds))
			{
				EvLog::instance().log_printf(EVL_INFO, "SPI uio0_fd, &rfds\n");
				::read(uio0_fd, &info, sizeof(info));// clear uio state
				#ifdef __DEBUG__
				fprintf(stdout, "=====(uio0_fd select) =====\n");
				#endif
				spi_action |= 0x01;
			}
			#endif

			if (FD_ISSET(tx_queue_fd, &rfds))
			{
				EvLog::instance().log_printf(EVL_INFO, "SPI tx_queue_fd, &rfds\r\n");
				len_spidata = spi_dqueues.get_tx_msg(txbuffer, sizeof(txbuffer), &flag);
				EvLog::instance().log_printf(EVL_INFO, "flg_tx (%d)\r\n", len_spidata);
				EvLog::instance().trace_time("2)SPI Write#############################");
				#ifdef __DEBUG__
				fprintf(stdout, "=====(spi_dqueues select) spi write =====(%d)\n", len_spidata);
				#endif
				spi_action |= 0x02;
			}
		}

		if((IB2_NORMAL_STATUS == get_ib2_reset_status()))
		{
			if (spi_action & 0x02)
			{
				spi_data_exchange(len_spidata);
			}

			if (check_UIO0_State() || (spi_action & 0x01))
			{
				#ifdef __DEBUG__
				fprintf(stdout, "=====(gpio high)=====\n");
				#endif
				EvLog::instance().log_printf(EVL_INFO, "gpio-irq = 1\r\n");
				spi_data_exchange(0);
			}
		}

		/* check ack timeout */ 
		//check_waitack_timeout();
	}

	//EvLog::instance().log_printf(EVL_INFO, "[%s]-%d\r\n", __FUNCTION__, __LINE__);
}



//end of SPI serial port

CommClientCtrl::CommClientCtrl(DQueues& dqueues, const char* dev_path, u8 init_tx_seq, u8 Type):_dqueues(dqueues)
{	
	sent_nb = 0;
	total_send_nb = 0;
	tx_retry_n = 0;

	rx_layer3_nb = 0;
	got_sof = false;
	slip_esc_pending = false;
	last_rx_seq = 0xFF;

	
	tx_seq = init_tx_seq;
	tx_layer3_nb = 0;
	tx_layer3_data_len = 0;
	tx_queue_wait_ack = false;
	tx_dont_ack = false;
	
	ack_txing_flag = false;
	need_tx_ack_flag = false;
	need_tx_ack_seq = 0;

	wait_ack_flag = false;
	wait_ack_seq = 0;
	portType = Type;
	

	if (portType == 0x00)
	{
		setup(WISELINK_UART_PORT, 0);
	}
	else 
	{
		spi_setup();
		//_spiport._dqueues = dqueues;
	}

	InitialKeys();
	aes_key = aes_keys;
	aes_iv = &aes_keys[16];
	_work_thread_run = true;

	int err = pthread_create(&_work_thread_id, NULL, _work_thread, (void*)this);
	if (err != 0)
	{
		EvLog::instance().log_printf(EVL_CRITICAL, "Create CommClientCtrl work thread failed(%d:%s)\n", errno, strerror(errno));
	} else {
	}
}

CommClientCtrl::~CommClientCtrl()
{
	if (portType == 0x00)
	{
		_port.close();
	}
	else
	{
		//EvLog::instance().log_printf(EVL_INFO, "[%s]-%d\r\n", __FUNCTION__, __LINE__);
		_spiport.close();
	}

	//EvLog::instance().log_printf(EVL_INFO, "[%s]-%d\r\n", __FUNCTION__, __LINE__);

	stop_work_thread();
}

void CommClientCtrl::InitialKeys(void)
{
	aes_enabled = ReadKeys(aes_keys);
}


void CommClientCtrl::ResetSequence(u8 init_tx_seq, u8 init_rx_seq)
{
	last_rx_seq = init_rx_seq;
	tx_seq = init_tx_seq;	
}

bool CommClientCtrl::setup(const char* node_path, int baudRate)
{
	if ( _port.open(node_path))
	{
		_port.setIOMode(NONBLOCK);
		_port.setBaudRate(Br1M);
		_port.setParity(NoParity);
		_port.setDataBits(Eight_Bits);
		return  true;
	} else {
		EvLog::instance().log_printf(EVL_CRITICAL, "Open Serial Port(%s) failed\n", node_path);
		return false;
	}
}

bool CommClientCtrl::spi_setup()
{
	if ( _spiport.open())
	{
		return  true;
	} 
	else 
	{
		EvLog::instance().log_printf(EVL_CRITICAL, "Open SPI Port failed\n");
		return false;
	}
}

u8* CommClientCtrl::tx_layer3_process()
{
	u8* ptr = NULL;
    u32 index = 0;
    u32 crc32res;
    uint8_t IV_new[AES_IV_KEY_SIZE];// 
    uint32 i;
	u16 msg_id = 0;
	
	if ( need_tx_ack_flag )
	{
		need_tx_ack_flag = false;
		ack_txing_flag = true;	//acknowledgement in transferring
		tx_layer3_ack[0] = 'e';	//ack to received message
		tx_layer3_ack[1] = need_tx_ack_seq;
		unsigned short crc16 = ccitt_crc16(tx_layer3_ack, 2);
		tx_layer3_ack[2] = crc16&0xFF;
		tx_layer3_ack[3] = crc16>>8;
		tx_layer3_nb = 4;
		ptr = tx_layer3_ack;

		EvLog::instance().log_printf(EVL_INFO, "Start to transmit Acknowledgement to MCU\n");
	} else if (!wait_ack_flag) {
		//Todo
		int flag = 0;
		int len = _dqueues.get_tx_msg(&tx_layer3_buffer[5], sizeof(tx_layer3_buffer) - 7, &flag);
		EvLog::instance().log_printf(EVL_INFO, "APP get data from APP queue(len %d)\r\n", len);
		if (flag & FLG_NEED_ACK) 
		{
			tx_queue_wait_ack = true; //we need to acknowledge caller which initiate tx message 
			tx_dont_ack = false;
		}
		else
		{
			tx_queue_wait_ack = false; //caller which initiate tx message doesn't care about acknowledge
			if (flag & FLG_DONT_ACK)
				tx_dont_ack = true;
			else
				tx_dont_ack = false;
		}

		tx_layer3_buffer[index++] = 'M';
		tx_layer3_buffer[index++] = ++tx_seq;
		tx_layer3_buffer[index++] = len &0xFF;
		tx_layer3_buffer[index++] = (len>>8)&0xFF;

		//aes_enabled = ReadKeys(aes_keys);
			
		//fprintf(stdout, "aes_enable falg: %d.\r\n", aes_enabled);
		
		msg_id = get_UINT16(&tx_layer3_buffer[5]);
		if(msg_id == E_DBGP_APP_SET_BOARD_ENABLE_RANDOM_DATA){
			tx_layer3_buffer[index++] = 0;
			//fprintf(stdout, "E_DBGP_APP_SET_BOARD_ENABLE_RANDOM_DATA: aes_enable falg: 0.\r\n");
		}else{
			tx_layer3_buffer[index++] = aes_enabled;
			//fprintf(stdout, "aes_enable falg: %d.\r\n", aes_enabled);
		}

		if( (aes_enabled == 1) && (msg_id != E_DBGP_APP_SET_BOARD_ENABLE_RANDOM_DATA) ){
        	// crc32
        	crc32res = crc32(&tx_layer3_buffer[index], len);
        	set_UINT32(&tx_layer3_buffer[index + len], crc32res);
			
        
        	// build new IV
        	memcpy(IV_new,aes_iv,AES_IV_KEY_SIZE);
        	for(i=0;i<4;i++)
        	{
            	IV_new[i] ^= tx_layer3_buffer[i];
        	}
        	//encrypt
        	Do_AES_OFB(&tx_layer3_buffer[index],len+CRC32_LENGTH,aes_key,IV_new );
			
			index += CRC32_LENGTH;
			
			unsigned short crc16 = ccitt_crc16(tx_layer3_buffer, len + index);
			tx_layer3_buffer[len+index] = crc16&0xFF;
			index++;
			tx_layer3_buffer[len+index] = crc16 >> 8;
			index++;
			tx_layer3_nb = len + index;
			
		}else{
			
			unsigned short crc16 = ccitt_crc16(tx_layer3_buffer, len + index);
			tx_layer3_buffer[len+index] = crc16&0xFF;
			index++;
			tx_layer3_buffer[len+index] = crc16 >> 8;
			index++;
			tx_layer3_nb = len + index;

		}
		
        #if 0 
		printf("\nFrame ##### xx.\n");
		for(int i = 0; i < tx_layer3_nb; i++)
			printf("%02x ", tx_layer3_buffer[i]);
		printf("\nOK.\n");
		#endif
        
		tx_retry_n = 0;
		tx_layer3_data_len = tx_layer3_nb;
		ptr = tx_layer3_buffer;
		EvLog::instance().log_printf(EVL_INFO, "Start to transmit Message to MCU, payload len = %d\n", len);
		
	} else {
		//retransmit
		ptr = tx_layer3_buffer;
		tx_layer3_nb = tx_layer3_data_len;
	}

	return ptr;
}
void CommClientCtrl::link_pack()
{
	if (sent_nb == total_send_nb)
	{
		/* build layer3 buffer*/
		u8* ptr = tx_layer3_process();

		sent_nb = 0;
		int index = 0;
		tx_layer2_buffer[index++] = SLIP_END;

		/* build layer2 buffer */
		for (int i = 0; i < tx_layer3_nb; i++)
		{
			switch (ptr[i])
			{
			case SLIP_END:
				tx_layer2_buffer[index++] = SLIP_ESC;
				tx_layer2_buffer[index++] = SLIP_END_C;
				break;
			case SLIP_ESC:
				tx_layer2_buffer[index++] = SLIP_ESC;
				tx_layer2_buffer[index++] = SLIP_ESC_C;
				break;
			default:
				tx_layer2_buffer[index++] = ptr[i];	
				break;
			}
		}

		tx_layer2_buffer[index++] = SLIP_END;
		//Ocean Add 4 bytes SLIP_END
		tx_layer2_buffer[index++] = SLIP_END;
		tx_layer2_buffer[index++] = SLIP_END;
		tx_layer2_buffer[index++] = SLIP_END;
		tx_layer2_buffer[index++] = SLIP_END;
		total_send_nb = index;

		//EvLog::instance().log_printf(EVL_INFO, "sent_nb = %d, total_send_nb = %d, x1(0x%x, 0x%x)\n", sent_nb, total_send_nb, tx_layer2_buffer[0], tx_layer2_buffer[1]);
	}
}

void CommClientCtrl::rx_layer3_process()
{
	u16 crc16 = ccitt_crc16(rx_layer3_buffer, rx_layer3_nb - 2); //calculate check
	
    uint32 crc32inpkt, crc32result;
    uint32 i;
    uint8_t IV_new[AES_IV_KEY_SIZE];//
    uint32 index = 0;
	
	#if 0
	printf("\nFrame ##### ack xx.\n");
	for(int i = 0; i < rx_layer3_nb; i++)
		printf("%02x ", rx_layer3_buffer[i]);
	printf("\nOK.\n");
	#endif

	#if 0
	for (int i = 0; i < rx_layer3_nb - 2; i++)
		fprintf(stdout, "%02x ", rx_layer3_buffer[i]);
	EvLog::instance().log_printf(EVL_INFO, "CRC value = 0x%x\n", crc16);
	#endif
    
	//check crc
	if (rx_layer3_buffer[rx_layer3_nb - 2] != (crc16&0xFF) ||
		rx_layer3_buffer[rx_layer3_nb-1] != ((crc16>>8)&0xFF))
	{
		//bad crc, discard this message
		EvLog::instance().log_printf(EVL_ERROR, "Got message from MCU, Bad CRC!\n");
		EvLog::instance().trace_uart_rx_data(rx_layer3_buffer, rx_layer3_nb - 2);/////////////TODO
		
		return;
	}

	rx_layer3_nb -= 2; //substract 2 bytes crc

	u8 flag = rx_layer3_buffer[0];
	u8 seq = rx_layer3_buffer[1];
	
	switch (flag) //message flag
	{
	case 'm': //ACK
		if (wait_ack_flag && wait_ack_seq == seq)
		{
			EvLog::instance().log_printf(EVL_INFO, "Got Acknowledgement from MCU\n");		
			//we got acknowledgement
			wait_ack_flag = false;
			tx_retry_n = 0;
			
			//we acknowledge the caller which initiates the tx message that the message is already delivered to MCU
			if (tx_queue_wait_ack)  {
				_dqueues.ack_tx_msg(ACKED);
				tx_queue_wait_ack = false;
			}
		}
		break;
	case 'E': //data
		if (seq != last_rx_seq)
		{
			index = 5;
			
			//aes_enabled = ReadKeys(aes_keys);
			
			//fprintf(stdout, "aes_enable falg: %d.\r\n", aes_enabled);
			
			if(aes_enabled == 1){
    			// build new IV
        		memcpy(IV_new,aes_iv,AES_IV_KEY_SIZE);
        		for(i=0;i<4;i++)
        		{
            		IV_new[i] ^= rx_layer3_buffer[i];
        		}

				#if 0
				fprintf(stdout, "\r\n\r\n\r\n\r\nDecrypt data start:\r\n");

				// printf iv
				for(i=0;i<AES_IV_KEY_SIZE;i++)
					fprintf(stdout, "%02x ", *(aes_iv+i));
				fprintf(stdout, "\r\n");

				// printf iv_new
				for(i=0;i<AES_IV_KEY_SIZE;i++)
					fprintf(stdout, "%02x ", *(IV_new+i));
				fprintf(stdout, "\r\n");

				// printf key
				for(i=0;i<AES_IV_KEY_SIZE;i++)
					fprintf(stdout, "%02x ", *(aes_key+i));
				fprintf(stdout, "\r\n");
                #endif


				
		    	//OFB decode
    			Do_AES_OFB(rx_layer3_buffer+index, rx_layer3_nb-index,aes_key,IV_new);

                #if 0
				// printf decryped data
				fprintf(stdout, "print decryped data.\r\n");
				for(i=0; i<rx_layer3_nb; i++)
					fprintf(stdout, "%02x ", *(rx_layer3_buffer+i));
				fprintf(stdout, "\r\n");
                #endif

				
        
		        // check CRC32
        		crc32inpkt = get_UINT32(rx_layer3_buffer + rx_layer3_nb - CRC32_LENGTH);// CRC pend on data end
		        crc32result = crc32(rx_layer3_buffer+index, rx_layer3_nb - index - CRC32_LENGTH);
        		if(crc32inpkt != crc32result)
					EvLog::instance().log_printf(EVL_INFO, "Got Message from MCU, CRC32 error\r\n");
				else
					EvLog::instance().log_printf(EVL_INFO, "Got Message from MCU, CRC32 OK.\r\n");
				
				//put into rx queue			
				_dqueues.put_rx_msg(&rx_layer3_buffer[index], rx_layer3_nb - index - CRC32_LENGTH);
				EvLog::instance().log_printf(EVL_INFO, "Got Message from MCU, payload len=%d\n", rx_layer3_nb - index - CRC32_LENGTH);
				
			}else{
				//put into rx queue			
				_dqueues.put_rx_msg(&rx_layer3_buffer[index], rx_layer3_nb - index);
				EvLog::instance().log_printf(EVL_INFO, "Got Message from MCU, payload len=%d\n", rx_layer3_nb - index);
				
			}
			
		} 
		last_rx_seq = seq;
		need_tx_ack_flag = true;
		need_tx_ack_seq = seq;		
		break;
	case 's':
		//put into rx queue			
		_dqueues.put_rx_msg(&rx_layer3_buffer[5], rx_layer3_nb - 5);
		break;
	default:
		EvLog::instance().log_printf(EVL_ERROR, "Unsupported packet received (%s:%d)\n", __FILE__, __LINE__);
		break;
	}
}
void CommClientCtrl::link_depack(const u8* buffer, int buff_nb)
{
	int i = 0;
	if (slip_esc_pending) //continue to parse from last end,(SLIP_ESC is last character of last buffer)
	{
		slip_esc_pending = false; //clear the flag
 		if (buffer[0] == SLIP_ESC_C)
		{
				if (rx_layer3_nb >= sizeof(rx_layer3_buffer)) { got_sof = 0; rx_layer3_nb = 0; } //reset			
				else rx_layer3_buffer[rx_layer3_nb++] = SLIP_ESC;
				i++;
		} else if (buffer[0] == SLIP_END_C)
		{
				if (rx_layer3_nb >= sizeof(rx_layer3_buffer)) { got_sof = 0; rx_layer3_nb = 0; } //reset			
				else rx_layer3_buffer[rx_layer3_nb++] = SLIP_END;
				i++;
		} else {
				EvLog::instance().log_printf(EVL_ERROR, "[Depack]Illegal bytes(DB%02X) encountered\n", buffer[0]);			
		}		
	}
	
	for (; i < buff_nb; i++)
	{
		if ( buffer[i] == SLIP_END )
		{
			if (!got_sof) 
			{
				//got sof
				got_sof = 1;
				rx_layer3_nb = 0;
				
			} else
			{ 
				//got eof
				if ( rx_layer3_nb >=4 ) 
				{
					got_sof = 0; //find a package, later try to find next
					rx_layer3_process();
				}
				else
				{
					rx_layer3_nb = 0; //clear buffer;

				}
			}
		} else if (buffer[i] == SLIP_ESC)
		{
			if ((i + 1) == buff_nb)  //reach end of the buffer
			{
				slip_esc_pending = true;
			} else if (buffer[i+1] == SLIP_ESC_C)
			{
				if (rx_layer3_nb >= sizeof(rx_layer3_buffer)) { got_sof = 0; rx_layer3_nb = 0; } //reset			
				else rx_layer3_buffer[rx_layer3_nb++] = SLIP_ESC;
				i++;
			} else if (buffer[i+1] == SLIP_END_C)
			{
				if (rx_layer3_nb >= sizeof(rx_layer3_buffer)) { got_sof = 0; rx_layer3_nb = 0; } //reset			
				else rx_layer3_buffer[rx_layer3_nb++] = SLIP_END;
				i++;
			} else {
				EvLog::instance().log_printf(EVL_ERROR, "[Depack]Illegal byte(DB%02X) encountered\n", buffer[i+1]);			
			}
		} else {
			if (rx_layer3_nb >= sizeof(rx_layer3_buffer)) { got_sof = 0; rx_layer3_nb = 0; } //reset		
			else rx_layer3_buffer[rx_layer3_nb++] = buffer[i];
		}
	}
}

static unsigned int diff_time(struct timespec* start, struct timespec* end)
{
	unsigned int diff = 0;
	if (end->tv_sec == start->tv_sec)
		diff = (end->tv_nsec - start->tv_nsec)/1000000; //in millisecond
	else {
		diff = (end->tv_sec -1 - start->tv_sec)*1000;
		diff += 1000 - start->tv_nsec/1000000 + end->tv_nsec/1000000;
	}

	return diff;
}
void CommClientCtrl::check_waitack_timeout()
{
	if ( wait_ack_flag && sent_nb == total_send_nb && !need_tx_ack_flag)
	{
		struct timespec curr_time;
		clock_gettime(CLOCK_REALTIME, &curr_time);
		if (diff_time(&send_time, &curr_time) >= 200) //200, 200,
		{
			EvLog::instance().log_printf(EVL_WARNING, "Wait ack timed out at %d retries tv_sec = %d, tv_nsec=%d\n", tx_retry_n, curr_time.tv_sec, curr_time.tv_nsec);
			if (++tx_retry_n < 3)
			{
				//start to retransmit
				link_pack();
				wait_ack_flag = false;				
			}
			else {
				EvLog::instance().log_printf(EVL_ERROR, "Wait ack failed after 3 attempts, lost tx messages\n");
				//give up the message, will look for next
				wait_ack_flag = false;
				tx_retry_n = 0;
				//we acknowledge the caller which initiates the tx message that the message failed to deliver to MCU
				if (tx_queue_wait_ack)  {
					_dqueues.ack_tx_msg(NACKED); 	
					tx_queue_wait_ack = false;
				}
			}
		}
	}
}

void CommClientCtrl::rx_tx_loop()
{
	//bool loop = true;

	//Comm_work_thread_flag = true;

	while(_work_thread_run || need_tx_ack_flag || (sent_nb < total_send_nb))
	{
		struct timeval tv;
		fd_set rfds, wfds;
		int max_fd;
		int rc;
		int ret = 0;
		int dateLen = 0;

		int fd;
		int fdR, fdW;

		if (portType == 0x00)
		{
			//fd = _port.get_fd();
			fdW = _port.get_write_fd();
			fdR = _port.get_read_fd();
		}
		else
		{
			//fd = spi_dqueues.tx_queue_fd();
			fdW = _spiport.get_write_fd();
			fdR = _spiport.get_read_fd();
		}

		int tx_queue_fd = _dqueues.tx_queue_fd();
		max_fd = fdW > tx_queue_fd? fdW:tx_queue_fd;
		max_fd = max_fd > fdR? max_fd:fdR;

		FD_ZERO(&rfds);
		FD_ZERO(&wfds);

		if (_work_thread_run) 
		{
			//FD_SET(fd, &rfds);
			FD_SET(fdR, &rfds);
		}

		if (sent_nb < total_send_nb)
		{
			//FD_SET(fd, &wfds);
			FD_SET(fdW, &wfds);
		}
 		else if (need_tx_ack_flag)
		{
			FD_SET(fdW, &wfds);
			link_pack();
		}
		else if (!wait_ack_flag)
		{
			FD_SET(tx_queue_fd, &rfds);
		}
 
		tv.tv_sec = 0;
		tv.tv_usec = 1000*100; //100ms
		rc = select(max_fd + 1, &rfds, &wfds, NULL, &tv);

		if (rc > 0)
		{
			if (FD_ISSET(fdW, &wfds))
			{
				//EvLog::instance().trace_uart_tx_data(tx_layer2_buffer+sent_nb, total_send_nb - sent_nb);
				if (portType == 0x00)
				{
					ret = _port.write(tx_layer2_buffer+sent_nb, total_send_nb - sent_nb);
				}
				else
				{
					EvLog::instance().log_printf(EVL_INFO, "COMM APP write to SPI Queue fdW, &wfds(write length %d)\r\n", total_send_nb - sent_nb);
					//fprintf(stderr, "=====(app write msg to spi tx msg) _spiport.write =====(%d)\n", total_send_nb - sent_nb);
					ret = _spiport.write(tx_layer2_buffer+sent_nb, total_send_nb - sent_nb);
					//fprintf(stderr, "===== _spiport.write =====(%d)\n", total_send_nb - sent_nb);
				}
				
				sent_nb += ret;
				if (sent_nb == total_send_nb) //finish sending
				{	
					if (ack_txing_flag) 
					{
						ack_txing_flag = false;
					}
					else 
					{ 
						//if (tx_retry_n < 3) 
						if (!tx_dont_ack)
						{
							wait_ack_flag = true; 
							wait_ack_seq = tx_seq; 
							/* the data message sent, we record current time and wait ack */
							clock_gettime(CLOCK_REALTIME, &send_time); 
							//EvLog::instance().log_printf(EVL_INFO, "====== Send Done (tx_seq=%d)  tv_s =%d, n_sec=%d\n", tx_seq, send_time.tv_sec, send_time.tv_nsec);  
						}
					}
				}
			}
			else if (FD_ISSET(tx_queue_fd, &rfds))
			{
				EvLog::instance().log_printf(EVL_INFO, "COMM got message from APP tx_queue_fd, &rfds\r\n");
				link_pack();
			} 
			//Ocean else if(FD_ISSET(fdR, &rfds))
			if(FD_ISSET(fdR, &rfds))
			{
				u8 buffer[DBGP_COMM_BUF_SIZE];
				if(get_programmer_mode() == For_Wiselink_Ap)
				{//uart port
					dateLen = _port.read(buffer, sizeof(buffer));
					//EvLog::instance().trace_uart_rx_data(buffer, ret); //to make CPU usage down in streaming mode, commit it
					
				}
				else
				{//spi port
					dateLen = _spiport.read(buffer, sizeof(buffer));
					//printf("COMM fdR, &rfds\r\n");
					//EvLog::instance().trace_uart_rx_data(buffer, dateLen);
					//printf("COMM read from SPI qunue fdR, &rfds(dataLen %d)\r\n", dateLen);
					//EvLog::trace_block_data_time_name("COMM read from SPI qunue fdR, &rfds ",buffer, dateLen);
				}
				
				EvLog::instance().log_printf(EVL_INFO, "link_depack(data length: %d)\r\n", dateLen);

				if(dateLen > 0) 
				{
					
					link_depack(buffer, dateLen);
				}
				
			}
		} else if (rc == 0) /* timeout */
		{
			//do nothing
		}
		/* check ack timeout */	
		check_waitack_timeout();
	}

	//EvLog::instance().log_printf(EVL_INFO, "[%s]-%d\r\n", __FUNCTION__, __LINE__);
}

void* CommClientCtrl::_work_thread(void * parameter)
{
	CommClientCtrl* self = (CommClientCtrl*) parameter;
	if (self)
		self->rx_tx_loop();
	
	return NULL; /* should not enter here */
}

void CommClientCtrl::stop_work_thread()
{
	if (_work_thread_run)
	{
		//EvLog::instance().log_printf(EVL_INFO, "[%s]-%d\r\n", __FUNCTION__, __LINE__);
		void* status;
		_work_thread_run = false;
		pthread_join(_work_thread_id, &status);
	}
}
