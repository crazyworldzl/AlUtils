#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <time.h>
#include <errno.h>
#include "globdef.h"
#include "queues.h"
#include "evlog.h"

#define RX_QUEUE_NAME	"/wl_rx_q"
#define TX_QUEUE_NAME	"/wl_tx_q"

#define MAX_QUEUE_NAME_CNT (32)

DQueues::DQueues(char * rx_queues_name, char * tx_queues_name)
{
	nrx_queue = alloc_queue();
	if (nrx_queue == NULL)
	{
		printf("\n Error in Creating etb_queue\n");
		free_queue(nrx_queue);
		return;
	}

	ntx_queue = alloc_queue();
	if (ntx_queue == NULL)
	{
		printf("\n Error in Creating fbd_queue\n");
		free_queue(ntx_queue);
		return;
	}
	my_rx_queues_name = rx_queues_name;
	my_tx_queues_name = tx_queues_name;
	pthread_cond_init(&var, NULL);
	ack_or_nack = 0;


}

DQueues::~DQueues()
{
	if(nrx_queue) {
		free_queue(nrx_queue);
		nrx_queue = NULL;
	}
	
	if(ntx_queue)
	{
		free_queue(ntx_queue);
		ntx_queue = NULL;
	}
}

int DQueues::get_rx_msg(unsigned char* buffer, int buff_nb)
{
	DQ_MSG *msg = NULL;
	int len = 0;
	pthread_mutex_lock(&rx_lock);
	msg = (DQ_MSG *)pop(nrx_queue);
	pthread_mutex_unlock(&rx_lock);
	if(msg!=NULL)
	{
		len = msg->msg_nb;
		if (strcmp(my_rx_queues_name, "/spi_rx_q") == 0)
		{
			//fprintf(stderr, "get_rx_msg msg_nb = %d\r\n", msg->msg_nb);
		}

		if (msg->msg_nb <= buff_nb)
		{
			memcpy(buffer, msg->msg_ptr, msg->msg_nb);
			free(msg->msg_ptr);
			//return msg->msg_nb;
			return len;
		} 
		else
		{
			EvLog::instance().log_printf(EVL_WARNING, "mq_receive size over error:%d:%s %s:%d\n", errno, strerror(errno), __FILE__, __LINE__);
		}
		free(msg->msg_ptr);
	} else {
		EvLog::instance().log_printf(EVL_WARNING, "mq_receive error:%d:%s %s:%d\n", errno, strerror(errno), __FILE__, __LINE__);
	}
	return 0;
}
int DQueues::get_rx_msg_timed(unsigned char* buffer, int buff_nb, int time /* in ms */)
{
	struct timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);
	u32 i_sec = time/1000;
	u32 i_nsec = (time%1000)*1000000;
	if((ts.tv_nsec + i_nsec) >= 1000000000)
	{
		ts.tv_nsec = i_nsec + ts.tv_nsec - 1000000000;
		ts.tv_sec += (i_sec + 1);
	}
	else
	{
		ts.tv_nsec += i_nsec;
		ts.tv_sec += i_sec;
	}

	DQ_MSG *msg = NULL;
	pthread_mutex_lock(&rx_lock);
	msg = (DQ_MSG *)pop(nrx_queue);
	pthread_mutex_unlock(&rx_lock);
	if(msg!=NULL)
	{
		if (msg->msg_nb <= buff_nb)
		{
			memcpy(buffer, msg->msg_ptr, msg->msg_nb);
			free(msg->msg_ptr);
			return msg->msg_nb;
		} 
		free(msg->msg_ptr);
	} else {
		EvLog::instance().log_printf(EVL_WARNING, "mq_receive error:%d:%s %s:%d\n", errno, strerror(errno), __FILE__, __LINE__);
	}
	return 0;	
}
int DQueues::get_tx_msg(unsigned char* buffer, int buff_nb, int* flag_ptr)
{

	DQ_MSG *msg = NULL;
	pthread_mutex_lock(&tx_lock);
	msg = (DQ_MSG *)pop(ntx_queue);
	pthread_mutex_unlock(&rx_lock);
	if(msg!=NULL) 
	{
		//fprintf(stderr, "qname %s message len = %d, m1 = 0x%x\n", my_tx_queues_name, msg->msg_nb, msg->msg_ptr[0]);
		if (msg->msg_nb <= buff_nb)
		{
			memcpy(buffer, msg->msg_ptr, msg->msg_nb);
			*flag_ptr = msg->flag;
			free(msg->msg_ptr);
			return msg->msg_nb;
		} 
		free(msg->msg_ptr);
	} else {
		EvLog::instance().log_printf(EVL_ERROR, "mq_receive error:%d:%s %s:%d\n", errno, strerror(errno), __FILE__, __LINE__);
	}

	return 0;

}

int DQueues::put_rx_msg(const unsigned char* buffer, int buff_nb)
{
	DQ_MSG *msg = NULL;
	msg->flag = 0;
	msg->msg_ptr = (char*)malloc(buff_nb);
	msg->msg_nb = buff_nb;


	pthread_mutex_lock(&rx_lock);
	int ret = push(nrx_queue, (void *) msg);
	pthread_mutex_unlock(&rx_lock);

	if (msg->msg_ptr)
	{
		struct timespec ts;

		memcpy(msg->msg_ptr, buffer, buff_nb);
		clock_gettime(CLOCK_REALTIME, &ts);

		if (strcmp(my_rx_queues_name, "/spi_rx_q") == 0)
		{
			//fprintf(stderr, "put_rx_msg msg_nb = %d\r\n", msg->msg_nb);
		}

		pthread_mutex_lock(&rx_lock);
		int ret = push(nrx_queue, (void *) msg);
		pthread_mutex_unlock(&rx_lock);
		if(ret < 0)
		{	//queue is full
			EvLog::instance().log_printf(EVL_WARNING, "DQueues::(%s)put_rx_msg failed (%d:%s)\n", my_rx_queues_name,errno, strerror(errno));
			return 0;
		} else {
			//mq_send(rx_queue, (const char*)&msg, sizeof(DQ_MSG), 0);
			return 1;
		}
	}
	return 0;
}

int DQueues::put_tx_msg(const unsigned char* buffer, int buff_nb, int flag)
{
	DQ_MSG *msg = NULL;
	msg->flag = 0;
	msg->msg_ptr = (char*)malloc(buff_nb);
	if (msg->msg_ptr) memcpy(msg->msg_ptr, buffer, buff_nb);
	msg->msg_nb = buff_nb;
	msg->flag = flag;


	if (msg->msg_ptr)
	{
		struct timespec ts;
		clock_gettime(CLOCK_REALTIME, &ts);	

		pthread_mutex_lock(&tx_lock);
		int ret = push(ntx_queue, (void *) msg);
		pthread_mutex_unlock(&tx_lock);
		if(ret < 0)
		{
			//queue is full
			EvLog::instance().log_printf(EVL_WARNING, "DQueues::put_tx_msg failed (%d:%s)\n", errno, strerror(errno));		
			ret = 0;
		}
		if (ret && (flag & FLG_NEED_ACK))
		{
/*
			pthread_mutex_lock(&mtx);					
			clock_gettime(CLOCK_REALTIME, &ts); 	
			ts.tv_sec += 3; //max wait time is 3 sec
			pthread_cond_timedwait(&var, &mtx, &ts);
			if (ack_or_nack == ACKED) //acked
				ret = 1;
			else 										//nacked
				ret = 0;
			pthread_mutex_unlock(&mtx);
*/
		}
		return ret;
	}

	return 0;

}

void DQueues::ack_tx_msg(int ack)
{
	//set signal	
	pthread_mutex_lock(&mtx);
	ack_or_nack = ack;
	pthread_cond_signal(&var);
	pthread_mutex_unlock(&mtx);

}




