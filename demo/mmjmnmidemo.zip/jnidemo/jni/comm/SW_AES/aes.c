/* Version: mss_albatross_release */
/*
 * aes.c
 *
 * AES Implementation
 *
 * Copyright Mocana Corp 2006-2017. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */
/**
@file       aes.c
@brief      C Source file for NanoCrypto AES symmetric cipher functions
            in CBC, CFB, and OFB modes.

@details    This file contains the NanoCrypto functions for AES symmetric cipher
            functions in CBC (Cipher Block Chaining), CFB (Cipher FeedBack), and
            OFB (Output FeedBack) modes.

@copydoc    overview_aes_ccm

@flags
To enable any of the functions in aes.{c,h}, the following flags must \b not
be defined in moptions.h:
+ \c \__DISABLE_AES_CIPHERS__
+ \c \__AES_HARDWARE_CIPHER__

@filedoc    aes.c
*/


/*------------------------------------------------------------------*/
#include "aes_defs.h"
#include "aesalgo.h"
#include "aes.h"

#if 0

#include "../common/moptions.h"
#include "../common/mtypes.h"
#include "../common/mocana.h"
#include "../crypto/hw_accel.h"
#endif

#if !defined(__DISABLE_AES_CIPHERS__) && !defined(__AES_HARDWARE_CIPHER__)
#if 0

#include "../common/mdefs.h"
#include "../common/merrors.h"
#include "../common/mrtos.h"
#include "../common/mstdlib.h"
#include "../common/debug_console.h"
#include "../crypto/aesalgo.h"
#include "../crypto/aes.h"
#endif

#ifdef __ENABLE_MOCANA_FIPS_MODULE__
#include "../crypto/fips.h"
#endif

#if (defined(__ENABLE_MOCANA_AES_NI__) || defined(__ENABLE_MOCANA_AES_NI_RUNTIME_CHECK__))
#include "../crypto/aesalgo_intel_ni.h"
#endif

/*------------------------------------------------------------------*/

/**
@brief      Get a new AES CBC context data structure and prepare the key
            schedule.

This function creates and returns a context data structure for AES CBC
operations, and prepares the key schedule (intermediate key material). This
is the first function your application calls when performing AES operations
(encryption or decryption). Your application uses the returned structure in
subsequent DoAES functions.

<table class="moc_crypto_info">
  <tr><td>FIPS Approved</td>
      <td>@image html check-green.gif ""
          @image latex check-green.png "" width=0.25in </td></tr>
  <tr><td>Suite B Algorithm</td>
      <td>@image html x-red.gif ""
      @image latex x-red.png "" width=0.25in </td></tr>
  <tr><td>Flowchart</td>
      <td>@htmlonly <a href="images/flowchart_aes_cbc.jpg">AES-CBC</a>@endhtmlonly
          @latexonly
          {See \nameref{Flowcharts}.}
          @endlatexonly</td></tr>
</table>

The AES CBC context is an opaque data structure that holds information such as
key length, key schedule, and mode of operation. To avoid memory leaks, your
application code must call the DeleteAESCtx() function after completing
AES-CBC related operations (because the AES context is dynamically allocated by
this function during context creation).

@sa         For details about AES in CBC mode, see @ref section_overview_aes_cbc
            and @ref section_caveats_aes_cbc.

@warning    If \c NULL is returned for the context pointer, you cannot use it as
            input to any subsequent AES-CBC functions.

@ingroup    aes_cbc_functions

@flags
There are no flag dependencies to enable this function.

@inc_file   aes.h

@param  hwAc:celCtx  If a hardware acceleration flag is defined, this macro
                      expands to an additional parameter, "hwAccelDescr
                      hwAccelCtx". Otherwise, this macro resolves to nothing.
                      @todo_eng_review  But... what does the user specify? In
                      the 5.3.1 docs, we just said that this was "Reserved
                      for future use." Ditto this for all aes.{c,h} functions.

@param  keyMaterial AES key to use for encryption or decryption.
@param  keyLength   Number of bytes in AES key; valid key lengths are: 16
                      (for 128 bit key), 24 (for 192 bit key), and 32 (for
                      256 bit key).
@param encrypt      \c TRUE to prepare the key schedule for encryption;
                    \c FALSE to prepare the key schedule for decryption.

@return     \c NULL if any error; otherwise pointer to created AES context.

@funcdoc    aes.c
*/
static aesCipherContext inst_aesCipherContext;// Xiao static 
#if 1
extern BulkCtx
CreateAESCtx(aesCipherContext* ctx, ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt)
#else
extern BulkCtx
CreateAESCtx(MOC_SYM(hwAccelDescr hwAccelCtx) ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt)
#endif
{
    //aesCipherContext* ctx = NULL;

#ifdef __ENABLE_MOCANA_FIPS_MODULE__
    if (OK != getFIPS_powerupStatus(FIPS_ALGO_AES_CBC))
        return NULL;
#endif /* __ENABLE_MOCANA_FIPS_MODULE__ */

#if defined(__ENABLE_MOCANA_AES_NI__)
    /* Do a runtime sanity check */
    /* With ENABLE_MOCANA_AES_NI defined, we don't have the software option */
    if (!check_for_aes_instructions())
    	return NULL;
#endif

#if 1
    //ctx = context;//Xiao static 
	memset((ubyte *)ctx, 0x00, sizeof(aesCipherContext));
	AESALGO_makeAesKey(ctx, 8 * keyLength, keyMaterial, encrypt, MODE_CBC);
#else
    
    ctx = (aesCipherContext*) MALLOC(sizeof(aesCipherContext));

    if (NULL != ctx)
    {
        MOC_MEMSET((ubyte *)ctx, 0x00, sizeof(aesCipherContext));

        if (OK > AESALGO_makeAesKey(ctx, 8 * keyLength, keyMaterial, encrypt, MODE_CBC))
        {
            FREE(ctx);  ctx = NULL;
        }
    }
#endif

    return ctx;
}

/*------------------------------------------------------------------*/

/**
@todo_eng_review    This function's documentation was added since 5.3.1,
                    and should be reviewed for accuracy and appropriateness.

@brief      Get a new AES CFB-mode context data structure and prepare the key
            schedule.

@details    This function creates and returns a context data structure for
            AES operations (in the CFB mode) and prepares the key schedule
            (intermediate key material). This is the first function your
            application calls when performing AES CFB-mode operations
            (encryption or decryption). Your application uses the returned
            structure in subsequent DoAES functions.

@sa         For details about AES in CFB mode, see @ref section_overview_aes_cfb
            and @ref section_caveats_aes_cfb.

<table class="moc_crypto_info">
  <tr><td>FIPS Approved</td>
      <td>@image html check-green.gif ""
          @image latex check-green.png "" width=0.25in </td></tr>
  <tr><td>Suite B Algorithm</td>
      <td>@image html x-red.gif ""
      @image latex x-red.png "" width=0.25in </td></tr>
  <tr><td>Flowchart</td>
      <td>@htmlonly <a href="images/flowchart_aes_cfb.png">AES-CFB</a>@endhtmlonly
          @latexonly
          {See \nameref{Flowcharts}.}
          @endlatexonly</td></tr>
</table>

The AES CFB-mode context is an opaque data structure that holds information
such as key length, key schedule, and mode of operation. To avoid memory leaks,
your application code must call the DeleteAESCtx function after completing
AES-related CFB-mode operations (because the AES context is dynamically
allocated by this function during context creation).

@warning    If \c NULL is returned for the context pointer, you cannot use it as
            input to any subsequent AES functions.

@ingroup    aes_cbc_functions

@flags
There are no flag dependencies to enable this function.

@inc_file   aes.h

@param  hwAccelCtx  If a hardware acceleration flag is defined, this macro
                      expands to an additional parameter, "hwAccelDescr
                      hwAccelCtx". Otherwise, this macro resolves to nothing.
@param keyMaterial  AES key to use for encryption or decryption.
@param keyLength    Number of bytes in AES key; valid key lengths are:
                      16 (for 128 bit key), 24 (for 192 bit key), and 32 (for
                      256 bit key).
@param encrypt      \c TRUE to prepare the key schedule for encryption;
                      \c FALSE to prepare the key schedule for decryption.

@return     \c NULL if any error; otherwise pointer to created AES CFB-mode
            context.

@funcdoc    aes.c
*/
#if 1
extern BulkCtx
CreateAESCFBCtx(ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt)
#else
extern BulkCtx
CreateAESCFBCtx(MOC_SYM(hwAccelDescr hwAccelCtx) ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt)
#endif
{
    aesCipherContext* ctx = NULL;

#ifdef __ENABLE_MOCANA_FIPS_MODULE__
    if (OK != getFIPS_powerupStatus(FIPS_ALGO_AES_CFB))
        return NULL;
#endif /* __ENABLE_MOCANA_FIPS_MODULE__ */

#if defined(__ENABLE_MOCANA_AES_NI__)
    /* Do a runtime sanity check */
    /* With ENABLE_MOCANA_AES_NI defined, we don't have the software option */
    if (!check_for_aes_instructions())
    	return NULL;
#endif
#if 1
	ctx = &inst_aesCipherContext;
	memset((ubyte *)ctx, 0x00, sizeof(aesCipherContext));
	AESALGO_makeAesKey(ctx, 8 * keyLength, keyMaterial, encrypt, MODE_CFB128);
#else
    ctx = (aesCipherContext*) MALLOC(sizeof(aesCipherContext));

    if (NULL != ctx)
    {
        MOC_MEMSET((ubyte *)ctx, 0x00, sizeof(aesCipherContext));

        if (OK > AESALGO_makeAesKey(ctx, 8 * keyLength, keyMaterial, encrypt, MODE_CFB128))
        {
            FREE(ctx);  ctx = NULL;
        }
    }
#endif
    return ctx;
}

/*------------------------------------------------------------------*/

/**
@brief      Get a new AES OFB-mode context data structure and prepare the key
            schedule.

@details    This function creates and returns a context data structure for
            AES operations in OFB mode, and prepares the key schedule
            (intermediate key material).

<table class="moc_crypto_info">
  <tr><td>FIPS Approved</td>
      <td>@image html check-green.gif ""
          @image latex check-green.png "" width=0.25in </td></tr>
  <tr><td>Suite B Algorithm</td>
      <td>@image html x-red.gif ""
      @image latex x-red.png "" width=0.25in </td></tr>
  <tr><td>Flowchart</td>
      <td>@htmlonly <a href="images/flowchart_aes_ofb.png">AES-OFB</a>@endhtmlonly
          @latexonly
          {See \nameref{Flowcharts}.}
          @endlatexonly</td></tr>
</table>

@todo_eng_review    This function and its documentation were added since 5.3.1,
                    and should be reviewed for accuracy and appropriateness.

This is the first function your application calls when performing AES OFB-mode
operations (encryption or decryption). Your application uses the returned
structure in subsequent DoAES() function calls.

The AES OFB-mode context is an opaque data structure that holds information
such as key length, key schedule, and mode of operation. To avoid memory leaks,
your application code must call the DeleteAESCtx() function after completing
AES-related OFB-mode operations (because the AES context is dynamically
allocated by this function during context creation).

@warning    If \c NULL is returned for the context pointer, you cannot use it as
            input to any subsequent AES functions.


@ingroup    aes_cbc_functions

@flags
There are no flag dependencies to enable this function.

@inc_file   aes.h

@param  hwAccelCtx  If a hardware acceleration flag is defined, this macro
                      expands to an additional parameter, "hwAccelDescr
                      hwAccelCtx". Otherwise, this macro resolves to nothing.
@param keyMaterial  AES key to use for encryption or decryption.
@param keyLength    Number of bytes in AES key; valid key lengths are:
                      16 (for 128 bit key), 24 (for 192 bit key), and 32 (for
                      256 bit key).
@param encrypt      \c TRUE to prepare the key schedule for encryption;
                      \c FALSE to prepare the key schedule for decryption.

@return     \c NULL if any error; otherwise pointer to created AES OFB-mode
            context.

@funcdoc    aes.c
*/
#if 1
extern BulkCtx
CreateAESOFBCtx(ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt)
#else
extern BulkCtx
CreateAESOFBCtx(MOC_SYM(hwAccelDescr hwAccelCtx) ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt)
#endif
{
    aesCipherContext* ctx = NULL;

#ifdef __ENABLE_MOCANA_FIPS_MODULE__
    if (OK != getFIPS_powerupStatus(FIPS_ALGO_AES_OFB))
        return NULL;
#endif /* __ENABLE_MOCANA_FIPS_MODULE__ */

#if defined(__ENABLE_MOCANA_AES_NI__)
    /* Do a runtime sanity check */
    /* With ENABLE_MOCANA_AES_NI defined, we don't have the software option */
    if (!check_for_aes_instructions())
    	return NULL;
#endif

#if 1
		ctx = &inst_aesCipherContext;
		memset((ubyte *)ctx, 0x00, sizeof(aesCipherContext));
		AESALGO_makeAesKey(ctx, 8 * keyLength, keyMaterial, encrypt, MODE_OFB);
#else

    ctx = (aesCipherContext*) MALLOC(sizeof(aesCipherContext));

    if (NULL != ctx)
    {
        MOC_MEMSET((ubyte *)ctx, 0x00, sizeof(aesCipherContext));

        if (OK > AESALGO_makeAesKey(ctx, 8 * keyLength, keyMaterial, encrypt, MODE_OFB))
        {
            FREE(ctx);  ctx = NULL;
        }
    }
#endif
    return ctx;
}

/*------------------------------------------------------------------*/

/**
@brief      Delete AES context data structure.

@details    This function deletes an AES context previously created by
            CreateAESCtx(), CreateAESCFBCtx(), or CreateAESOFBCtx(). To avoid
            memory leaks, your application must call this function after
            completing AES-related operations for a given context.

<table class="moc_crypto_info">
  <tr><td>FIPS Approved</td>
      <td>@image html check-green.gif ""
          @image latex check-green.png "" width=0.25in </td></tr>
  <tr><td>Suite B Algorithm</td>
      <td>@image html x-red.gif ""
      @image latex x-red.png "" width=0.25in </td></tr>
  <tr><td>Flowchart</td>
      <td>@htmlonly <a href="images/flowchart_aes_cbc.jpg">AES-CBC</a>@endhtmlonly
          @latexonly
          {See \nameref{Flowcharts}.}
          @endlatexonly</td></tr>
</table>

@ingroup    aes_cbc_functions

@flags
There are no flag dependencies to enable this function.

@inc_file   aes.h

@param  hwAccelCtx  If a hardware acceleration flag is defined, this macro
                      expands to an additional parameter, "hwAccelDescr
                      hwAccelCtx". Otherwise, this macro resolves to nothing.
@param  ctx         Pointer to AES context to delete.

@return     \c OK (0) if successful; otherwise a negative number error code
            definition from merrors.h. To retrieve a string containing an
            English text error identifier corresponding to the function's
            returned error status, use the \c DISPLAY_ERROR macro.

@funcdoc    aes.c
*/
#if 1
extern MSTATUS
DeleteAESCtx(aesCipherContext* ctx)
#else
extern MSTATUS
DeleteAESCtx(MOC_SYM(hwAccelDescr hwAccelCtx) BulkCtx* ctx)
#endif
{
#ifdef __ENABLE_MOCANA_FIPS_MODULE__
   if (OK != getFIPS_powerupStatus(FIPS_ALGO_AES))
        return getFIPS_powerupStatus(FIPS_ALGO_AES);
#endif /* __ENABLE_MOCANA_FIPS_MODULE__ */
    if (ctx)
    {
#ifdef __ZEROIZE_TEST__
        int counter = 0;
        FIPS_PRINT("\nAES - Before Zeroization\n");
        for( counter = 0; counter < sizeof(aesCipherContext); counter++)
        {
            FIPS_PRINT("%02x",*((ubyte*)*ctx+counter));
        }
        FIPS_PRINT("\n");
#endif
        /* Zeroize the sensitive information before deleting the memory */
        memset((ubyte*)ctx,0x00,sizeof(aesCipherContext));//xiao
#ifdef __ZEROIZE_TEST__
        FIPS_PRINT("\nAES - After Zeroization\n");
        for( counter = 0; counter < sizeof(aesCipherContext); counter++)
        {
            FIPS_PRINT("%02x",*((ubyte*)*ctx+counter));
        }
        FIPS_PRINT("\n");
#endif
     //xiao   FREE(*ctx);
    }

    return OK;
}


/*------------------------------------------------------------------*/

/**
@brief      AES-encrypt or AES-decrypt a data buffer.

@details    This function AES-encrypts or AES-decrypts a data buffer. Before
            calling this function, your application must call CreateAESCtx(),
            CreateAESCFBCtx(), or CreateAESOFBCtx() to dynamically create a
            valid, mode-appropriate AES context.

@warning    This function destroys the submitted IV.

<table class="moc_crypto_info">
  <tr><td>FIPS Approved</td>
      <td>@image html check-green.gif ""
          @image latex check-green.png "" width=0.25in </td></tr>
  <tr><td>Suite B Algorithm</td>
      <td>@image html x-red.gif ""
      @image latex x-red.png "" width=0.25in </td></tr>
  <tr><td>Flowchart</td>
      <td>@htmlonly <a href="images/flowchart_aes_cbc.jpg">AES-CBC</a>@endhtmlonly
          @latexonly
          {See \nameref{Flowcharts}.}
          @endlatexonly</td></tr>
</table>

@ingroup    aes_cbc_functions

@flags
There are no flag dependencies to enable this function.

@inc_file   aes.h

@param  hwAccelCtx  If a hardware acceleration flag is defined, this macro
                      expands to an additional parameter, "hwAccelDescr
                      hwAccelCtx". Otherwise, this macro resolves to nothing.
@param  ctx         AES context, previously created by CreateAESCtx(),
                      CreateAESCFBCtx(), or CreateAESOFBCtx().
@param data         Data to be encrypted or decrypted.
@param dataLength   Number of bytes of data to encrypt or decrypt (\p data).
@param encrypt      \c TRUE to encrypt the data; \c FALSE to decrypt the data.
@param iv           Unique IV for the AES operation. @warning For all modes,
                      it is essential that you never reuse an IV under the
                      same key. Otherwise, you will compromise
                      confidentiality for the mode.

@return     \c OK (0) if successful; otherwise a negative number error code
            definition from merrors.h. To retrieve a string containing an
            English text error identifier corresponding to the function's
            returned error status, use the \c DISPLAY_ERROR macro.

@funcdoc    aes.c
*/
#if 1
extern MSTATUS
DoAES(BulkCtx ctx, ubyte* data, sbyte4 dataLength, sbyte4 encrypt, ubyte* iv)
#else
extern MSTATUS
DoAES(MOC_SYM(hwAccelDescr hwAccelCtx) BulkCtx ctx, ubyte* data, sbyte4 dataLength, sbyte4 encrypt, ubyte* iv)
#endif
{
    sbyte4              retLength;
    aesCipherContext*   pAesContext = (aesCipherContext *)ctx;
    MSTATUS             status = OK;

    if (NULL == pAesContext || (MODE_ECB != pAesContext->mode && NULL == iv))
    {
        status = ERR_NULL_POINTER;
        goto exit;
    }

#ifdef __ENABLE_MOCANA_FIPS_MODULE__
   if (OK != getFIPS_powerupStatus(FIPS_ALGO_AES))
        return getFIPS_powerupStatus(FIPS_ALGO_AES);

   /* Need to check specific algo enabled too */
   switch (pAesContext->mode)
   {
       case MODE_ECB:
    	   status = getFIPS_powerupStatus(FIPS_ALGO_AES_ECB);
    	   break;
       case MODE_CBC:
    	   status = getFIPS_powerupStatus(FIPS_ALGO_AES_CBC);
    	   break;
#if 0
        case MODE_CFB1:
     	   status = getFIPS_powerupStatus(FIPS_ALGO_AES_CFB);
     	   break;
#endif
        case MODE_CFB128:
     	   status = getFIPS_powerupStatus(FIPS_ALGO_AES_CFB);
     	   break;
        case MODE_OFB:
     	   status = getFIPS_powerupStatus(FIPS_ALGO_AES_OFB);
     	   break;
   }

   if (OK != status)
        return status;

#endif /* __ENABLE_MOCANA_FIPS_MODULE__ */

    if (0 != (dataLength % AES_BLOCK_SIZE))
    {
        status = ERR_AES_BAD_LENGTH;
        goto exit;
    }

    if (encrypt)
        status = AESALGO_blockEncrypt(pAesContext, iv, data, 8 * dataLength, data, &retLength);
    else
        status = AESALGO_blockDecrypt(pAesContext, iv, data, 8 * dataLength, data, &retLength);

#ifdef __ENABLE_ALL_DEBUGGING__
    if (OK > status)
        DEBUG_ERROR(DEBUG_SSL_TRANSPORT, (sbyte *)"DoAES: cipher failed, error = ", status);
#endif

exit:
    return status;
}

/*------------------------------------------------------------------*/
/**
@private
@internal
@todo_add_ask    (New in .c file since 5.3.1; labeled as "internal
                  prototypes" in aes.h)
@ingroup    aes_cbc_functions
*/
extern MSTATUS
AESALGO_makeAesKey(aesCipherContext *pAesContext, sbyte4 keyLen, const ubyte *keyMaterial,
                   sbyte4 encrypt, sbyte4 mode)
{
    MSTATUS status = OK;

    if ((NULL == pAesContext) || (NULL == keyMaterial))
    {
        status = ERR_NULL_POINTER;
        goto exit;
    }

    if ((keyLen == 128) || (keyLen == 192) || (keyLen == 256))
    {
        pAesContext->keyLen = keyLen;
    }
    else
    {
        status = ERR_AES_BAD_KEY_LENGTH;
        goto exit;
    }

    pAesContext->encrypt = encrypt;
    pAesContext->mode = mode;


    /* special case here: */
    /* For CFB or OFB decrypt, we use aesEncrypt to decrypt data. */
    if ((mode == MODE_CFB128) || (mode == MODE_CFB1) || (mode == MODE_OFB)) {
        encrypt = TRUE;
    }

    if (encrypt)
    {
        pAesContext->Nr = aesKeySetupEnc(pAesContext->rk, keyMaterial, keyLen);
    }
    else
    {
        pAesContext->Nr = aesKeySetupDec(pAesContext->rk, keyMaterial, keyLen);
    }

#if 0
    /* CFB1 code disabled currently */
    aesKeySetupEnc(pAesContext->ek, keyMaterial, keyLen);
#endif

exit:
    return status;

} /* AESALGO_makeAesKey */



#if !defined(__ENABLE_MOCANA_AES_NI__) && !defined(__ENABLE_MOCANA_AES_NI_RUNTIME_CHECK__)
/*------------------------------------------------------------------*/

/**
@private
@internal
@todo_add_ask    (New in .c file since 5.3.1; labeled as "internal
                  prototypes" in aes.h)
@ingroup    aes_cbc_functions
*/
extern MSTATUS
AESALGO_blockEncrypt(aesCipherContext *pAesContext, ubyte* iv,
                     ubyte *input, sbyte4 inputLen, ubyte *outBuffer,
                     sbyte4 *pRetLength)
{
    sbyte4  i, numBlocks;
    ubyte4  block[AES_BLOCK_SIZE/4];   /* use a ubyte4[] for alignment */
    MSTATUS status = OK;

    if ((NULL == pAesContext) || (NULL == input))
    {
        status = ERR_NULL_POINTER;
        goto exit;
    }

    if (FALSE == pAesContext->encrypt)
    {
        status = ERR_AES_BAD_OPERATION;
        goto exit;
    }

    if (0 >= inputLen)
    {
        *pRetLength = 0;
        goto exit; /* nothing to do */
    }

    numBlocks = inputLen/128;

    switch (pAesContext->mode)
    {
        case MODE_ECB:
        {
            for (i = numBlocks; i > 0; i--)
            {
                aesEncrypt(pAesContext->rk, pAesContext->Nr, input, outBuffer);
                input += AES_BLOCK_SIZE;
                outBuffer += AES_BLOCK_SIZE;
            }
            break;
        }

        case MODE_CBC:
        {
            if ((NULL == iv))
            {
                status = ERR_NULL_POINTER;
                goto exit;
            }
#if __LONG_MAX__ == __INT_MAX__
            if ( (((ubyte4)input) | ((ubyte4)iv)) & 3) /* one or both are not aligned on 4 byte boundary */
#else
                if ( (((ubyte8)input) | ((ubyte8)iv)) & 3) /* one or both are not aligned on 4 byte boundary */
#endif
                {
                    for (i = numBlocks; i > 0; i--)
                    {
                        sbyte4 j;
                        for (j = 0; j < AES_BLOCK_SIZE; ++j)
                        {
                            ((ubyte*)block)[j] = (input[j] ^ iv[j]);
                        }
                        aesEncrypt(pAesContext->rk, pAesContext->Nr, (ubyte*) block, outBuffer);
                        memcpy(iv, outBuffer, AES_BLOCK_SIZE);
                        input += AES_BLOCK_SIZE;
                        outBuffer += AES_BLOCK_SIZE;
                    }
                }
                else /* assume we can use 4 bytes ops */
                {
                    for (i = numBlocks; i > 0; i--)
                    {
                        block[0] = ((ubyte4*)input)[0] ^ ((ubyte4*)iv)[0];
                        block[1] = ((ubyte4*)input)[1] ^ ((ubyte4*)iv)[1];
                        block[2] = ((ubyte4*)input)[2] ^ ((ubyte4*)iv)[2];
                        block[3] = ((ubyte4*)input)[3] ^ ((ubyte4*)iv)[3];

                        aesEncrypt(pAesContext->rk, pAesContext->Nr, (ubyte*) block, outBuffer);
                        memcpy(iv, outBuffer, AES_BLOCK_SIZE);
                        input += AES_BLOCK_SIZE;
                        outBuffer += AES_BLOCK_SIZE;
                    }
                }
            break;
        }

#if 0
        case MODE_CFB1:
        {
            sbyte4 k, t;

            for (i = numBlocks; i > 0; i--) {
                MOC_MEMCPY(outBuffer, input, AES_BLOCK_SIZE);
                for (k = 0; k < 128; k++) {
                    aesEncrypt(pAesContext->ek, pAesContext->Nr, iv, block);
                    outBuffer[k >> 3] ^= (block[0] & 0x80U) >> (k & 7);
                    for (t = 0; t < 15; t++) {
                        iv[t] = (ubyte)((iv[t] << 1) | (iv[t + 1] >> 7));
                    }
                    iv[15] = (ubyte)((iv[15] << 1) | ((outBuffer[k >> 3] >> (7 - (k & 7))) & 1));
                }
                outBuffer += AES_BLOCK_SIZE;
                input += AES_BLOCK_SIZE;
            }
            break;
        }
#endif

        case MODE_CFB128:
        {
            sbyte4 j;
            ubyte *tmpBlock = (ubyte*) block;

            if(NULL == iv)
            {
                status = ERR_NULL_POINTER;
                goto exit;
            }

            for (i = numBlocks; i > 0; i--) {
                aesEncrypt(pAesContext->rk, pAesContext->Nr, iv, tmpBlock);
                for (j = 0; j< AES_BLOCK_SIZE; j++) {
                    iv[j] = input[j] ^ tmpBlock[j];
                }
                memcpy(outBuffer, iv, AES_BLOCK_SIZE);
                outBuffer += AES_BLOCK_SIZE;
                input += AES_BLOCK_SIZE;
            }
            break;
        }

        case MODE_OFB:
        {
            sbyte4 j;
            ubyte *tmpBlock = (ubyte *) block;

            if(NULL == iv)
            {
                status = ERR_NULL_POINTER;
                goto exit;
            }

            for (i = numBlocks; i > 0; i--) {
                aesEncrypt(pAesContext->rk, pAesContext->Nr, iv, tmpBlock);
                memcpy(iv, tmpBlock, AES_BLOCK_SIZE);
                for (j = 0; j< AES_BLOCK_SIZE; j++) {
                    outBuffer[j] = input[j] ^ tmpBlock[j];

                }
                outBuffer += AES_BLOCK_SIZE;
                input += AES_BLOCK_SIZE;
            }


            break;
        }

        default:
        {
            status = ERR_AES_BAD_CIPHER_MODE;
            goto exit;
        }
    }

    *pRetLength = (128 * numBlocks);

exit:
    return status;

} /* AESALGO_blockEncrypt */


/*------------------------------------------------------------------*/

/**
@private
@internal
@todo_add_ask    (New in .c file since 5.3.1; labeled as "internal
                  prototypes" in aes.h)
@ingroup    aes_cbc_functions
*/
extern MSTATUS
AESALGO_blockDecrypt(aesCipherContext *pAesContext, ubyte* iv,
                     ubyte *input, sbyte4 inputLen, ubyte *outBuffer,
                     sbyte4 *pRetLength)
{
    sbyte4  i, numBlocks;
    ubyte4  block[AES_BLOCK_SIZE/4];  /* use a ubyte4[] for alignment */
    MSTATUS status = OK;

    if ((NULL == pAesContext) || (NULL == input))
    {
        status = ERR_NULL_POINTER;
        goto exit;
    }

    if ((pAesContext->mode != MODE_CFB1) && (pAesContext->encrypt))
    {
        status = ERR_AES_BAD_OPERATION;
        goto exit;
    }

    if (0 >= inputLen)
    {
        *pRetLength = 0; /* nothing to do */
        goto exit;
    }

    numBlocks = inputLen/128;

    switch (pAesContext->mode)
    {
        case MODE_ECB:
        {
            for (i = numBlocks; i > 0; i--)
            {
                aesDecrypt(pAesContext->rk, pAesContext->Nr, input, outBuffer);
                input += AES_BLOCK_SIZE;
                outBuffer += AES_BLOCK_SIZE;
            }
            break;
        }

        case MODE_CBC:
        {
#if __LONG_MAX__ == __INT_MAX__
            if ( ((ubyte4) iv) & 3)
#else
                if ( ((ubyte8) iv) & 3)
#endif
                {
                    for (i = numBlocks; i > 0; i--)
                    {
                        sbyte4 j;

                        aesDecrypt(pAesContext->rk, pAesContext->Nr, input, (ubyte*)block);
                        for (j = 0; j < AES_BLOCK_SIZE; ++j)
                        {
                            ((ubyte*)block)[j] ^= iv[j];
                        }
                        memcpy(iv, input, AES_BLOCK_SIZE);
                        memcpy(outBuffer, block, AES_BLOCK_SIZE);
                        input += AES_BLOCK_SIZE;
                        outBuffer += AES_BLOCK_SIZE;
                    }
                }
                else
                {
                    for (i = numBlocks; i > 0; i--)
                    {
                        aesDecrypt(pAesContext->rk, pAesContext->Nr, input, (ubyte*) block);

                        block[0] ^= ((ubyte4*)iv)[0];
                        block[1] ^= ((ubyte4*)iv)[1];
                        block[2] ^= ((ubyte4*)iv)[2];
                        block[3] ^= ((ubyte4*)iv)[3];

                        memcpy(iv, input, AES_BLOCK_SIZE);
                        memcpy(outBuffer, block, AES_BLOCK_SIZE);
                        input += AES_BLOCK_SIZE;
                        outBuffer += AES_BLOCK_SIZE;
                    }
                }
            break;
        }

#if 0
        case MODE_CFB1:
        {
            sbyte4 k, t;

            for (i = numBlocks; i > 0; i--) {
                MOC_MEMCPY(outBuffer, input, AES_BLOCK_SIZE);
                for (k = 0; k < 128; k++) {
                    aesEncrypt(pAesContext->ek, pAesContext->Nr, iv, block);
                    for (t = 0; t < 15; t++) {
                        iv[t] = (ubyte)((iv[t] << 1) | (iv[t + 1] >> 7));
                    }
                    iv[15] = (ubyte)((iv[15] << 1) | ((input[k >> 3] >> (7 - (k & 7))) & 1));
                    outBuffer[k >> 3] ^= (block[0] & 0x80U) >> (k & 7);
                }
                outBuffer += AES_BLOCK_SIZE;
                input += AES_BLOCK_SIZE;
            }
            break;
        }
#endif
        case MODE_CFB128:
        {
            sbyte4 j;
            ubyte *tmpBlock = (ubyte *) block;

            if(NULL == iv)
            {
                status = ERR_NULL_POINTER;
                goto exit;
            }

            for (i = numBlocks; i > 0; i--) {
                aesEncrypt(pAesContext->rk, pAesContext->Nr, iv, tmpBlock);
                for (j = 0; j< AES_BLOCK_SIZE; j++) {
                    iv[j] = input[j];   /* save curr input for next iv. */
                    outBuffer[j] = input[j] ^ tmpBlock[j];
                }
                outBuffer += AES_BLOCK_SIZE;
                input += AES_BLOCK_SIZE;
            }

            break;
        }

        case MODE_OFB:
        {
            sbyte4 j;
            ubyte *tmpBlock = (ubyte *) block;

            if(NULL == iv)
            {
                status = ERR_NULL_POINTER;
                goto exit;
            }

            for (i = numBlocks; i > 0; i--) {
                aesEncrypt(pAesContext->rk, pAesContext->Nr, iv, tmpBlock);
                memcpy(iv, tmpBlock, AES_BLOCK_SIZE);
                for (j = 0; j< AES_BLOCK_SIZE; j++) {
                    outBuffer[j] = input[j] ^ tmpBlock[j];
                }
                outBuffer += AES_BLOCK_SIZE;
                input += AES_BLOCK_SIZE;
            }


            break;
        }

        default:
        {
            status = ERR_AES_BAD_OPERATION;
            break;
        }
    }

    *pRetLength = (128 * numBlocks);

exit:
    return status;

} /* AESALGO_blockDecrypt */

#endif /* (!defined(__ENABLE_MOCANA_AES_NI) */

#endif /* (!defined(__DISABLE_AES_CIPHERS__) && !defined(__AES_HARDWARE_CIPHER__)) */
