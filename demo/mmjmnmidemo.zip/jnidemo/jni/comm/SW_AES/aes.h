/* Version: mss_albatross_release */
/*
 * aes.h
 *
 * AES Implementation
 *
 * Copyright Mocana Corp 2006-2017. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */
/**
@file       aes.h

@brief      Header file for the NanoCrypto AES symmetric cipher
            functions API.
@details    Header file for the NanoCrypto AES symmetric cipher
            functions API.

For documentation for this file's functions, see aes.c.
*/



/*------------------------------------------------------------------*/

#ifndef __AES_HEADER__
#define __AES_HEADER__

#ifdef __cplusplus
extern "C" {
#endif

#define AES_MAXNR               14
#ifndef AES_BLOCK_SIZE
#define AES_BLOCK_SIZE          (16)
#endif

#define ERR_AES_BAD_KEY_LENGTH                            -7904
#define 	OK 											   0
#define ERR_NULL_POINTER                                  -6001
#define ERR_AES_BAD_LENGTH                                -7902
#define ERR_AES_BAD_OPERATION                             -7903
#define ERR_AES_BAD_CIPHER_MODE                           -7907
#define ERR_INVALID_ARG                                   -6010

    
/*  Generic Defines  */
#define MODE_ECB                1         /* Are we ciphering in ECB mode?   */
#define MODE_CBC                2         /* Are we ciphering in CBC mode?   */
#define MODE_CFB1               3         /* Are we ciphering in 1-bit CFB mode? */
#define MODE_CFB128             4         /* Are we ciphering in 128-bit CFB mode? */
#define MODE_OFB                5         /* Are we ciphering in OFB mode? */

/*------------------------------------------------------------------*/

/*  The structure for key information */
typedef struct
{
    sbyte4              encrypt;                        /* Key used for encrypting or decrypting? */
    sbyte4              mode;                           /* MODE_ECB, MODE_CBC, MODE_CFB1 or MODE_OFB */
    sbyte4              keyLen;                         /* Length of the key  */
    sbyte4              Nr;                             /* key-length-dependent number of rounds */
    ubyte4              rk[4*(AES_MAXNR + 1)];          /* key schedule */
#if 0
    /* CFB1 code disabled currently */
    ubyte4              ek[4*(AES_MAXNR + 1)];          /* CFB1 key schedule (encryption only) */
#endif
} aesCipherContext;

typedef void*               BulkCtx;//Xiao add
#define MSTATUS   int16   //Xiao add, == enum enum_errDescrValues

/*------------------------------------------------------------------*/

/* internal prototypes */
MOC_EXTERN MSTATUS AESALGO_makeAesKey(aesCipherContext *pAesContext, sbyte4 keyLen, const ubyte *keyMaterial, sbyte4 encrypt, sbyte4 mode);
MOC_EXTERN MSTATUS AESALGO_blockEncrypt(aesCipherContext *pAesContext, ubyte* iv, ubyte *input, sbyte4 inputLen, ubyte *outBuffer, sbyte4 *pRetLength);
MOC_EXTERN MSTATUS AESALGO_blockDecrypt(aesCipherContext *pAesContext, ubyte* iv, ubyte *input, sbyte4 inputLen, ubyte *outBuffer, sbyte4 *pRetLength);


/*------------------------------------------------------------------*/

/*  Function prototypes  */
#if 1 //Ocean_mark: for complier issue
MOC_EXTERN BulkCtx  CreateAESCtx(aesCipherContext* ctx, ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt);

MOC_EXTERN MSTATUS  DeleteAESCtx(aesCipherContext *ctx);

MOC_EXTERN MSTATUS  DoAES(BulkCtx ctx, ubyte* data, sbyte4 dataLength, sbyte4 encrypt, ubyte* iv);

MOC_EXTERN BulkCtx CreateAESCFBCtx(ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt);

MOC_EXTERN BulkCtx CreateAESOFBCtx(ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt);

#else
MOC_EXTERN BulkCtx  CreateAESCtx(MOC_SYM(hwAccelDescr hwAccelCtx) ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt);

MOC_EXTERN MSTATUS  DeleteAESCtx(MOC_SYM(hwAccelDescr hwAccelCtx) BulkCtx *ctx);

MOC_EXTERN MSTATUS  DoAES       (MOC_SYM(hwAccelDescr hwAccelCtx) BulkCtx ctx, ubyte* data, sbyte4 dataLength, sbyte4 encrypt, ubyte* iv);

MOC_EXTERN BulkCtx CreateAESCFBCtx(MOC_SYM(hwAccelDescr hwAccelCtx) ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt);

MOC_EXTERN BulkCtx CreateAESOFBCtx(MOC_SYM(hwAccelDescr hwAccelCtx) ubyte* keyMaterial, sbyte4 keyLength, sbyte4 encrypt);
#endif
#ifdef __cplusplus
}
#endif

#endif /* __AES_HEADER__ */

