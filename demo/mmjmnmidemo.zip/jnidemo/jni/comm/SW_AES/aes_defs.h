#ifndef __TYPEDEFS_H__
#define __TYPEDEFS_H__

#include <stdlib.h>
#include <string.h>

#include "globdef.h"


#define MOC_EXTERN 
#define TRUE 1
#define FALSE 0

#endif
