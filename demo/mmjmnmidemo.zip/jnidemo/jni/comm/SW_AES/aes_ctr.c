/* Version: mss_albatross_release */
/*
 * aes_ctr.c
 *
 * AES-CTR Implementation (RFC 3686)
 *
 * Copyright Mocana Corp 2006-2017. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */
/**
@file       aes_ctr.c
@brief      C source code for the NanoCrypto AES-CTR API.

@details    This file contains the NanoCrypto AES-CTR API functions.

@copydoc    overview_aes_ctr

@flags
There are no flag dependencies to enable the functions in this API.

@filedoc    aes_ctr.c

*/


/*------------------------------------------------------------------*/
#include "aes_defs.h"
#include "aesalgo.h"
#include "aes.h"
#include "aes_ctr.h"

#if 0

#include "../common/moptions.h"
#include "../common/mtypes.h"
#include "../common/mocana.h"
#include "../crypto/hw_accel.h"

#include "../common/mdefs.h"
#include "../common/merrors.h"
#include "../crypto/fips.h"
#include "../crypto/aes.h"
#include "../crypto/aes_ctr.h"
#endif
#if (!defined(__DISABLE_AES_CIPHERS__))

#if 0
#include "../common/mrtos.h"
#include "../common/mstdlib.h"
#include "../common/debug_console.h"
#include "../crypto/aesalgo.h"
#endif

#if (defined(__ENABLE_MOCANA_AES_NI__) || defined(__ENABLE_MOCANA_AES_NI_RUNTIME_CHECK__))
#include "../crypto/aesalgo_intel_ni.h"
#endif

/*------------------------------------------------------------------*/

/**
@private
@internal
@todo_add_ask    (In the 5.3.1 code but not documented; don't know why not)
@ingroup    aes_ctr_functions
*/
#if 1
extern MSTATUS
AESCTRInit(AES_CTR_Ctx* ctx,
            const ubyte* keyMaterial, sbyte4 keyLength,
            const ubyte initCounter[AES_BLOCK_SIZE])
#else
extern MSTATUS
AESCTRInit( MOC_SYM(hwAccelDescr hwAccelCtx) AES_CTR_Ctx* ctx,
            const ubyte* keyMaterial, sbyte4 keyLength,
            const ubyte initCounter[AES_BLOCK_SIZE])
#endif
{
#ifdef __ENABLE_MOCANA_FIPS_MODULE__
    if (OK != getFIPS_powerupStatus(FIPS_ALGO_AES_CTR))
        return getFIPS_powerupStatus(FIPS_ALGO_AES_CTR);
#endif /* __ENABLE_MOCANA_FIPS_MODULE__ */

    memset((ubyte *)ctx, 0x00, sizeof(aesCTRCipherContext));

    /* install the block */
    memcpy( ctx->u.counterBlock, initCounter, AES_BLOCK_SIZE);
    return AESALGO_makeAesKey(&ctx->ctx, 8 * keyLength, keyMaterial, 1, MODE_ECB);
}


/*------------------------------------------------------------------*/

/**
@brief      Create a new AES-CTR context data structure and prepare the key
            schedule.

@details    This function creates and returns a context data structure for AES
            operations, and prepares the key schedule (intermediate key
            material). This is the first function your application calls when
            performing AES-CTR operations (encryption or decryption). Your
            application uses the returned structure in subsequent DoAESCTR()
            function calls.

<table class="moc_crypto_info">
  <tr><td>FIPS Approved</td>
      <td>@image html check-green.gif ""
          @image latex check-green.png "" width=0.25in </td></tr>
  <tr><td>Suite B Algorithm</td>
      <td>@image html x-red.gif ""
      @image latex x-red.png "" width=0.25in </td></tr>
  <tr><td>Flowchart</td>
      <td>@htmlonly <a href="images/flowchart_aes_ctr.jpg">AES-CTR</a>@endhtmlonly
          @latexonly
          {See \nameref{Flowcharts}.}
          @endlatexonly</td></tr>
</table>

The AES-CTR context is an opaque data structure that holds information such as
key length, key schedule, counter block, and mode of operation. To avoid memory
leaks, your application code must call the DeleteAESCTRCtx function after
completing AES-related operations (because the AES-CTR context is dynamically
allocated by this function during context creation).

@warning    If \c NULL is returned for the context pointer, you cannot use it as
            input to subsequent AES function calls.

@ingroup    aes_ctr_functions

@flags
There are no flag dependencies to enable this function.

@inc_file aes_ctr.h

@param  hwAccelCtx  If a hardware acceleration flag is defined, this macro
                      expands to an additional parameter, "hwAccelDescr
                      hwAccelCtx". Otherwise, this macro resolves to nothing.
                      @todo_eng_review  But... what does the user specify? In
                      the 5.3.1 docs, we just said that this was "Reserved
                      for future use." Ditto this for all aes_ccm.{c,h}
                      functions.

@param  keyMaterial Key material plus counter block.
@param  keyLength   Number of octets for AES key plus a fixed length counter
                      block (AES_BLOCK_SIZE). Valid key lengths are:
                      AES-CTR-128(16 + 16 = 32 octets), AES-CTR-192(40
                      octets), and AES-CTR-256 (48 octets).
@param encrypt      \c TRUE to prepare the key schedule for encryption;
                      \c FALSE to prepare the key schedule for decryption.

@return     \c NULL if any error; otherwise pointer to created AES-CTR context.

@todo_eng_review    Confirm that this function appears properly in the output;
                    it's in question given the compiler-controlled declarations.

@funcdoc    aes_ctr.c
*/
extern BulkCtx
#ifdef __UCOS_DIRECT_RTOS__
CreateAESCTRCtx(MOC_SYM(hwAccelDescr hwAccelCtx) ubyte* keyMaterial,
                sbyte4 keyLength, sbyte4 encrypt)
#else
#if 1
CreateAESCTRCtx(const ubyte* keyMaterial,
                sbyte4 keyLength, sbyte4 encrypt)
#else
CreateAESCTRCtx(MOC_SYM(hwAccelDescr hwAccelCtx) const ubyte* keyMaterial,
                sbyte4 keyLength, sbyte4 encrypt)
#endif
#endif /* __UCOS_DIRECT_RTOS__ */
{

#if defined(__ENABLE_MOCANA_AES_NI__)
    /* Do a runtime sanity check */
    /* With ENABLE_MOCANA_AES_NI defined, we don't have the software option */
    if (!check_for_aes_instructions())
    	return NULL;
#endif
	static aesCTRCipherContext inst_aesCTRCipherContext;//Xiao

    aesCTRCipherContext* ctx = &inst_aesCTRCipherContext;// (aesCTRCipherContext*) MALLOC(sizeof(aesCTRCipherContext));
    //MOC_UNUSED(encrypt);

    if (NULL != ctx)
    {
        keyLength -= AES_BLOCK_SIZE;
        #if 1
        if (OK > AESCTRInit(ctx, keyMaterial,
                            keyLength, keyMaterial + keyLength))
        #else
        if (OK > AESCTRInit(MOC_SYM(hwAccelCtx) ctx, keyMaterial,
                            keyLength, keyMaterial + keyLength))
        #endif
        {
           // FREE(ctx);  
           ctx = NULL;
        }
    }
    return ctx;
}


/*------------------------------------------------------------------*/

/**
@brief      Delete AES-CTR context data structure.

@details    This function deletes an AES-CTR context previously created by
            CreateAESCTRCtx(). To avoid memory leaks, your application must
            call this function after completing AES-CTR related operations for
            a given context.

<table class="moc_crypto_info">
  <tr><td>FIPS Approved</td>
      <td>@image html check-green.gif ""
          @image latex check-green.png "" width=0.25in </td></tr>
  <tr><td>Suite B Algorithm</td>
      <td>@image html x-red.gif ""
      @image latex x-red.png "" width=0.25in </td></tr>
  <tr><td>Flowchart</td>
      <td>@htmlonly <a href="images/flowchart_aes_ctr.jpg">AES-CTR</a>@endhtmlonly
          @latexonly
          {See \nameref{Flowcharts}.}
          @endlatexonly</td></tr>
</table>

@ingroup    aes_ctr_functions

@flags
There are no flag dependencies to enable this function.

@inc_file aes_ctr.h

@param  hwAccelCtx  If a hardware acceleration flag is defined, this macro
                      expands to an additional parameter, "hwAccelDescr
                      hwAccelCtx". Otherwise, this macro resolves to nothing.
@param  ctx         Pointer to AES-CTR context to delete.

@return     \c OK (0) if successful; otherwise a negative number error code
            definition from merrors.h. To retrieve a string containing an
            English text error identifier corresponding to the function's
            returned error status, use the \c DISPLAY_ERROR macro.

@funcdoc    aes_ctr.c
*/
#if 1
extern MSTATUS
DeleteAESCTRCtx(BulkCtx* ctx)
#else
extern MSTATUS
DeleteAESCTRCtx(MOC_SYM(hwAccelDescr hwAccelCtx) BulkCtx* ctx)
#endif
{
#ifdef __ENABLE_MOCANA_FIPS_MODULE__
    if (OK != getFIPS_powerupStatus(FIPS_ALGO_AES_CTR))
        return getFIPS_powerupStatus(FIPS_ALGO_AES_CTR);
#endif /* __ENABLE_MOCANA_FIPS_MODULE__ */

    if (*ctx)
    {
#ifdef __ZEROIZE_TEST__
        int counter = 0;
        FIPS_PRINT("\nAES - Before Zeroization\n");
        for( counter = 0; counter < sizeof(aesCTRCipherContext); counter++)
        {
            FIPS_PRINT("%02x",*((ubyte*)*ctx+counter));
        }
        FIPS_PRINT("\n");
#endif
        /* Zeroize the sensitive information before deleting the memory */
        memset((ubyte*)*ctx, 0x00, sizeof(aesCTRCipherContext));

#ifdef __ZEROIZE_TEST__
        FIPS_PRINT("\nAES - After Zeroization\n");
        for( counter = 0; counter < sizeof(aesCTRCipherContext); counter++)
        {
            FIPS_PRINT("%02x",*((ubyte*)*ctx+counter));
        }
        FIPS_PRINT("\n");
#endif

        //FREE(*ctx);
        *ctx = NULL;
    }

    return OK;
}


/*------------------------------------------------------------------*/

static void
AESCTR_GetNewBlock( aesCTRCipherContext* pCtx, sbyte4 limit)
{
    sbyte4 i;
    ubyte addend;

    limit = AES_BLOCK_SIZE - limit;
    /* encrypt the current block */
    aesEncrypt(pCtx->ctx.rk, pCtx->ctx.Nr, pCtx->u.counterBlock, pCtx->encBlock);
    /* increment the block for next call -- time constant way */
    addend = 1;
    for ( i = AES_BLOCK_SIZE - 1; i >= limit; --i)
    {
        addend = (pCtx->u.counterBlock[i] += addend) ? 0 : addend;
    }
}


/*------------------------------------------------------------------*/

/**
@private
@internal
@todo_add_ask    (In the 5.3.1 code but not documented; don't know why not)
@ingroup    aes_ctr_functions
*/
#if 1
extern MSTATUS
DoAESCTREx(BulkCtx ctx, ubyte* data, sbyte4 dataLength,
         sbyte4 encrypt, ubyte* iv, sbyte4 limit)
#else
extern MSTATUS
DoAESCTREx(MOC_SYM(hwAccelDescr hwAccelCtx) BulkCtx ctx, ubyte* data, sbyte4 dataLength,
         sbyte4 encrypt, ubyte* iv, sbyte4 limit)
#endif
{
    aesCTRCipherContext*    pCtx = (aesCTRCipherContext *)ctx;
    sbyte4                  i;

    //MOC_UNUSED(encrypt);

#ifdef __ENABLE_MOCANA_FIPS_MODULE__
    if (OK != getFIPS_powerupStatus(FIPS_ALGO_AES_CTR))
        return getFIPS_powerupStatus(FIPS_ALGO_AES_CTR);
#endif /* __ENABLE_MOCANA_FIPS_MODULE__ */

    if ( AES_BLOCK_SIZE < limit || limit < 0)
    {
        return ERR_INVALID_ARG;
    }

    if (iv)
    {
        /* reset to new settings, if IV is null */
        memcpy(pCtx->u.counterBlock, iv, AES_BLOCK_SIZE);
        pCtx->offset = 0;
    }

	/* was there some bytes remaining from last call? */
	if ( pCtx->offset && dataLength > 0)
	{
		while (dataLength > 0 && pCtx->offset > 0)
		{
			*data++ ^= pCtx->encBlock[pCtx->offset];
			dataLength--;
			pCtx->offset++;
			if (AES_BLOCK_SIZE == pCtx->offset)
			{
				pCtx->offset = 0;
			}
		}
	}

	while ( dataLength >= AES_BLOCK_SIZE)
	{
#if defined(__ENABLE_MOCANA_AES_NI__) || defined(__ENABLE_MOCANA_AES_NI_RUNTIME_CHECK__)

		if (check_for_aes_instructions())
		{
			/* CTR data doesn't have to be a multiple of AES_BLOCK_SIZE     */
			/* So we are going to round up the number of blocks to handle   */
			/* the extra bytes                                              */
			/* Because the intel aesni will always encrypt an entire block  */
			/* I must encrypt into a temporary buffer so that I don't       */
			/* overrun the data buffer passed into the function             */
			/* Then I'll copy the result back into the data buffer using    */
			/* the exact dataLength                                         */

			/* Find the max number of blocks by rounding up */
			ubyte4 numBlocks = (dataLength+(AES_BLOCK_SIZE-1))/AES_BLOCK_SIZE;
			/* if the dataLength is a multiple of AES_BLOCK_SIZE      */
			/* then the intel aesni can process all of data           */
			/* But if there are some bytes left over, then those      */
			/* will have to be processed with the software version    */
			if (dataLength%AES_BLOCK_SIZE)
			{
				/* Only process the number of complete blocks */
				numBlocks--;
			}

			if (numBlocks)
			{
				aesNiEncDecCTR(pCtx->ctx.rk, pCtx->ctx.Nr, data, data, numBlocks, pCtx->u.counterBlock);

				/* move the data pointer and increment the dataLength */
				data += numBlocks*AES_BLOCK_SIZE;
				dataLength -= numBlocks*AES_BLOCK_SIZE;
			}
		}
		else
#endif
		{
			AESCTR_GetNewBlock( pCtx, limit);
			/* XOR it with the data */
			for ( i = 0; i < AES_BLOCK_SIZE; ++i)
			{
				*data++ ^= pCtx->encBlock[i];
			}
			dataLength -= AES_BLOCK_SIZE;
		}
	}

	if ( dataLength > 0)
	{
		AESCTR_GetNewBlock( pCtx, limit);
		/* XOR it with the data */
		for ( i = 0; (i < dataLength) && (i < AES_BLOCK_SIZE); ++i)
		{
			*data++ ^= pCtx->encBlock[i];
		}
		pCtx->offset = (ubyte)i;
	}
    return OK;
}


/*------------------------------------------------------------------*/

/**
@brief      AES-CTR encrypt or decrypt a data buffer.

@details    This function AES-CTR encrypts or decrypts a data buffer. Before
            calling this function, your application must call the
            CreateAESCTRCtx() function to dynamically create a valid AES-CTR
            context. For RFC&nbsp;3686 usage, the IV should be NULL. If the
            IV parameter is not NULL, the contents of the IV are copied to
            counter block context within AES-CTR context. The internal counter
            block is incremented for each block that is encrypted/decrypted.
            AES in CTR mode does not require that the submitted data buffer be
            an even multiple of the AES block size (128 bits). Therefore, no
            padding is required, which makes this mode compatible with stream
            data.

<table class="moc_crypto_info">
  <tr><td>FIPS Approved</td>
      <td>@image html check-green.gif ""
          @image latex check-green.png "" width=0.25in </td></tr>
  <tr><td>Suite B Algorithm</td>
      <td>@image html x-red.gif ""
      @image latex x-red.png "" width=0.25in </td></tr>
  <tr><td>Flowchart</td>
      <td>@htmlonly <a href="images/flowchart_aes_ctr.jpg">AES-CTR</a>@endhtmlonly
          @latexonly
          {See \nameref{Flowcharts}.}
          @endlatexonly</td></tr>
</table>

@ingroup    aes_ctr_functions

@flags
There are no flag dependencies to enable this function.

@inc_file aes_ctr.h

@param  hwAccelCtx  If a hardware acceleration flag is defined, this macro
                      expands to an additional parameter, "hwAccelDescr
                      hwAccelCtx". Otherwise, this macro resolves to nothing.
@param  ctx         AES-CTR context, previously created by CreateAESCTRCtx().
@param  data        Data to be encrypted or decrypted.
@param  dataLength  Number of octets of data to encrypt or decrypt (\p data).
@param  encrypt     \c TRUE to encrypt the data; \c FALSE to decrypt the data.
@param  iv          Usually NULL, optionally used to pass in a new counter block
                      of AES_BLOCK_SIZE.
@param  limit       TBD.

@todo_eng_review    What's the \p limit param for?

@return     \c OK (0) if successful; otherwise a negative number error code
            definition from merrors.h. To retrieve a string containing an
            English text error identifier corresponding to the function's
            returned error status, use the \c DISPLAY_ERROR macro.

@funcdoc    aes_ctr.c
*/
#if 1
extern MSTATUS
DoAESCTR(BulkCtx ctx, ubyte* data, sbyte4 dataLength, sbyte4 encrypt, ubyte* iv)
{
    return DoAESCTREx(ctx, data, dataLength, encrypt, iv, AES_BLOCK_SIZE);
}
#else
extern MSTATUS
DoAESCTR(MOC_SYM(hwAccelDescr hwAccelCtx) BulkCtx ctx, ubyte* data, sbyte4 dataLength, sbyte4 encrypt, ubyte* iv)
{
    return DoAESCTREx(MOC_SYM(hwAccelCtx) ctx, data, dataLength, encrypt, iv, AES_BLOCK_SIZE);
}
#endif

/*------------------------------------------------------------------*/

#ifdef __ENABLE_MOCANA_IPSEC_SERVICE__

/**
@private
@internal
@todo_add_ask    (In the 5.3.1 code but not documented; don't know why not)
@ingroup    aes_ctr_functions
*/
#if 1
extern BulkCtx
CreateAesCtrCtx(ubyte* keyMaterial,
                sbyte4 keyLength, sbyte4 encrypt)
#else
extern BulkCtx
CreateAesCtrCtx(MOC_SYM(hwAccelDescr hwAccelCtx) ubyte* keyMaterial,
                sbyte4 keyLength, sbyte4 encrypt)
#endif
{

#if defined(__ENABLE_MOCANA_AES_NI__)
    /* Do a runtime sanity check */
    /* With ENABLE_MOCANA_AES_NI defined, we don't have the software option */
    if (!check_for_aes_instructions())
    	return NULL;
#endif

    aesCTRCipherContext* ctx = MALLOC(sizeof(aesCTRCipherContext));
    MOC_UNUSED(encrypt);

    if (NULL != ctx)
    {
        MOC_MEMSET((ubyte *)ctx, 0x00, sizeof(aesCTRCipherContext));

        /* install the nonce/block counter in the counter block */
        keyLength -= 4;
        MOC_MEMCPY(ctx->u.counterBlock, keyMaterial + keyLength, 4);
        ctx->u.counterBlock[AES_BLOCK_SIZE - 1] = 1;

        if (OK > AESALGO_makeAesKey(&ctx->ctx, 8 * keyLength, keyMaterial, 1, MODE_ECB))
        {
            FREE(ctx);  ctx = NULL;
        }
    }
    return ctx;
}


/*------------------------------------------------------------------*/

/**
@private
@internal
@todo_add_ask    (In the 5.3.1 code but not documented; don't know why not.
                 Differs only in the signature's upper/lower-case usage from
                 the documented function, DoAESCTR().)
@ingroup    aes_ctr_functions
*/
#if 1
extern MSTATUS
DoAesCtr(BulkCtx ctx, ubyte* data,
                         sbyte4 dataLength, sbyte4 encrypt, ubyte* iv)
#else
extern MSTATUS
DoAesCtr(MOC_SYM(hwAccelDescr hwAccelCtx) BulkCtx ctx, ubyte* data,
                         sbyte4 dataLength, sbyte4 encrypt, ubyte* iv)
#endif
{
    aesCTRCipherContext *pCtx = (aesCTRCipherContext *)ctx;

    /* install IV in the counter block */
    MOC_MEMCPY(&(pCtx->u.counterBlock[4]), iv, 8);

#if 1
    return DoAESCTREx(ctx, data, dataLength, encrypt, NULL, AES_BLOCK_SIZE);
#else
    return DoAESCTREx(MOC_SYM(hwAccelCtx) ctx, data, dataLength, encrypt, NULL, AES_BLOCK_SIZE);
#endif
}

#endif /* __ENABLE_MOCANA_IPSEC_SERVICE__ */


#endif /* (!defined(__DISABLE_AES_CIPHERS__) && !defined(__AES_HARDWARE_CIPHER__)) */
