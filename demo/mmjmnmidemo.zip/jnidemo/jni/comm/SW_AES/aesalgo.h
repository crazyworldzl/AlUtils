/* Version: mss_albatross_release */
/*
 * aesalgo.h
 *
 * AES Implementation
 *
 * Copyright Mocana Corp 2003-2017. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*------------------------------------------------------------------*/

#ifndef __AESALGO_HEADER__
#define __AESALGO_HEADER__

#ifdef __cplusplus
extern "C" {
#endif


MOC_EXTERN sbyte4 aesKeySetupEnc(ubyte4 rk[/*4*(Nr + 1)*/], const ubyte cipherKey[], sbyte4 keyBits);
MOC_EXTERN sbyte4 aesKeySetupDec(ubyte4 rk[/*4*(Nr + 1)*/], const ubyte cipherKey[], sbyte4 keyBits);
MOC_EXTERN void aesEncrypt(ubyte4 rk[/*4*(Nr + 1)*/], sbyte4 Nr, const ubyte pt[16], ubyte ct[16]);
MOC_EXTERN void aesDecrypt(ubyte4 rk[/*4*(Nr + 1)*/], sbyte4 Nr, const ubyte ct[16], ubyte pt[16]);

#ifdef __cplusplus
}
#endif

#endif /* __AESALGO_HEADER__ */
