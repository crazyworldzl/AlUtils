#ifndef __GLOBDEF_H__
#define __GLOBDEF_H__

typedef signed char i8, int8, sbyte;
typedef short i16, int16, sbyte2;
typedef int i32, int32, sbyte4;

typedef unsigned char u8, uint8, U8, ubyte, ubyte8, uint8_t;
typedef unsigned short u16, uint16, U16, ubyte2, uint16_t;
typedef unsigned int u32, uint32, U32, ubyte4, uint32_t; 

#endif
