#ifndef __UARTCLIENT_H__
#define __UARTCLIENT_H__
#include <time.h>
#include "globdef.h"

#define DBGP_COMM_BUF_SIZE (2048)

#define IB2_RX_QUEUE_NAME	"/ib2_rx_q"
#define IB2_TX_QUEUE_NAME	"/ib2_tx_q"

#define SPI_RX_QUEUE_NAME	"/spi_rx_q"
#define SPI_TX_QUEUE_NAME	"/spi_tx_q"



typedef enum {
	Br9600 = 0, 
	Br38400,
	Br115200,
	Br1M,
	Br2M,
} SpBaudRate;

typedef enum {
	Even = 0,
	Odd,
	NoParity,
} SpParity;

typedef enum {
	OneStop = 0,
	TwoStop,
} SpStop;

typedef enum {
	Seven_Bits = 0,
	Eight_Bits,
} SpDataBits;

typedef enum {
	BLOCK = 0,
	NONBLOCK,
} SpIOMode;

typedef enum {
	For_Wiselink_Ap = 0x00,
	For_IB2_AP,
} type_run_mode;

typedef enum{
	IB2_RESET_STATUS,
	IB2_NORMAL_STATUS,
} ib2_reset_status_t;

void set_programmer_mode(type_run_mode newMode);
type_run_mode get_programmer_mode();

void set_ib2_reset_status(ib2_reset_status_t newMode);
ib2_reset_status_t get_ib2_reset_status(void);
class SerialPort 
{
public:
	SerialPort() { fd = -1;  io_mode = BLOCK;}
	~SerialPort() {}
	bool open(const char* node_path);
	bool close();
	bool setIOMode(SpIOMode mode);
	bool setBaudRate(SpBaudRate baudrate);
	bool setParity(SpParity parity);
	bool setDataBits(SpDataBits bits);
	bool setStop(SpStop stop);
	//bool setFlow();
	bool flush();

	int get_fd();
	int get_read_fd();
	int get_write_fd();

	int read(u8* buffer, int buff_nb);
	int write(u8* buffer, int buff_nb);

private:
	int fd;
	SpIOMode io_mode;
};


class DQueues;

//SPISerialPort class define
#define SPI_DEV				"/dev/co-processor/spi"
#define SPI_SPEED			4000000
#define SPI_BITS				8

struct spi_param {
	unsigned char bits;
	unsigned int spi_mode;
	unsigned int speed;
};

class SPISerialPort 
{
public:
	SPISerialPort();
	~SPISerialPort() {}
	bool open(void);
	bool close();
	int get_fd();
	int get_read_fd();
	int get_write_fd();
	int get_spi_int_fd();
	int read(u8* buffer, int buff_nb);
	int write(u8* buffer, int buff_nb);
	int spi_transfer_data(int fd,struct spi_param *param,char *tx,char *rx,int len);
	void stop_work_thread();
	//DQueues& _dqueues;
private:

	int spi_fd;
	int spi_int_fd;
	pthread_t _spi_work_thread_id;
	bool spi_work_thread_run;
	bool spi_int_irq_work;
	u8 rxbuffer[2048];
	u8 txbuffer[2048];

	struct timespec spi_time;

	struct spi_param spi_adap_param;
	bool get_work_thread_flag();
	void clear_work_thread_flag();
	static void* _spi_work_thread(void* parameter);
	void SPI_workloop();
	bool check_UIO0_State(void);
	int spi_data_exchange(int tx_len);
	int spi_adapter_init(struct spi_param *param);
};

class CommClientCtrl
{
private:
	//DQueues* dqueues_ref;

	bool setup(const char* uart_node, int baud_rate);
	bool spi_setup(void);
	static void* _work_thread(void* parameter);

	pthread_t _work_thread_id;
	int _work_thread_run;
	u8 aes_keys[32];
	u8* aes_key;
	u8* aes_iv;
	u8 aes_enabled;
	u8 portType;
	
public:
	CommClientCtrl(DQueues& dqueues, const char* dev_path, u8 init_tx_seq, u8 Type);
	~CommClientCtrl();
	void InitialKeys(void);
	void ResetSequence(u8 init_tx_seq = 0, u8 init_rx_seq = 0xFF);
	void stop_work_thread();
	static const u8 SLIP_END = 192;
	static const u8 SLIP_ESC = 219;
	static const u8 SLIP_END_C = 220;
	static const u8 SLIP_ESC_C = 221;

private:
	SerialPort _port;
	SPISerialPort _spiport;
	DQueues& _dqueues;
	
	bool wait_ack_flag;
	u8 wait_ack_seq;

	bool ack_txing_flag;

	bool need_tx_ack_flag;
	u8 need_tx_ack_seq;


	u8 rx_layer3_buffer[2048];
	int rx_layer3_nb;
	bool got_sof;
	bool slip_esc_pending;
	u8 last_rx_seq;
	

	u8 tx_layer3_ack[4];
	u8 tx_layer3_buffer[2048];
	int tx_layer3_data_len;
	int tx_layer3_nb;
	u8 tx_seq;
	bool tx_queue_wait_ack;
	bool tx_dont_ack;
	
	
	u8 tx_layer2_buffer[2048+128];
	int sent_nb;
	int total_send_nb;
	struct timespec send_time;
	int tx_retry_n;

	//int recvd_nb;
	//bool got_sof;
	//unsigned char last_recvd_seq;

	//char sending_buffer[2048];
	//int sent_nb;
	//int total_send_nb;
	//unsigned char sending_seq;
	//struct timespec send_time;
	//int retry_n;

	//bool ack_to_seq_to_rx;
	
	//int ack_to_seq_to_tx;
	
	void link_depack(const u8* buffer, int buff_nb);
	void link_pack();
	
	void rx_layer3_process();
	u8* tx_layer3_process();
	void check_waitack_timeout();
	

	void rx_tx_loop();
};

#endif
