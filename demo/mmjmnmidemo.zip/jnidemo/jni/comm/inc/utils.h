#ifndef _UTILS_H__
#define _UTILS_H__
#include "globdef.h"


#ifdef __cplusplus
extern "C"
{
#endif
#define CRC16_CCITT_0000 0x0000
#define CRC16_CCITT_FFFF 0xFFFF

u16 ccitt_crc16(u8* buffer, u16 lng, u16 crcpreset);
u32 crc32(const u8 *buf, u32 lng);

u16 get_u16(const u8* buf);
u32 get_u32(const u8* buf);
void set_u16(u8* buf, u16 val);
void set_u32(u8* buf, u32 val);

int convertstring2hex(const char* hexStr, u8* hexDat, int len);
u32 b64_encode(const u8* data, u32 len, char* encoded_str);

#ifdef __cplusplus
}
#endif

#endif
