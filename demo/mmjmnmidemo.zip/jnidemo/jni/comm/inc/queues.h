#ifndef __QUEUES_H__
#define __QUEUES_H__

#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
extern "C" {
#include "queue.h"
}


#define FLG_NEED_ACK 0x01
#define FLG_DONT_ACK 0x10
#define FLG_DONT_ENCRYPT 0x80

#define ACKED 		0x01
#define NACKED 		0x02

typedef struct 
{
	char* msg_ptr;
	int msg_nb;
	int flag; /* reserved */
} DQ_MSG;

class DQueues
{
private:
	int rx_queue;
	int tx_queue;
	char* my_rx_queues_name;
	char* my_tx_queues_name;
	
	int ack_or_nack;
	pthread_cond_t var;
	pthread_mutex_t mtx;
Queue * nrx_queue;
Queue * ntx_queue;
pthread_mutex_t rx_lock;
pthread_mutex_t tx_lock;

	
public:
	DQueues(char * rx_queues_name, char * tx_queues_name);
	virtual ~DQueues();

	int rx_queue_fd() { return rx_queue; }
	int tx_queue_fd() { return tx_queue; }

	int get_rx_msg(unsigned char* buffer, int buff_nb);
	int get_rx_msg_timed(unsigned char* buffer, int buff_nb, int time);
	int get_tx_msg(unsigned char* buffer, int buff_nb, int* flag_ptr);

	int put_rx_msg(const unsigned char* buffer, int buff_nb);
	int put_tx_msg(const unsigned char* buffer, int buff_nb, int flag = 0);

	void ack_tx_msg(int ack);
};

#endif
