#ifndef __EVLOG_H__
#define __EVLOG_H__

enum {  /* log levels */
	EVL_INFO = 0,
	EVL_WARNING,
	EVL_ERROR,
	EVL_CRITICAL,
};

class EvLog 
{
private:
	EvLog();
	virtual ~EvLog();

	int _level;
public:
	static EvLog& instance();
	void enable_level(int level);
	void log_printf(int level, const char* log, ...);

	/* debug use */
	void trace_uart_rx_data(const unsigned char* buffer, int buff_nb);
	void trace_uart_tx_data(const unsigned char* buffer, int buff_nb);
	void trace_time(const   char *title);
	void  trace_block_data_time_name(const   char *title, const unsigned char * buffer,int buff_nb);
};
#endif
