/***********************************************************************************
* Unit    : api_ReedSolomon
* Layer   : API
* Version :
*
* Layers                 Commom   Appli   API   System   Kernel
* Authorized including     NO      YES    YES    NO      NO
*
* This unit provides functions for encoding and decoding Reed Solomon codes.
*
* The Reed Solomon Code Word format is (255, 223). This code can correct up 
* to 32 erasures or 16 errors, or combinations thereof with each error counting
* as two erasures. Performance r is 0.874.
*
* This unit offers a clear interface to a C module originally written
* by Phil Karn (karn at ka9q.ampr.org) in September 1996. The original rs.c module
* can handle a lot of formats and data's type of code words, but he was reduced
* to handle only the format (255, 223) by Laurent. 
*
* HISTORY
*   18.06.2014: Original creation by Laurent Battista - RSI
*   23.12.2016: Update to handle only one code word for US radio protocol. (==> Less efficiency of block interleaver)
***********************************************************************************/

#ifndef REEDSOLOMONH
#define REEDSOLOMONH
#ifdef __cplusplus
extern "C"
{
#endif

#include "rs.h"

// 16 x 16 = 256 bytes (1 code word = 255 bytes)
#define EDGE_SIZE 16

void BufferInterleaving(char Buff[EDGE_SIZE][EDGE_SIZE]); 

// Reed Solomon buffer structure to encode/decode a (255,223) code word 
typedef struct {
  union {
    u8 Data[KK];     // 223 bytes user data array.
    u8 CodeWord[NN]; // 255 bytes code word array = 223 datas folowed by 32 codes (e.g parity symbol).
  };
  char PosEras[NN-KK];   // 32 erasures positions array for a (255,223) code word.
  char PosNumber;        // Number of erasures in the erasures positions array 
} TReedSolomonBuff;

void API_InitReedSolomon(void); // Unit's initialization: must be called at least once before using the functions of the unit.
void ClearReedSolomon (TReedSolomonBuff *rs); // Clear the buffers.
int  EncodeReedSolomon(TReedSolomonBuff *rs); // Compute and fill code word array with data array as input. 
int  DecodeReedSolomon(TReedSolomonBuff *rs); // Controls and correct code word, fill data array by corrected values.

#ifdef __cplusplus
}
#endif
//---------------------------------------------------------------------------
#endif
