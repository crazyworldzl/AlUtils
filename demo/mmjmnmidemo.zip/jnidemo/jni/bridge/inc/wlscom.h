#ifndef _WLSCOM_H__
#define _WLSCOM_H__
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/select.h>
#include "globdef.h"
#include "queues.h"
class WLJsonStreamProcessor;

#define JSON_SEND_BUFF_LENTH 4096
#define JSON_PARSE_BUFF_LENTH 4096

class WLScom 
{
public:
	WLScom(DQueues& dqueues);
	virtual ~WLScom();

private:
	char strIPAddr[32];
	unsigned short nPort;

	char Json_sending_str[JSON_SEND_BUFF_LENTH];
	int Json_total_send_nb;
	int Json_sent_nb;

	char Json_parsing_str[JSON_PARSE_BUFF_LENTH];
	int Json_parsing_nb;
	
	int scom_started;

	DQueues& _dqueues;
	WLJsonStreamProcessor *_myWLJsonProcessor;
	
protected:
	virtual void scom_entry_loop();

	bool do_connect(int sock, int timeout /* in seconds */);
	void recv_and_send_loop(int sock);

  int discard_bad_data(char * ptr);
	int parse_recv_msg(const char* msg_ptr, int msg_nb);
	void prepare_sending_msg();

	
public:
	int start(const char* ipaddr, unsigned short port);
	int start();
	char* processJson(const char* json);
	int receiverMessage(const char* message);
	int put_tx_msg(const u8* buffer, int buff_nb);
	
};

#endif
