#ifndef __WLSTREAMMESSAGEPROCESS_H__
#define __WLSTREAMMESSAGEPROCESS_H__
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/sysinfo.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <time.h>
#include "WlMessageProcess.h"
#include "api_ReedSolomon.h"

#pragma pack(1) //align = 1 byte

#define SNIFFER_VS_DATA

#define FHSS_VIDEO_STREAM_DATA_LENGTH 256

#define STREAMING_NB_BYTES_PER_RADIO_BLOCK KK
#define STREAMING_NB_RADIO_BLOCK_PER_FRAME 4
#define STREAMING_MAX_BYTES_PER_FRAME (STREAMING_NB_BYTES_PER_RADIO_BLOCK*STREAMING_NB_RADIO_BLOCK_PER_FRAME+4)

enum {
	NO_VIDEO_STREAMING_RUNNING,
	VIDEO_STERAMING_RUNNING,
	ENCRYPTED_VIDEO_STREAMING_RUNNING,
};

enum {
	VS_STARTED,
	VS_ALREADY_STARTED,
	VS_START_DELAYED,
	VS_START_ERROR_NOT_AN_ISMV,
	VS_START_ERROR_ISMV_ERROR,
	VS_STOPPED,
	VS_NOT_STARTED,
	VS_START_ERROR_RADIO_BUSY,
	VS_START_ERROR_PANEL_BUSY,
	VS_START_ERROR_OTHERS,
	VS_READY_FOR_STREAMING,
	VS_READY_FOR_CRYPTO_STREAMING,
	VS_STARTED_DELAYED_CRYPTO_STREAMING,	//12
};

enum {
	VS_BREAK_NONE,
	VS_BREAK_DURATION_TIMEOUT,
	VS_BREAK_NO_MORE_DATA,
	VS_BREAK_RESYNC,
	VS_BREAK_OTHER,
};

typedef struct {
	union{
		u16 Flags;
		struct {
			u8 Rfa					:6;
			u8 fCipher				:1;
			u8 fLastSecondPacket	:1;

			u8 fLastTxPacket		:1;
			u8 fRepeat				:1;
			u8 fMAC_Enabled			:1;
			u8 fMAC_Status			:1;
			u8 fCRC_Enabled			:1;
			u8 fCRC_Status			:1;
			u8 fFEC					:1;
			u8 fInterLeaving		:1;
		};
	};
	u8 Type;
	u8 BlockNumber_msb;
	u8 BlockNumber_lsb;

	u8 MAC_msb;
	u8 MAC_lsb;

	u8 CRC_msb;
	u8 CRC_lsb;

	u8 SiteID_msb;
	u8 SiteID_lsb;
	
} TWS_FHSS_Header;


typedef struct {
	TWS_FHSS_Header header;
	u8 Buffer[FHSS_VIDEO_STREAM_DATA_LENGTH];
} TWS_FHSS_Packet;


typedef struct {
  u8 msg_id;
  u8 device_addr;
	u8 cypto_mode;
  u8 duration;	/* 0 means forever, n - n*10 seconds */
  u8 aeskey[16];
	u8 aesiv[16];
} _VS_START_MSG;

typedef struct {
	u8 msg_id;
	u8 device_addr;
	u8 option;
	u8 reserved;
} _VS_STOP_MSG;

/* streaming definition */
typedef struct{
	u16 msg_id;
    _ADDRESS_DEFINITION address;
	u8 start_stop;
	u8 channel;
	u8 up_audio_format;
	u8 down_audio_format;
	u8 up_video_format;
	u8 down_video_format;
	u8 security_type;
	u8 key[16];
	u8 iv[16];
	u8 status;	
	u8 duration;
} _REQUEST_STREAMING, _RESP_REQUEST_STREAMING, _RES_VS_START, _RES_VS_STOP;

typedef struct {
	u16 msg_id;
    _ADDRESS_DEFINITION device_addr;
    u8 channel;
    u32 blockID;
    u16 length;
    TWS_FHSS_Packet video_data;
} _RES_VS_STREAMING_DATA;

#pragma pack()

class WLStreamingStartProcess:public WLRxProcess
{
	MSG_TYPE(0x51)
		
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLStreamingStartProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLStreamingStartProcess() {}
	void process(cJSON* root);


};

class WLStreamingStopProcess:public WLRxProcess
{
	MSG_TYPE(0x52)
		
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLStreamingStopProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLStreamingStopProcess() {}
	void process(cJSON* root);


};

class WLTxVSStartResponse:public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xD1;
	WLTxVSStartResponse(const u8* msg_ptr, int msg_nb) 
	{
		blk_size = msg_nb;
		vs_start_response_msg = (_RES_VS_START*) msg_ptr;
	}
	
	~WLTxVSStartResponse() { }
	int toJSONString(char* json_str, int json_nb);

private:
	_RES_VS_START* vs_start_response_msg;
	int blk_size;
};

class WLTxVSStopResponse:public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xD2;
	WLTxVSStopResponse(const u8* msg_ptr, int msg_nb)
	{
		blk_size = msg_nb;
		//vs_stop_response_msg = (_RES_VS_STOP*) msg_ptr;
		vs_stop_response_msg = (_RES_VS_STOP*) msg_ptr;
	}
	~WLTxVSStopResponse() {}
	int toJSONString(char* json_str, int json_nb);

private:
	_RES_VS_STOP* vs_stop_response_msg;
	int blk_size;
};

class WLTxVSStreamData:public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xD3;
	WLTxVSStreamData(const u8* msg_ptr, int msg_nb)
	{
		blk_size = msg_nb;
		vs_data_msg = (_RES_VS_STREAMING_DATA*) msg_ptr;
	}
	~WLTxVSStreamData() {}
	int toJSONString(char* json_str, int json_nb);

private:
	_RES_VS_STREAMING_DATA* vs_data_msg;
	int blk_size;

};

#ifdef SNIFFER_VS_DATA
class VSFramesSniffer
{
public:
	VSFramesSniffer()
	{

	}
	virtual ~VSFramesSniffer()
	{
	}

	virtual void start() = 0;
	virtual void stop() = 0;
	virtual void OneFrameGot(u8* frame, u16 frameLen) = 0;
};

class VSFramesSniffer2File: public VSFramesSniffer
{
public:
	VSFramesSniffer2File(const char* filepath)
	{
		strncpy(m_filepath, filepath, sizeof(m_filepath)-1);
		m_filepath[sizeof(m_filepath)-1]=0;
		m_fp = NULL;
	}
	virtual ~VSFramesSniffer2File()
	{
	}
	virtual void start()
	{
		//m_fp = fopen("/run/wiselink/vs_stream.h264", "w");
		system("mkdir -p /run/wiselink/");
		m_fp = fopen(m_filepath, "w");
	}
	virtual void stop()
	{
		if (m_fp) fclose(m_fp);
		m_fp = NULL;
	}
	virtual void OneFrameGot(u8* frame, u16 frameLen)
	{
		if (m_fp)
		{
			fwrite(frame, frameLen, 1, m_fp);
		}

	}
private:
	FILE* m_fp;
	char m_filepath[256];

};
#endif

class WLVSStreamMngr
{
private:
	WLVSStreamMngr() {
#ifdef SNIFFER_VS_DATA
		vsSniffer = NULL;
#endif
	}

public:
	~WLVSStreamMngr()
	{
#ifdef SNIFFER_VS_DATA
		if (vsSniffer) delete vsSniffer;
		vsSniffer = NULL;
#endif
	}
	static WLVSStreamMngr* instance()
	{
		static WLVSStreamMngr _instance;
		return &_instance;
	}
	void StartStream(u8 device_addr, u8 encrypted_flag);
	void StopStream(u8 device_addr);
	void PushStreamData(u8 device_addr, TWS_FHSS_Packet* fhss_packet);
	void DebugEnable(bool flag);
	u16  GetAvailableFrameData(u8** frame_pptr);
	u8	 GetDevAddr(void)
	{
		return DeviceAddr;
	}
	void SetDecrypto(u8 encrypted_flag, u8 decrypt_required, u8* decrypt_key, u8* decrypt_iv);
	void PrepareDecrypto(u8 decrypt_required, u8* decrypt_key, u8* decrypt_iv);
private:
	void Increment_IV(u8* iv_instance);
	void DecryptFrame();
	void DecryptFrameEx(u8 *pbuffer);
	void mergePackets(u8* streamPacket, u16 streamPacketLength, u16 blockNumber);

#ifdef SNIFFER_VS_DATA	
	VSFramesSniffer* vsSniffer;
#endif

private:
	TReedSolomonBuff rs1;
	u32 CorrectedSymboles;
	u32 IncorrectCodeWords;
	u32 BadCrcCnt;
	u32 MissedPackets;

	u8 StreamPacketBuffer[STREAMING_MAX_BYTES_PER_FRAME];
	
	u8 StreamPacketBufferIndex;
	u16 NbBytesInStreamPacketBuffer;
	u16 LastRadioPacketNumber;

	u8 ReadyFrameBuffer[STREAMING_MAX_BYTES_PER_FRAME];
	u8 ReadyFlg;

	u8 DeviceAddr;
	bool FileEnable;
	u8 Encrypted_flag;
	u8 DoDecrypt_required;
	u8 DoDecrypt_Key[16];
	u8 DoDecrypt_IV[16];
	
	u8 LaterDecrypt_required;
	u8 LaterDecrypt_Key[16];
	u8 LaterDecrypt_IV[16];
};

#endif
