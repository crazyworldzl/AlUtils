#ifndef __WLMESSAGEPROCESS_H__
#define __WLMESSAGEPROCESS_H__
#include <vector>
#include "cJSON.h"
#include "globdef.h"
#include "evlog.h"
#include "wlscom.h"

#define CAM_VIDEO_CLIP

static const char* BrVersion = "IB2Bridge_00.01.0003";

#pragma pack(1) //align = 1 byte

enum {
    
	
    RES_ID_PIR_QUERY_SENSITIVITY = 0XB7,
	
    RES_ID_QUERY_SUPERVISION = 0xB9,
};
typedef enum _MESSAGE_TYPE{
	MESSAGE_TYPE_SET_ZONE_CONFIG						= 0x60,
	MESSAGE_TYPE_EVT_ZONE_CONFIG						= 0x61,
	MESSAGE_TYPE_SET_FIRE_CONFIG						= 0x62,
	MESSAGE_TYPE_EVT_FIRE_CONFIG						= 0x63,
	MESSAGE_TYPE_SET_SIREN_CONFIG						= 0x64,
	MESSAGE_TYPE_EVT_SIREN_CONFIG						= 0x65,
	MESSAGE_TYPE_SET_TRIGGER_CONFIG						= 0x66,
	MESSAGE_TYPE_EVT_TRIGGER_CONFIG						= 0x67,
	MESSAGE_TYPE_SET_AUXEN_CONFIG						= 0x68,
	MESSAGE_TYPE_EVT_AUXEN_CONFIG						= 0x69,
	MESSAGE_TYPE_SET_AC_CONFIG							= 0x6A,
	MESSAGE_TYPE_EVT_AC_CONFIG							= 0x6B,
	MESSAGE_TYPE_GET_BATTERY_AC							= 0x6C,
	MESSAGE_TYPE_RSP_BATTERY_AC							= 0x6D,
	MESSAGE_TYPE_GET_AUX								= 0x6E,
	MESSAGE_TYPE_RSP_AUX								= 0x6F,
	MESSAGE_TYPE_GET_EX_LTE_WIFI_ID						= 0x70,
	MESSAGE_TYPE_RSP_EX_LTE_WIFI_ID						= 0x71,
	MESSAGE_TYPE_SET_IB2_DOWNLOAD_FRAME					= 0x72,
	MESSAGE_TYPE_EVT_IB2_DOWNLOAD_FRAME					= 0x73,
	MESSAGE_TYPE_EVT_IB2_UPLOAD_FRAME					= 0x74,
	MESSAGE_TYPE_EVT_REPORT_ALL							= 0x75,
	MESSAGE_TYPE_EVT_REPORT_ZONE_STATUS					= 0x76,
	MESSAGE_TYPE_EVT_REPORT_BELL_STATUS					= 0x77,
	MESSAGE_TYPE_EVT_REPORT_AC_STATUS					= 0x78,
	MESSAGE_TYPE_SET_RUN_IB2							= 0x79,
	MESSAGE_TYPE_EVT_RUN_IB2							= 0x7A,
	MESSAGE_TYPE_HQ												= 0x7B,
} e_MESSAGE_TYPE;

// command type definition
typedef enum _DBGP_COMMAND{
    //Board common command definition
    E_DBGP_APP_GET_BOARD_INIT                           = 0x0001,
    E_DBGP_APP_RSP_BOARD_INIT                           = 0x0002,
    E_DBGP_APP_GET_BOARD_DIALOG                         = 0x0003,
    E_DBGP_APP_RSP_BOARD_DIALOG                         = 0x0004,
    E_DBGP_APP_GET_BOARD_VERSION                        = 0x0005,
    E_DBGP_APP_RSP_BOARD_VERSION                        = 0x0006,
    E_DBGP_APP_GET_BOARD_CAPABILITY                     = 0x0007,
    E_DBGP_APP_RSP_BOARD_CAPABILITY                     = 0x0008,
    E_DBGP_APP_SET_BOARD_ENTER_LOW_POWER                = 0x0009,
    E_DBGP_APP_GET_BOARD_RANDOM_DATA                    = 0x000a,
    E_DBGP_APP_RSP_BOARD_RANDOM_DATA                    = 0x000b,
    E_DBGP_APP_SET_BOARD_ENABLE_RANDOM_DATA             = 0x000c,
		E_DBGP_APP_EVT_BOARD_ENABLE_RANDOM_DATA				= 0x000d,
	
    E_DBGP_APP_EVT_BOARD_ERROR_RESPONSE                 = 0x0020,
    
    
    //FCT command definition
    E_DBGP_APP_SET_FCT_COMMAND                          = 0x6001,
    E_DBGP_APP_EVT_FCT_COMMAND                          = 0x6002,
    
    
    //Bootloader command definition
    E_DBGP_APP_SET_BOOT_TRANSFER_PKG                    = 0x1001,
    E_DBGP_APP_EVT_BOOT_TRANSFER_PKG                    = 0x1002,
    E_DBGP_APP_SET_BOOT_VERIFY_UPGRADE                  = 0x1003,
    E_DBGP_APP_EVT_BOOT_VERIFY_UPGRADE                  = 0x1004,
    E_DBGP_APP_SET_BOOT_START_APPLICATION               = 0x1005,
    E_DBGP_APP_SET_BOOT_REBOOT                          = 0x1006,
    E_DBGP_APP_SET_BOOT_LOCK_FLASH                      = 0x1007,
    E_DBGP_APP_EVT_BOOT_LOCK_FLASH                      = 0x1008,
    
    
    //AP & Peripheral management command definition
    E_DBGP_APP_GET_BOARD_INFO                           = 0x2101,
    E_DBGP_APP_RSP_BOARD_INFO                           = 0x2102,
    E_DBGP_APP_SET_RUN_MODE                             = 0x2103,
    E_DBGP_APP_EVT_RUN_MODE                             = 0x2104,
    E_DBGP_APP_SET_SITE_ADDRESS                         = 0x2105,
    E_DBGP_APP_EVT_SITE_ADDRESS                         = 0x2106,
    E_DBGP_APP_GET_SITE_ADDRESS                         = 0x2107,
    E_DBGP_APP_RSP_SITE_ADDRESS                         = 0x2108,
    E_DBGP_APP_SET_AP_MONITOR                           = 0x2109,
    E_DBGP_APP_EVT_AP_MONITOR                           = 0x210a,
	
    E_DBGP_APP_SET_UPLOAD_DEVICE_INFO                   = 0x2120,
    E_DBGP_APP_EVT_UPLOAD_DEVICE_INFO                   = 0x2121,
    E_DBGP_APP_SET_DEVICE_INFO                          = 0x2122,
    E_DBGP_APP_EVT_DEVICE_INFO                          = 0x2123,
    E_DBGP_APP_GET_DEVICE_STATUS                        = 0x2124,
    E_DBGP_APP_RSP_DEVICE_STATUS                        = 0x2125,
    E_DBGP_APP_EVT_DEVICE_UPDATE_1STATUS                = 0x2126,
    E_DBGP_APP_GET_DEVICE_1ELEMENT                      = 0x2127,
    E_DBGP_APP_RSP_DEVICE_1ELEMENT                      = 0x2128,
    E_DBGP_APP_SET_DEVICE_1ELEMENT                      = 0x2129,
    E_DBGP_APP_EVT_DEVICE_1ELEMENT                      = 0x212a,
    E_DBGP_APP_SET_START_ENROLLING                      = 0x212b,
    E_DBGP_APP_SET_STOP_ENROLLING                       = 0x212c,
    E_DBGP_APP_SET_DELETE_DEVICE                        = 0x212d,
    E_DBGP_APP_EVT_DEVICE_UPDATE_INFO                   = 0x212e,
    E_DBGP_APP_SET_DEVICE_ARM                           = 0x212f,
    E_DBGP_APP_SET_DEVICE_DISARM                        = 0x2130,
	
    E_DBGP_APP_SET_SOUND_LIGHT_LED                      = 0x2140,
    E_DBGP_APP_EVT_SOUND_LIGHT_LED                      = 0x2141,
    E_DBGP_APP_SET_SOUND_LIGHT_LED_PROFILE              = 0x2142,
    E_DBGP_APP_EVT_SOUND_LIGHT_LED_PROFILE              = 0x2143,
    E_DBGP_APP_SET_USER_REQ_IMAGE                       = 0x2144,
    E_DBGP_APP_EVT_USER_REQ_IMAGE                       = 0x2145,
    E_DBGP_APP_SET_DEVICE_STREAMING_REQ                 = 0x2146,
    E_DBGP_APP_EVT_DEVICE_STREAMING_REQ                 = 0x2147,
    E_DBGP_APP_STREAMING_DOWN_DATA                      = 0x2148,
    E_DBGP_APP_STREAMING_UP_DATA                        = 0x2149,
    E_DBGP_APP_SET_DEVICE_MAINTENANCE_TEST              = 0x214a,
    E_DBGP_APP_EVT_DEVICE_MAINTENANCE_TEST              = 0x214b,
    

	E_DBGP_APP_SET_ZONE_CONFIG							= 0x3001,
	E_DBGP_APP_EVT_ZONE_CONFIG							= 0x3002,
	E_DBGP_APP_SET_FIRE_CONFIG							= 0x3003,
	E_DBGP_APP_EVT_FIRE_CONFIG							= 0x3004,
	E_DBGP_APP_SET_SIREN_CONFIG							= 0x3005,
	E_DBGP_APP_EVT_SIREN_CONFIG							= 0x3006,
	E_DBGP_APP_SET_TRIGGER_CONFIG						= 0x3007,
	E_DBGP_APP_EVT_TRIGGER_CONFIG						= 0x3008,
	E_DBGP_APP_SET_AUXEN_CONFIG							= 0x3009,
	E_DBGP_APP_EVT_AUXEN_CONFIG							= 0x300a,
	E_DBGP_APP_SET_AC_CONFIG							= 0x300b,
	E_DBGP_APP_EVT_AC_CONFIG							= 0x300c,
	
	E_DBGP_APP_GET_BATTERY_AC							= 0x3020,
	E_DBGP_APP_RSP_BATTERY_AC							= 0x3021,
	E_DBGP_APP_GET_AUX									= 0x3022,
	E_DBGP_APP_RSP_AUX									= 0x3023,
	E_DBGP_APP_GET_EX_LTE_WIFI_ID						= 0x3024,
	E_DBGP_APP_RSP_EX_LTE_WIFI_ID						= 0x3025,
	
	E_DBGP_APP_SET_IB2_DOWNLOAD_FRAME					= 0x3040,
	E_DBGP_APP_EVT_IB2_DOWNLOAD_FRAME					= 0x3041,
	E_DBGP_APP_EVT_IB2_UPLOAD_FRAME						= 0x3042,
	E_DBGP_APP_SET_IB2_RUN								= 0x3043,
	E_DBGP_APP_EVT_IB2_RUN								= 0x3044,
	
	E_DBGP_APP_EVT_REPORT_ALL							= 0x3060,
	E_DBGP_APP_EVT_REPORT_ZONE_STATUS					= 0x3061,
	E_DBGP_APP_EVT_REPORT_BELL_STATUS					= 0x3062,
	E_DBGP_APP_EVT_REPORT_AC_STATUS						= 0x3063,

	
    // enum end
    E_DBGP_APP_END                                      = 0xffff,
    
    
}e_DBGP_COMMAND;


typedef struct {
	u16 msg_id;
} REQ_RANDOM_DATA, SET_ENABLE_RANDOM_DATA, EVT_ENABLE_RANDOM_DATA, SET_LOCK_FLASH;


// security definition
typedef enum _DBGP_SECURITY_TYPE{
    PLAINTEXT,
    AES_128_OFB,
    SECURITY_TYPE_END,
    
    AES_256_CBC_SHA256,
}e_DBGP_SECURITY_TYPE;

#define AES_128_KEY_IV_LENGTH 16
#define AES_256_KEY_IV_LENGTH 32

typedef struct {
	u16 msg_id;
	u8 security_type;
} RES_RANDOM_DATA_PLAINTEXT;

typedef struct {
	u16 msg_id;
	u8 security_type;
	u8 key[AES_128_KEY_IV_LENGTH];
	u8 iv[AES_128_KEY_IV_LENGTH];
} RES_RANDOM_DATA_AES_128_OFB;

typedef union {
	RES_RANDOM_DATA_PLAINTEXT plaintext;
	RES_RANDOM_DATA_AES_128_OFB aes_128_ofb;
} RES_RANDOM_DATA;



typedef struct {
	u16 msg_id;
	char str[256];
} _FCT;

typedef struct {
	u16 msg_id;
} REQ_RESET_MSG, REQ_JUMP2APP_MSG;

typedef struct {
	u16 msg_id;
	u16 blk_index;
	u8 blk[1024];
} REQ_BL_WRITE_BLK_MSG;

typedef struct {
	u16 msg_id;
	u32 len;
} REQ_BL_VERIFY_FW_MSG;

typedef struct {
	u16 msg_id;
	u16 blk_index;
} RES_BL_WRITE_BLK_MSG;

typedef struct {
	u16 msg_id;
	u16 rcode;
} RES_BL_SIG_VERIFY_MSG;




typedef enum {
	ADDRESS_INDEX,
	ADDRESS_LONG,
	ADDRESS_SHORT,
} _ADDRESS_TYPE;

typedef union {
	u8 index;
	u8 long_address[8];
	u8 short_address[2];
} _ADDRESS_SPACE;

typedef struct{
	u8 address_type;
	_ADDRESS_SPACE address_space;
} _ADDRESS_DEFINITION;

typedef enum {
	STOP,
	START,
} _START_STOP;

typedef struct {
  u16 msg_id;
} _GET_BOARD_VERSION_MSG;

typedef struct {
  u16 msg_id;
  char str[256];
} _RES_BOARD_VERSION_MSG;

typedef struct {
  u16 msg_id;
  u8 mode;
} _RUN_MODE_MSG;

typedef struct {
  u16 msg_id;
} _GET_SITEID_MSG;

typedef struct {
  u16 msg_id;
  u8 length;
  u8 site_id[32];
} _SET_SITEID_MSG, _RESP_SITEID_MSG;


typedef struct {
  u16 msg_id;
} _ENROLL_START_MSG, _ENROLL_STOP_MSG;

typedef struct {
  u16 msg_id;
  _ADDRESS_DEFINITION address;
} _REMOVE_DEVICES_MSG;

/* arm/disarm/remove async ... commands feedback */
enum {
  Asyn_Cmd_Acked = 0x0,         /* command sent out and got ack */
  Asyn_Cmd_Nacked = 0x01,       /* command sent out but no ack */
  Asyn_Cmd_Device_No_Found = 0x02,    /* device not found */
  Asyn_Cmd_Device_No_Support = 0x03,
  Asyn_Cmd_Timedout = 0x10,
}; 

typedef struct {
  u16 msg_id;
  _ADDRESS_DEFINITION address;
} _ARM_DEVICES_MSG, _DISARM_DEVICES_MSG;


typedef struct {
  u16 msg_id;
  u8 mode;	/* 1 - start, 0 - stop */
  u16 period; /* in seconds */
} _REQUEST_MONITOR_MSG;

typedef struct {
  u16 msg_id;
  u8 mode;
  u16 period;
  u8 status;
} _RESP_MONITOR_SUPERV_MSG;

typedef enum {
	NOTHING,
	ENROLLING_RESULT,
	ARM_RESULT,
	DISARM_RESULT,
	DELETE_RESULT,
	UPLOAD_DEVICE_INFO,//0x00: not last device; 0x01: the last device
	SET_DEVICE_INFORMATION,
} _RESULT_CODE;


typedef enum{
    
    //ADDRESS
    INDEX_INDEX                                 = 0x00,
    INDEX_LONG_ADDRESS,
    INDEX_SHORT_ADDRESS,
    
    
    // RESULT CODE
    INDEX__RESULT_TYPE,
    INDEX_RESULT_CODE,
    
    
    //CONFIGURATION
    INDEX_DEVICE_SUPERVISION_INTERVAL			= 0x10,
    INDEX_DEVICE_MONITOR_CYCLE,
    INDEX_PIR_SENSITIVITY,
    INDEX_DEVICE_FAST_CYCLE_MODE,
    INDEX_EXTERNAL_IO_CONTROL,
    
    INDEX_RESERVED00,
    INDEX_RESERVED01,
    INDEX_RESERVED02,
    INDEX_RESERVED03,
    INDEX_RESERVED04,
    
    
    //INFORMATION
    INDEX_CYCLE_VALUE                           = 0x40,
    INDEX_FASTCYCLEALLOWED_FLAG,
    INDEX_TYPE,
    INDEX_CLIENT,
    INDEX_VERSION,
    INDEX_SERIALNUMBER,
    INDEX_CRYTO_KEY,
    INDEX_NONCE_KEY,
    
    INDEX_OUT_DOOR,
    INDEX_MEASURECAPABLE,
    INDEX_ACCELEROMETER,
    
    INDEX_GOT_CAPABILITY,
    INDEX_VIDEOSTREAMINGCAPABLE,
    INDEX_H264CAPABLE,
    
    INDEX_RESERVED05,
    INDEX_RESERVED06,
    INDEX_RESERVED07,
    INDEX_RESERVED08,
    INDEX_RESERVED09,
    
    
    // STATUS
    INDEX_BATTERY_LEVEL                         = 0x70,
    INDEX_SIGNAL_LEVEL,
    INDEX_SIGNAL_LEVEL_1,
    INDEX_TEMPERATURE,
    INDEX_MODE,
    INDEX_ARM_STATE,
    INDEX_EXTERNAL_IO_INPUT,
    
    INDEX_RESERVED10,
    INDEX_RESERVED11,
    INDEX_RESERVED12,
    INDEX_RESERVED13,
    INDEX_RESERVED14,
    
    
    // STATUS WITH EVENT
    INDEX_TAMPER                                = 0xa0,
    INDEX_FIRE,
    INDEX_BATTERY_FAULT,
    INDEX_RADIOFAILURE,
    INDEX_LATCHED,
    INDEX_LATCHEDMEMO,
    INDEX_PANIC,
    INDEX_IMMEDIATE,
    INDEX_TEST,
    INDEX_SELF_TEST_FAULT,
    INDEX_JAMMING,
    
    
    INDEX_RESERVED15,
    INDEX_RESERVED16,
    INDEX_RESERVED17,
    INDEX_RESERVED18,
    INDEX_RESERVED19,
    
    
    // EVENT
    INDEX_KEYFOB                                = 0xd0,
    INDEX_DEVICE_RESYNCH,
    INDEX_EXECUTE_FAIL,
    INDEX_VIDEO_READY,
    INDEX_VIDEO_RECEIVE_DATA,
    INDEX_VIDEO_TRANSFER_RESULT,
    INDEX_RANGE_TEST_RESULT,
    
} _DEVICE_INFO_STATUS_INDEX;


typedef struct{
    
    //address
    u8 index;
    u8 long_address[8];
    u8 short_address[2];
    
    
    // result code
    u8 result_type;
    u8 result_code;
    
    
    //configuration
    u32 device_supervision_interval;
    u32 device_monitor_cycle;
    u8 pir_sensitivity;
    u8 device_fast_cycle_mode;
    u32 external_io_control;
    
    u32 reserved00;
    u32 reserved01;
    u32 reserved02;
    u32 reserved03;
    u32 reserved04;
    
    
    //information
    u8 cycle_value;
    u8 fastcycleallowed_flag;
    u16 type;
    u8 client[2];
    u8 version[4];
    u8 serialnumber[4];
    u8 cryto_key[16];
    u8 nonce_key[16];
    
    u8 out_door;
    u8 measurecapable;
    u8 accelerometer;
    
    u8 got_capability;
    u8 videostreamingcapable;
    u8 h264capable;
    
    u32 reserved05;
    u32 reserved06;
    u32 reserved07;
    u32 reserved08;
    u32 reserved09;
    
    
    // status
    u8 battery_level;
    i8 signal_level;
    i8 signal_level_1;
    i8 temperature;
    u8 mode;
    u8 arm_state;
    u32 external_io_input;
    
    u8 reserved10;
    u8 reserved11;
    u8 reserved12;
    u8 reserved13;
    u8 reserved14;
    
    
    // status with event
    u8 tamper;
    u8 fire;
    u8 battery_fault;
    u8 radiofailure;
    u8 latched;
    u8 latchedmemo;
    u8 panic;
    u8 immediate;
    u8 test;
    u8 self_test_fault;
    u8 jamming;
    
    
    u8 reserved15;
    u8 reserved16;
    u8 reserved17;
    u8 reserved18;
    u8 reserved19;
    
} _INFO_STATUS;


typedef struct {
	u16 msg_id;
	_INFO_STATUS device;
} _DEVICE_INFO_STATUS;


typedef struct {
  u16 msg_id;
  _ADDRESS_DEFINITION address;
} _REQUEST_DEVICE_INFO_STATUS_MSG;

typedef struct{
    
    //address
    _ADDRESS_DEFINITION address;
    
    //configuration
    u32 device_supervision_interval;
    u32 device_monitor_cycle;
    u8 pir_sensitivity;
    u8 device_fast_cycle_mode;
    u32 external_io_control;
    
    u32 reserved00;
    u32 reserved01;
    u32 reserved02;
    u32 reserved03;
    u32 reserved04;
    
    
    //information
    u8 cycle_value;
    u8 fastcycleallowed_flag;
    u16 type;
    u8 client[2];
    u8 version[4];
    u8 serialnumber[4];
    u8 cryto_key[16];
    u8 nonce_key[16];
    
    u8 out_door;
    u8 measurecapable;
    u8 accelerometer;
    
    u8 got_capability;
    u8 videostreamingcapable;
    u8 h264capable;
    
    u32 reserved05;
    u32 reserved06;
    u32 reserved07;
    u32 reserved08;
    u32 reserved09;
    
} _INFO;

typedef struct {
	u16 msg_id;
	_INFO device;
} _SET_DEVICES_INFO_MSG;


typedef union {
  	u8 mode;//fast cycle mode
	u8 sensitivity; //0 :disable, 1:very weak, 2:low,  3:default value, 4:high, 5:very high
	u32 interval;// device supervision
	u8 array[32];
} _INDEX_VALUE;


typedef struct {
  	u16 msg_id;
  	_ADDRESS_DEFINITION address;
  	u8 index;
	_INDEX_VALUE value;
} _RESP_1_ELEMENT, _SET_RADIO_CYCLICITY_MSG,_SET_PIR_SENSITIVITY_MSG,_RESP_SET_PIR_SENSITIVITY_MSG,_SET_SENSOR_SUPERVISION_MSG,_RESP_SET_SUPERVISION_MSG;

typedef struct {
  u16 msg_id; 
} _RESP_SENSITIVITY_RX_GET_DATA_MSG;//query command need modify added by donghanjia 20171025

typedef struct {
  u16 msg_id;
  //FRAME_M1 M1_list[1];  
} _RESP_SENSITIVITY_RX_SET_DATA_MSG;

typedef enum {
    _RESERVED,
    _SIREN,
    _LIGHT,
    _LED,
}_SOUND_LIGHT_LED;

/* led modes */
typedef enum {
	LED_MODE_OFF = 0,
	LED_MODE_ONE_SHOT,
	LED_MODE_BLINK_SLOW,
	LED_MODE_ON,
	LED_MODE_DETECT,
	LED_MODE_BLINK_FAST,
} _LED_MODE;

typedef struct {
  u16 msg_id;
  _ADDRESS_DEFINITION address;
  u8 type;
  u8 mode;
  u8 strength;
  u32 duration;
} _SET_LED_MODE_MSG;

typedef struct {
	u16 msg_id;
	_ADDRESS_DEFINITION address;
	u8 index;
} _EVENT_DEFNITION;

/* video formats */
enum {
    VIDEO_FORMAT_NONE = 0,
    VIDEO_FORMAT_MPEG,
    VIDEO_FORMAT_JPEG,
    VIDEO_FORMAT_MJPEG_ENCAP,
    VIDOE_FORMAT_MJPEG_DIFF,
    VIDEO_FORMAT_H264,
    VIDEO_FORMAT_BIG_JPEG,
};
/* video clip transfer state */
enum 
{
  VIDEO_Rx_Started = 0,
  VIDEO_Rx_Not_Support = 1,
  VIDEO_Rx_Inprogress = 2,
  VIDEO_Rx_No_Found = 3,
  VIDEO_Rx_Error = 4,
  VIDEO_Rx_Timeout = 5,
  VIDEO_Rx_Done = 6,
};

#ifdef CAM_VIDEO_CLIP
typedef struct {
    u8 NoPaquetLsb;        
    u8 NoPaquetMsb : 3;
    u8 NoFrmt: 5;
    u8 M0[5];
} FRAME_M0;

typedef struct {
    u8 NoPaquetLsb;        
    u8 NoPaquetMsb : 3;
    u8 NoFrmt: 5;
    u8 M1[15];
} FRAME_M1;


typedef struct {
	u16 msg_id;
	_ADDRESS_DEFINITION address;
	u8 index;
  	u8 format;
  	u32 size;
} _RESP_VIDEO_READY_MSG;


typedef struct {
	u16 msg_id;
	_ADDRESS_DEFINITION address;
	u8 index;
  	u8 state;
  	u8 format;
  	u32 total_size;
} _RESP_VIDEO_RX_STATE_MSG;


typedef struct {
	u16 msg_id;
	_ADDRESS_DEFINITION address;
	u8 index;
  	u8 xpaq;
  	u8 frmt_cnt;
  	FRAME_M0 M0_list[1];
} _RESP_VIDEO_RX_M0_DATA_MSG;

typedef struct {
	u16 msg_id;
	_ADDRESS_DEFINITION address;
	u8 index;
  	u8 xpaq;
  	u8 frmt_cnt;
  	FRAME_M1 M1_list[1];  
} _RESP_VIDEO_RX_M1_DATA_MSG;

typedef enum {
	USER_REQUIRE_TAKE_IMAGE,
	USER_REQUIRE_IMAGE_DATA,
	TRIGGER_TAKE_IMAGE,
} _IMAGE_ACTION;

typedef struct {
    u16 msg_id;
    
    _ADDRESS_DEFINITION address;
    
    u8 format;
    u8 duration;
    u8 quality;
    u8 resolution;
    u8 color;
    u16 reserved;
    
    u8 action;
} _CONFIG_REQUEST_IMAGE;

#endif


/* streaming definition */
/*
typedef struct{
	u16 msg_id;
	
    _ADDRESS_DEFINITION address;

	u8 start_stop;
	
	u8 channel;
	
	u8 up_audio_format;
	u8 down_audio_format;
	u8 up_video_format;
	u8 down_video_format;
	
	u8 security_type;
	u8 key[16];
	u8 iv[16];

	u8 status;
	u8 duration;
} _REQUEST_STREAMING, _RESP_REQUEST_STREAMING;
*/

typedef struct{
	u16 msg_id;
    _ADDRESS_DEFINITION address;
	u8 channel;
	u32 blockID;
	u16 length;
	u8 data[2048];
} _STREAMING_RX_DATA;


typedef enum {
	MAINTENANCE,
	RANGE_TEST,
	DETECTION_TEST,
} _MAINTENANCE_MODE;

typedef struct {
  u16 msg_id;
  _ADDRESS_DEFINITION address;
  u8 mode;
  u8 start_stop;
} _START_STOP_MAINTENANCE_MSG;

typedef struct {
	u16 msg_id;
	_ADDRESS_DEFINITION address;
	u8 index;
  	u8 key_code;
} _RESP_KEYFOB_PRESSED_MSG;

typedef struct {
	u16 msg_id;
	_ADDRESS_DEFINITION address;
	u8 index;
  	u8 radio_range;
  	i8 signal_level;
} _RESP_RANGETEST_RESULT_MSG;







/* definition for IB2 co-processor */
#define IB2_MAX_BUFFER 512
#define ZONE_MAX_CHANNEL 8

enum {
	RESULT_CODE_FAIL,
	RESULT_CODE_SUCCESS,
};

enum {
	CHANNEL_STATUS_SHORT,
	CHANNEL_STATUS_LOW,
	CHANNEL_STATUS_NORMAL,
	CHANNEL_STATUS_HIGH,
	CHANNEL_STATUS_OPEN,
};
typedef struct {
	u16 msg_id;
	u8 result_code;

	u8 channel_number;
	
	u32 channel_sampling_time;
	
	u8 channel_status;
	
	u32 channel_voltage;

	u32 short_voltage_threshold;
	u32 low_voltage_threshold;
	u32 normal_voltage_threshold;
	u32 high_voltage_threshold;
	u32 open_voltage_threshold;
} _SET_ZONE_CONFIG, _EVT_ZONE_CONFIG, _EVT_REPORT_ZONE_STATUS;

enum {
	FIRE_STATUS_ON,
	FIRE_STATUS_OFF,
	FIRE_STATUS_RESET,
};
typedef struct {
	u16 msg_id;
	u8 result_code;
	
	u8 fire_status;
	u32 timeout;
} _SET_FIRE_CONFIG, _EVT_FIRE_CONFIG;

enum{
	MELODY_MODE_OFF,
	MELODY_MODE_ON,
	MELODY_MODE_FIRE_CADENCE,
	MELODY_MODE_CO_CADENCE,
	MELODY_MODE_BELL_DING,
};
typedef struct {
	u16 msg_id;
	u8 result_code;

	u8 channel_number;
	
	u32 siren_voltage;

	u8 melody_mode;
} _SET_SIREN_CONFIG, _EVT_SIREN_CONFIG;

enum{
	TRIGGER_MODE_OFF,
	TRIGGER_MODE_ON,
	TRIGGER_MODE_TOGGLE,
	TRIGGER_MODE_INTERVAL,
	TRIGGER_MODE_PULSING,
};
typedef struct {
	u16 msg_id;
	u8 result_code;

	u8 channel_number;
	
	u8 trigger_mode;
} _SET_TRIGGER_CONFIG, _EVT_TRIGGER_CONFIG;

enum{
	AUXEN_STATUS_ON,
	AUXEN_STATUS_OFF,
};
typedef struct {
	u16 msg_id;
	u8 result_code;

	u8 auxen_status;
} _SET_AUXEN_CONFIG, _EVT_AUXEN_CONFIG;

enum{
	AC_STATUS_LOSE,
	AC_STATUS_ONLINE,
};
typedef struct {
	u16 msg_id;
	u8 result_code;

	u32 battery_voltage;
	u32 ac_voltage;
	u8 ac_status;
	u32 ac_threshold;
} _SET_AC_CONFIG, _EVT_AC_CONFIG, _GET_BATTERY_AC, _RSP_BATTERY_AC, _EVT_REPORT_AC_FAIL;

typedef struct {
	u16 msg_id;
	u8 result_code;

	u32 aux_voltage;
	u32 aux_current;
} _GET_AUX, _RSP_AUX;

typedef struct {
	u16 msg_id;
	u8 result_code;

	u32 ex_id_voltage;
	u32 lte_id_voltage;
	u32 wifi_id_voltage;
} _GET_EX_LTE_WIFI_ID, _RSP_EX_LTE_WIFI_ID;

typedef struct {
	u16 msg_id;

	u8 channel_number;

	u16 ib2_length;
	u8 ib2_buffer[IB2_MAX_BUFFER];
} _SET_IB2_DOWNLOAD_FRAME, _EVT_IB2_UPLOAD_FRAME;

typedef struct {
	u16 msg_id;
	u8 result_code;
} _EVT_IB2_DOWNLOAD_FRAME;

typedef struct {
	u16 msg_id;

	u32 zone_voltage[ZONE_MAX_CHANNEL];

	u32 battery_voltage;
	u32 ac_voltage;

	u32 aux_voltage;
	u32 aux_current;

	u32 siren_voltage;

	u32 ex_id_voltage;
	u32 lte_id_voltage;
	u32 wifi_id_voltage;

	u16 ib2_length;
	u8 ib2_buffer[IB2_MAX_BUFFER];
} _EVT_REPORT_ALL;

enum{
	BELL_STATUS_SHORT,
	BELL_STATUS_NORMAL,
	BELL_STATUS_OPEN,
};
typedef struct {
	u16 msg_id;

	u8 channel_number;
	u8 bell_status;
} _EVT_REPORT_BELL_STATUS;


typedef struct {
	u16 msg_id;
	u8 result_code;
} _SET_IB2_RUN, _EVT_IB2_RUN;


#pragma pack()

class WLScom;

#define MSG_TYPE(x) private:virtual u8 MESSAGE_TYPE() const {return x;}

class WLRxProcess	/* security app -> wiselink bridge */
{
	MSG_TYPE(0x0)

public:
	inline WLRxProcess(WLScom& wlscom):_wlscom(wlscom), _b_started_run(false) {};
	virtual ~WLRxProcess() {};
	virtual void process(cJSON* root) = 0;
	bool is4Me(u8 msgType)
	{
		return (msgType == MESSAGE_TYPE());
	}

protected:
	WLScom& _wlscom;
	bool _b_started_run;

	void do_start_run();
};

class HQProcess:public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_HQ)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline HQProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~HQProcess() {}

	void process (cJSON* root);

};

class WLRxVersionProcess : public WLRxProcess
{
	MSG_TYPE(0x01)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline WLRxVersionProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~WLRxVersionProcess() {}

	void process (cJSON* root);


};

class WLRxQuerySiteIDProcess: public WLRxProcess
{
	MSG_TYPE(0x11)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxQuerySiteIDProcess(WLScom& wlscom) : WLRxProcess( wlscom) {}
	~WLRxQuerySiteIDProcess() { }
	void process(cJSON* root);

};

class WLRxSetSiteIDProcess: public WLRxProcess
{
	MSG_TYPE(0x12)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxSetSiteIDProcess(WLScom& wlscom) : WLRxProcess( wlscom) {}
	~WLRxSetSiteIDProcess() { }
	void process(cJSON* root);

};


class WLRxQueryDevicesInfoProcess: public WLRxProcess
{
	MSG_TYPE(0x13)
	
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxQueryDevicesInfoProcess(WLScom& wlscom) : WLRxProcess( wlscom) {}
	~WLRxQueryDevicesInfoProcess() { }
	void process(cJSON* root);
};


class WLRxSetDevicesInfoProcess:public WLRxProcess
{
	MSG_TYPE(0x14)
		
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxSetDevicesInfoProcess(WLScom& wlscom) : WLRxProcess( wlscom) {}
	~WLRxSetDevicesInfoProcess() { }
	void process(cJSON* root);

};

class WLRxQueryDeviceSensitivityProcess:public WLRxProcess
{
	MSG_TYPE(0x37)
		
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxQueryDeviceSensitivityProcess(WLScom& wlscom) : WLRxProcess( wlscom) {}
	~WLRxQueryDeviceSensitivityProcess() {}
	void process(cJSON* root);

};

class WLRxSetDeviceSensitivityProcess:public WLRxProcess
{
	MSG_TYPE(0x36)
		
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxSetDeviceSensitivityProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxSetDeviceSensitivityProcess() {}
	void process(cJSON* root);


};

class WLRxQueryDeviceSupervisionProcess:public WLRxProcess
{
	MSG_TYPE(0x39)
		
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxQueryDeviceSupervisionProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxQueryDeviceSupervisionProcess() {}
	void process(cJSON* root);


};

class WLRxSetDeviceSupervisionProcess:public WLRxProcess
{
	MSG_TYPE(0x38)
		
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxSetDeviceSupervisionProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxSetDeviceSupervisionProcess() {}
	void process(cJSON* root);


};

/*
class WLStreamingStartProcess:public WLRxProcess
{
	MSG_TYPE(0x51)
		
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLStreamingStartProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLStreamingStartProcess() {}
	void process(cJSON* root);


};

class WLStreamingStopProcess:public WLRxProcess
{
	MSG_TYPE(0x52)
		
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLStreamingStopProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLStreamingStopProcess() {}
	void process(cJSON* root);


};
*/

class WLRxEnrollProcess : public WLRxProcess
{	MSG_TYPE(0x21)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline WLRxEnrollProcess(WLScom& wlscom):WLRxProcess( wlscom ) {}
	~WLRxEnrollProcess() {}
	void process(cJSON* root);

	
};

class WLRxRemoveProcess: public WLRxProcess
{
	MSG_TYPE(0x23)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxRemoveProcess(WLScom& wlscom) : WLRxProcess( wlscom) {}
	~WLRxRemoveProcess() { }
	void process(cJSON* root);
};

class WLRxArmDevicesProcess: public WLRxProcess
{
	MSG_TYPE(0x24)
	
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxArmDevicesProcess(WLScom& wlscom) : WLRxProcess( wlscom) {}
	~WLRxArmDevicesProcess() { }
	void process(cJSON* root);

};

class WLRxDisarmDevicesProcess: public WLRxProcess
{
	MSG_TYPE(0x25)
	
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxDisarmDevicesProcess(WLScom& wlscom) : WLRxProcess( wlscom) {}
	~WLRxDisarmDevicesProcess() { }
	void process(cJSON* root);
};



class WLRxRangeTestProcess:public WLRxProcess
{
	MSG_TYPE(0x26)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
public:
	WLRxRangeTestProcess(WLScom& wlscom) : WLRxProcess( wlscom) {}
	~WLRxRangeTestProcess() { }
	void process(cJSON* root);
};

class WLRxControlLedProcess: public WLRxProcess
{
	MSG_TYPE(0x27)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	WLRxControlLedProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxControlLedProcess() {}
	void process(cJSON* root);
};

class WLRxRequestPStatProcess: public WLRxProcess
{
	MSG_TYPE(0x28)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	WLRxRequestPStatProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxRequestPStatProcess() {}
	void process(cJSON* root);
};

class WLRxSetRadioCyclicityProcess : public WLRxProcess
{
	MSG_TYPE(0x29)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	WLRxSetRadioCyclicityProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxSetRadioCyclicityProcess() {}
	void process(cJSON* root);
};

class WLRxRequestMaintanceProcess: public WLRxProcess
{
	MSG_TYPE(0x2A)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	WLRxRequestMaintanceProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxRequestMaintanceProcess() {}
	void process(cJSON* root);
};


class WLRxConfigVideoProcess: public WLRxProcess
{
	MSG_TYPE(0x40)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	WLRxConfigVideoProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxConfigVideoProcess() {}
	void process(cJSON* root);
};

class WLRxGetVideoClipProcess: public WLRxProcess
{
	MSG_TYPE(0x41)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
	
public:
	WLRxGetVideoClipProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxGetVideoClipProcess() {}
	void process(cJSON* root);
};

class WLRxGetVideoSnapshotProcess: public WLRxProcess
{
	MSG_TYPE(0x42)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);
	
public:
	WLRxGetVideoSnapshotProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxGetVideoSnapshotProcess() {}
	void process(cJSON* root);
};

class WLRxRequestMonitorProcess: public WLRxProcess
{
	MSG_TYPE(0xF1)
public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	WLRxRequestMonitorProcess(WLScom& wlscom) : WLRxProcess(wlscom) {}
	~WLRxRequestMonitorProcess() {}
	void process(cJSON* root);
};


class WLTxProcess	/* wiselink bridge -> security app */
{
public:
	WLTxProcess() {};
	virtual ~WLTxProcess() { MessageType = 0; };

//	virtual unsigned char getMessageType() {};
	virtual int toJSONString(char* json_str, int json_nb) = 0;
	unsigned char MessageType;
};

class WLTxEnrollResponseProcess: public WLTxProcess
{
public:

	static const u8 MESSAGE_TYPE = 0x22;
	
	WLTxEnrollResponseProcess(const u8* msg_ptr, int msg_nb);
	~WLTxEnrollResponseProcess() {}

	int toJSONString(char* json_str, int json_nb);
private:
	_DEVICE_INFO_STATUS* enroll_resp_ptr;
	int blk_size;
};



class WLTxVersionResponseProcess: public WLTxProcess
{

public:
	static const u8 MESSAGE_TYPE = 0x81;
	WLTxVersionResponseProcess(const u8* msg_ptr, int msg_nb) {
		u16 i = 2;
		strVersion = (char*) malloc(msg_nb);
		if (strVersion) 
		{
			while(msg_ptr[i] != '\0'){
				i++;
			}
			i++;
			while(msg_ptr[i] != '\0'){
				i++;	
			}
			i++;
			
			strncpy(strVersion, (char*)(msg_ptr + i), msg_nb-i);
			strVersion[msg_nb-1] = 0;
		}
	}
	~WLTxVersionResponseProcess()
	{
		if(strVersion) free(strVersion);
	}

	int toJSONString(char* json_str, int json_nb)
	{
		cJSON* root = cJSON_CreateObject();
		if (!root) return 0;
		cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
		cJSON_AddStringToObject(root, "BbVersion", strVersion?strVersion:"");
		cJSON_AddStringToObject(root, "BrVersion", BrVersion);
		char* JsonChar = cJSON_Print(root);
		if (!JsonChar)
		{
			cJSON_Delete(root);
			return 0;
		}
		int size = strlen(JsonChar);

		if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
		else size = 0;
		free(JsonChar);
		cJSON_Delete(root);
		return size;
	}

private:
	char* strVersion;
};



class WLTxQuerySiteIDResponseProcess:public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0x91;

	WLTxQuerySiteIDResponseProcess(const u8* msg_ptr, int msg_nb)
	{
		resp_siteid_msg_ptr = (_RESP_SITEID_MSG*) msg_ptr;
		blk_size = msg_nb;
	}
	~WLTxQuerySiteIDResponseProcess() {}
	int toJSONString(char* json_str, int json_nb);
private:
	_RESP_SITEID_MSG* resp_siteid_msg_ptr;
	int blk_size;
};

class WLTxQueryDevicesInfoResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0x93;
	WLTxQueryDevicesInfoResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pInfo = (_DEVICE_INFO_STATUS *)msg_ptr;
		blk_size = msg_nb;
	}
	~WLTxQueryDevicesInfoResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_DEVICE_INFO_STATUS * pInfo;
	int blk_size;
};




class WLTxRemovedResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xA3;
	WLTxRemovedResponseProcess(const u8* msg_ptr, int msg_nb);
	~WLTxRemovedResponseProcess();
	int toJSONString(char* json_str, int json_nb);

private:
	_DEVICE_INFO_STATUS * _resp_removed_ptr;
	int blk_size;
};

class WLTxArmedResponseProcess:public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xA4;
	WLTxArmedResponseProcess(const u8* msg_ptr, int msg_nb);
	~WLTxArmedResponseProcess();
	int toJSONString(char* json_str, int json_nb);

private:
	_DEVICE_INFO_STATUS * _resp_armed_ptr;
	int blk_size;	
};

class WLTxDisarmedResponseProcess:public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xA5;
	WLTxDisarmedResponseProcess(const u8* msg_ptr, int msg_nb);
	~WLTxDisarmedResponseProcess();
	int toJSONString(char* json_str, int json_nb);

private:
	_DEVICE_INFO_STATUS* _resp_disarmed_ptr;
	int blk_size;	
};


class WLTxStatusUpdateEventProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xB1;

	WLTxStatusUpdateEventProcess(const u8* msg_ptr, int msg_nb);
	~WLTxStatusUpdateEventProcess() { }
	int toJSONString(char* json_str, int json_nb);

private:
	_DEVICE_INFO_STATUS* status_update_ptr;
	int blk_size;
};

class WLTxKeyPressedEventProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xB2;
	WLTxKeyPressedEventProcess(const u8* msg_ptr, int msg_nb);
	~WLTxKeyPressedEventProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_RESP_KEYFOB_PRESSED_MSG* key_press_msg_ptr;
	int blk_size;
};

class WLTxRangeTestResponseProcess : public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xB6;
	WLTxRangeTestResponseProcess(const u8* msg_ptr, int msg_nb);
	~WLTxRangeTestResponseProcess() {}
	int toJSONString(char* json_str, int json_nb);
private:
	_RESP_RANGETEST_RESULT_MSG* resp_range_ptr;
	int blk_size;
};


class BitMap
{
	#define BITSPERWORD 	32
	#define SHIFT 			5
	#define MASK 			0x1F
public:
	BitMap(u32 size)
	{
		pMap = new u32[1 + size / BITSPERWORD];
		memset(pMap, 0, (1 + size / BITSPERWORD) * sizeof(u32));
		max	 = size;
	}
	
	~BitMap() 
	{
		delete pMap;
	}
	
	void set(u32 i)
	{   
		if (i > max)
		{
			return;
		}
		pMap[i >> SHIFT] |=  (1<<(i & MASK));   
	}
	
	void set(u32 head, u32 offset)
	{   
		unsigned int i;
		
		if ((head + offset) > max)
		{
			return;
		}
		for (i = head; i < (head + offset); i++)
		{
			pMap[i >> SHIFT] |=  (1 << (i & MASK)); 
		}
	} 
	
	void clr(u32 i) 
	{          
		if (i > max)
		{
			return;
		}
		pMap[i >> SHIFT] &= ~(1<<(i & MASK));   
	}
	
	void clr(u32 head, u32 offset)
	{   
		u32 i;
		if ((head + offset) > max)
		{
			return;
		}		
		for (i = head; i < (head + offset); i++)
		{
			pMap[i >> SHIFT] &= ~(1<<(i & MASK));  
		}
	} 
	
	int test(u32 i)
	{   
		if (i > max)
		{
			return 0;
		}
		return pMap[i >> SHIFT] & (1<<(i & MASK));
	}
	
	int test(u32 head, u32 offset)
	{   
		unsigned int i;
		if ((head + offset) > max)
		{
			return 0;
		}

		for (i = head; i < (head + offset); i++)
		{
			if (test(i) == 0)
			{
				printf("Map Test clr index:%d\r\n", i);
				return 0;
			}
		}

		return 1;
	} 
	
	uint32 getClrHead(u32 head, u32 offset)
	{   
		unsigned int i;
		if ((head + offset) > max)
		{
		
		printf("getClrHead:%d\r\n", __LINE__);
			return head;
		}

		for (i = head; i < (head + offset); i++)
		{
			if (test(i) == 0)
			{
				printf("Map Test clr index:%d\r\n", i);
				return i;
			}
		}
		
		printf("getClrHead:%d,%d\r\n", __LINE__, i);

		return i;
	} 	
private:
	u32 *pMap;
	u32 max;
};

class WLVideoClipBuffer
{
private:
	WLVideoClipBuffer() 
	{
		video_buffer = NULL; 
		//frames_per_blk = NULL;
		started = 0;
	}
private:
	u8* video_buffer;			
	u32 buffer_len;  	// AP report clip size
	u32 recv_len; 		// size of date we already received from AP.
	u32	sent_len;		// size of adta we already sent to process.
	u32 valid_index;    // current valid data index. 

	u8 xpaq;
	u8 started;
	u8 device_addr;
	u8 end_state;

	//jason clip
	BitMap* bit_map;

#define M0_FRAME_SIZE 5
#define M1_FRAME_SIZE 15
#define M_PACKET_SIZE (M1_FRAME_SIZE*8)
#define CLIP_PACK_SIZE 1000

public:
	static const u8 MESSAGE_TYPE_RX_STATE = 0xC2;
	static const u8 MESSAGE_TYPE_RX_DATA = 0xC3;

	~WLVideoClipBuffer() {}
	static WLVideoClipBuffer* instance()
	{
		static WLVideoClipBuffer _instance;
		return &_instance;
	}
	bool IsClipPackageReady(void)
	{
		uint32 index;

		if (!started)
		{	
			if (end_state != VIDEO_Rx_Done)
			{
				EvLog::instance().log_printf(EVL_INFO, "[VIDEO] Not start!\n");
				return 0;
			}
			else
			{	
				//handle the rest buffer data.
				EvLog::instance().log_printf(EVL_INFO, "[VIDEO] VIDEO_Rx_Done!\n");
				return 1;
			}
		}

		index = bit_map->getClrHead(sent_len, (buffer_len - sent_len));
		EvLog::instance().log_printf(EVL_INFO, "[VIDEO] Jsn:total len:%d, recv:%d, sent:%d, invalid_index:%d!\n", buffer_len, recv_len, sent_len, index);
		
		//check vaild data len
		if ((index - sent_len) >= CLIP_PACK_SIZE)
		{
			return 1;
		}
		else
		{
			//wait the buffer to be filled in other state. So we do not need to send package.
			if (end_state != VIDEO_Rx_Done)
			{
				return 0;
			}
		}

		return 1;
	}
	int toJSONString(char* json_str, int json_nb); 
	void InitState(void)
	{
		end_state = 0;
		sent_len = 0;
		buffer_len = 0;
		recv_len = 0;
		started = 0;
		end_state = 0;

	}
	void Start(u8 addr, u32 total_size)
	{
		delete [] video_buffer;
		video_buffer = new u8[total_size + (50 * 1024)];//(50 * 1024) for unexpect clip data
		
		delete bit_map;
		bit_map = new BitMap(total_size + (50 * 1024));
		
		buffer_len = total_size;
		recv_len = 0;
		sent_len = 0;
		valid_index = 0;

		started = 1;
		device_addr = addr;
		end_state = 0;
	}
	void Done(u8 addr)
	{
		if (addr != device_addr || !started) return;
		system("mkdir -p /run/wiselink/");
		FILE* fp = fopen("/run/wiselink/videoclip.h264", "w");
		if (fp)
		{
			fwrite(video_buffer, buffer_len, 1, fp);
			fclose(fp);
		}

		EvLog::instance().log_printf(EVL_INFO, "[VIDEO]File Saved, recv_len =%d\n", recv_len);
		
		//save file
		started = 0;
		end_state = VIDEO_Rx_Done;
	}
	
	bool PushData( u8 addr, FRAME_M1* m1)
	{
		if (!started || addr != device_addr) return false;
		u32 offset = ((m1->NoPaquetMsb << 8) + m1->NoPaquetLsb)*M_PACKET_SIZE + m1->NoFrmt*M1_FRAME_SIZE;
		
		if ((offset + M1_FRAME_SIZE) <= buffer_len)
		{
			bit_map->set(offset, M1_FRAME_SIZE);
		//	EvLog::instance().log_printf(EVL_INFO, "bit set start1:%d, len:%d", offset, M1_FRAME_SIZE);
			memcpy(video_buffer + offset, m1->M1, M1_FRAME_SIZE);
			xpaq = 1;
			recv_len += M1_FRAME_SIZE;
			return true;
		} else {
			return false;
		}
	}
	bool PushData(u8 addr, FRAME_M0* m0)
	{
		if (!started || addr != device_addr) return false;
		u32 offset = ((m0->NoPaquetMsb << 8) + m0->NoPaquetLsb)*M_PACKET_SIZE + m0->NoFrmt*M0_FRAME_SIZE;
		
		if ((offset + M0_FRAME_SIZE) <= buffer_len)
		{
			bit_map->set(offset, M0_FRAME_SIZE);
		//	EvLog::instance().log_printf(EVL_INFO, "bit set start0:%d, len:%d", offset, M0_FRAME_SIZE);
			memcpy(video_buffer + offset, m0->M0, 5);
			xpaq = 0;
			recv_len += M0_FRAME_SIZE;
			//??
			return true;
		} else {
			return false;
		}
	}
};

class WLTxVideoReadyEventProcess:public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xC1;
	WLTxVideoReadyEventProcess(const u8* msg_ptr, int msg_nb) 
	{
		blk_size = msg_nb;
		video_ready_msg_ptr = (_RESP_VIDEO_READY_MSG*) msg_ptr;
	}
	~WLTxVideoReadyEventProcess() { }
	int toJSONString(char* json_str, int json_nb);

private:
	_RESP_VIDEO_READY_MSG* video_ready_msg_ptr;
	int blk_size;
};

class WLTxVideoStateEventProcess: public WLTxProcess
{

public:
	static const u8 MESSAGE_TYPE = 0xC2;
	WLTxVideoStateEventProcess(const u8* msg_ptr, int msg_nb)
	{
		blk_size = msg_nb;
		video_state_msg_ptr = (_RESP_VIDEO_RX_STATE_MSG*) msg_ptr;
	}
	~WLTxVideoStateEventProcess() { }
	int toJSONString(char* json_str, int json_nb) { 
		cJSON* root = cJSON_CreateObject();
		if (!root){ return 0; }
		
		EvLog::instance().log_printf(EVL_INFO, "[Video]VideoClip State: addr = %d, state = %d!\n",
								video_state_msg_ptr->address.address_space.index,
								video_state_msg_ptr->state);
		
		if (video_state_msg_ptr->state == VIDEO_Rx_Started)
		{
			//prepare video buffer when we received Video Rx started message
			WLVideoClipBuffer::instance()->Start(video_state_msg_ptr->address.address_space.index, 
											video_state_msg_ptr->total_size);
		} else if (video_state_msg_ptr->state == VIDEO_Rx_Done)
		{
			//send rest buffer data
			//Todo
			WLVideoClipBuffer::instance()->Done(video_state_msg_ptr->address.address_space.index);
		}else if (video_state_msg_ptr->state >= 10)
		{
			//just print  error state + 10
			//#define CAUSE_ARRET_ERREUR_TABLE_BLOCS_ERRONES_PLEINE           1
			//#define CAUSE_ARRET_ERREUR_CTRANS_POURSUITE_NACK_FRAME          2
			//#define CAUSE_ARRET_ERREUR_C_VIDEO_NACK                         3
			//#define CAUSE_ARRET_ERREUR_TIMEOUT_PTRANS_JPEG                  4
			//#define CAUSE_ARRET_ERREUR_TIMEOUT_PTRANS_MPEG                  5
			//#define CAUSE_ARRET_ERREUR_RX_PTRANS_ERREUR_SESSION             6
			//#define CAUSE_ARRET_ERREUR_RETOUR_CAPTURE_ERREUR_SESSION        7

			EvLog::instance().log_printf(EVL_INFO, "@@@@@[Video]Clip recv specialerror state:= %d!@@@@\n", video_state_msg_ptr->state);
			cJSON_Delete(root);
			return 0;
		}
		else
		{
			//process error state
			EvLog::instance().log_printf(EVL_INFO, "[Video]Clip recv state:= %d!\n", video_state_msg_ptr->state);
			WLVideoClipBuffer::instance()->InitState();
		}
		
		cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
		cJSON_AddNumberToObject(root, "Device", video_state_msg_ptr->address.address_space.index);
		cJSON_AddNumberToObject(root, "Code", video_state_msg_ptr->state);
		
		char* JsonChar = cJSON_Print(root);
		if (!JsonChar)
		{
			cJSON_Delete(root);
			return 0;
		}
		int size = strlen(JsonChar);
		
		if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
		else size = 0;
		free(JsonChar);
		cJSON_Delete(root);
		if (video_state_msg_ptr->state == VIDEO_Rx_Done)
		{
			size = 0;
		}
		return size;	
	} //Todo 

private:
	
	_RESP_VIDEO_RX_STATE_MSG* video_state_msg_ptr;
	int blk_size;


};
class WLTxVideoDataEventProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xC3;
	WLTxVideoDataEventProcess(const u8* msg_ptr, int msg_nb)
	{
		video_data_msg_ptr = (_RESP_VIDEO_RX_M1_DATA_MSG*) msg_ptr;
		blk_size = msg_nb;
	}
	~WLTxVideoDataEventProcess() { }
	int toJSONString(char* json_str, int json_nb)
	{
		u8* data_ptr = NULL;
		u16 data_len = 0;

		for (int i = 0; i < video_data_msg_ptr->frmt_cnt; ++i)
		{
			if (video_data_msg_ptr->xpaq)
				WLVideoClipBuffer::instance()->PushData(video_data_msg_ptr->address.address_space.index,
														&(video_data_msg_ptr->M1_list[i]));
		}

		return 0;
	}

private:
	_RESP_VIDEO_RX_M1_DATA_MSG* video_data_msg_ptr;
	int blk_size;
};

class WLTxStreamingDataEventProcess:public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xD3;
	WLTxStreamingDataEventProcess(const u8* msg_ptr, int msg_nb) 
	{
		blk_size = msg_nb;
		video_ready_msg_ptr = (_STREAMING_RX_DATA*) msg_ptr;
	}
	~WLTxStreamingDataEventProcess() { }
	int toJSONString(char* json_str, int json_nb);

private:
	_STREAMING_RX_DATA* video_ready_msg_ptr;
	int blk_size;
};

class WLTxMonitorSupervProcess : public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xF2;
	WLTxMonitorSupervProcess(const u8* msg_ptr, int msg_nb);
	~WLTxMonitorSupervProcess();
	int toJSONString(char* json_str, int json_nb);

private:
	_RESP_MONITOR_SUPERV_MSG* _resp_monitor_superv_ptr;
	int blk_size;

};

class WLTxQuerySensitivityProcess : public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xB7;
	WLTxQuerySensitivityProcess(const u8* msg_ptr, int msg_nb)
	{
		_resp_sensitivity_list_ptr = (_RESP_SENSITIVITY_RX_GET_DATA_MSG*) msg_ptr;
		blk_size = msg_nb;
	}
	
	~WLTxQuerySensitivityProcess(){}
	int toJSONString(char* json_str, int json_nb);

private:
	_RESP_SENSITIVITY_RX_GET_DATA_MSG* _resp_sensitivity_list_ptr;
	int blk_size;

};

class WLTxSetSensitivityProcess : public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xB4;
	WLTxSetSensitivityProcess(const u8* msg_ptr, int msg_nb)
	{
		_resp_sensitivity_status_ptr = (_RESP_SENSITIVITY_RX_SET_DATA_MSG*) msg_ptr;
		blk_size = msg_nb;
	}
	
	~WLTxSetSensitivityProcess(){}
	int toJSONString(char* json_str, int json_nb);

private:
	_RESP_SENSITIVITY_RX_SET_DATA_MSG* _resp_sensitivity_status_ptr;
	int blk_size;

};

class WLTxQuerySensorSupervisionProcess : public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xB9;
	WLTxQuerySensorSupervisionProcess(const u8* msg_ptr, int msg_nb)
	{
		_resp_sensitivity_list_ptr = (_RESP_SENSITIVITY_RX_GET_DATA_MSG*) msg_ptr;
		blk_size = msg_nb;
	}
	
	~WLTxQuerySensorSupervisionProcess(){}
	int toJSONString(char* json_str, int json_nb);

private:
	_RESP_SENSITIVITY_RX_GET_DATA_MSG* _resp_sensitivity_list_ptr;
	int blk_size;

};

class WLTxSetSensorSupervisionProcess : public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = 0xB8;
	WLTxSetSensorSupervisionProcess(const u8* msg_ptr, int msg_nb)
	{
		_resp_sensitivity_status_ptr = (_RESP_SENSITIVITY_RX_SET_DATA_MSG*) msg_ptr;
		blk_size = msg_nb;
	}
	
	~WLTxSetSensorSupervisionProcess(){}
	int toJSONString(char* json_str, int json_nb);

private:
	_RESP_SENSITIVITY_RX_SET_DATA_MSG* _resp_sensitivity_status_ptr;
	int blk_size;

};


class WLJsonStreamProcessor
{
public:
	WLJsonStreamProcessor(WLScom& wlscom);
	~WLJsonStreamProcessor();
	int processRx(const char* json_msg);
	int processTx(const u8* buffer, int buff_nb, char* json_buffer, int json_buffer_nb);

	static WLRxProcess & (*createlist[])(WLScom&);
private:
	WLScom& _wlscom;
	std::vector<WLRxProcess*> arrayRxProcesses;	
};


class CPSetZoneConfigProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_SET_ZONE_CONFIG)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPSetZoneConfigProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPSetZoneConfigProcess() {}

	void process (cJSON* root);


};


class CPSetFireConfigProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_SET_FIRE_CONFIG)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPSetFireConfigProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPSetFireConfigProcess() {}

	void process (cJSON* root);


};


class CPSetSirenConfigProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_SET_SIREN_CONFIG)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPSetSirenConfigProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPSetSirenConfigProcess() {}

	void process (cJSON* root);


};


class CPSetTriggerConfigProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_SET_TRIGGER_CONFIG)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPSetTriggerConfigProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPSetTriggerConfigProcess() {}

	void process (cJSON* root);


};


class CPSetAuxenConfigProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_SET_AUXEN_CONFIG)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPSetAuxenConfigProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPSetAuxenConfigProcess() {}

	void process (cJSON* root);


};


class CPSetAcConfigProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_SET_AC_CONFIG)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPSetAcConfigProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPSetAcConfigProcess() {}

	void process (cJSON* root);


};


class CPGetBatteryACProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_GET_BATTERY_AC)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPGetBatteryACProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPGetBatteryACProcess() {}

	void process (cJSON* root);


};

class CPGetAUXProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_GET_AUX)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPGetAUXProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPGetAUXProcess() {}

	void process (cJSON* root);


};

class CPGetEX_LTE_WIFIProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_GET_EX_LTE_WIFI_ID)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPGetEX_LTE_WIFIProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPGetEX_LTE_WIFIProcess() {}

	void process (cJSON* root);


};

class CPSetIB2DownloadFrameProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_SET_IB2_DOWNLOAD_FRAME)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPSetIB2DownloadFrameProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPSetIB2DownloadFrameProcess() {}

	void process (cJSON* root);


};

class CPSetIB2RunProcess : public WLRxProcess
{
	MSG_TYPE(MESSAGE_TYPE_SET_RUN_IB2)

public:
	static WLRxProcess& CREATE(WLScom& wlscom);

public:
	inline CPSetIB2RunProcess(WLScom& wlscom):WLRxProcess(wlscom) {}
	~CPSetIB2RunProcess() {}

	void process (cJSON* root);


};

class CPSetZoneConfigResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_ZONE_CONFIG;
	CPSetZoneConfigResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_ZONE_CONFIG *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPSetZoneConfigResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_ZONE_CONFIG * pData;
	int blk_size;
};

class CPSetFireConfigResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_FIRE_CONFIG;
	CPSetFireConfigResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_FIRE_CONFIG *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPSetFireConfigResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_FIRE_CONFIG * pData;
	int blk_size;
};
class CPSetSirenConfigResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_SIREN_CONFIG;
	CPSetSirenConfigResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_SIREN_CONFIG *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPSetSirenConfigResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_SIREN_CONFIG * pData;
	int blk_size;
};
class CPSetTriggerConfigResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_TRIGGER_CONFIG;
	CPSetTriggerConfigResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_TRIGGER_CONFIG *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPSetTriggerConfigResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_TRIGGER_CONFIG * pData;
	int blk_size;
};
class CPSetAuxenConfigResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_AUXEN_CONFIG;
	CPSetAuxenConfigResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_AUXEN_CONFIG *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPSetAuxenConfigResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_AUXEN_CONFIG * pData;
	int blk_size;
};
class CPSetAcConfigResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_AC_CONFIG;
	CPSetAcConfigResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_AC_CONFIG *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPSetAcConfigResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_AC_CONFIG * pData;
	int blk_size;
};
class CPGetBatteryACResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_RSP_BATTERY_AC;
	CPGetBatteryACResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_RSP_BATTERY_AC *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPGetBatteryACResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_RSP_BATTERY_AC * pData;
	int blk_size;
};
class CPGetAUXResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_RSP_AUX	;
	CPGetAUXResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_RSP_AUX *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPGetAUXResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_RSP_AUX * pData;
	int blk_size;
};
class CPGetEX_LTE_WIFIResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_RSP_EX_LTE_WIFI_ID;
	CPGetEX_LTE_WIFIResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_RSP_EX_LTE_WIFI_ID *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPGetEX_LTE_WIFIResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_RSP_EX_LTE_WIFI_ID * pData;
	int blk_size;
};
class CPSetIB2DownloadFrameResponseProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_IB2_DOWNLOAD_FRAME;
	CPSetIB2DownloadFrameResponseProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_IB2_DOWNLOAD_FRAME *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPSetIB2DownloadFrameResponseProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_IB2_DOWNLOAD_FRAME * pData;
	int blk_size;
};

class CPEvtIB2UploadFrameProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_IB2_UPLOAD_FRAME;
	CPEvtIB2UploadFrameProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_IB2_UPLOAD_FRAME *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPEvtIB2UploadFrameProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_IB2_UPLOAD_FRAME * pData;
	int blk_size;
};

class CPEvtReportAllProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_REPORT_ALL;
	CPEvtReportAllProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_REPORT_ALL *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPEvtReportAllProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_REPORT_ALL * pData;
	int blk_size;
};

class CPEvtReportZoneStatusProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_REPORT_ZONE_STATUS;
	CPEvtReportZoneStatusProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_REPORT_ZONE_STATUS *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPEvtReportZoneStatusProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_REPORT_ZONE_STATUS * pData;
	int blk_size;
};

class CPEvtReportBellStatusProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_REPORT_BELL_STATUS;
	CPEvtReportBellStatusProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_REPORT_BELL_STATUS *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPEvtReportBellStatusProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_REPORT_BELL_STATUS * pData;
	int blk_size;
};

class CPEvtReportACStatusProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_REPORT_AC_STATUS;
	CPEvtReportACStatusProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_REPORT_AC_FAIL *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPEvtReportACStatusProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_REPORT_AC_FAIL * pData;
	int blk_size;
};

class CPEvtIB2RunProcess: public WLTxProcess
{
public:
	static const u8 MESSAGE_TYPE = MESSAGE_TYPE_EVT_RUN_IB2;
	CPEvtIB2RunProcess(const u8* msg_ptr, int msg_nb) 
	{
		pData = (_EVT_IB2_RUN *)msg_ptr;
		blk_size = msg_nb;
	}
	~CPEvtIB2RunProcess() { }

	int toJSONString(char* json_str, int json_nb);
private:
	_EVT_IB2_RUN * pData;
	int blk_size;
};

#endif
