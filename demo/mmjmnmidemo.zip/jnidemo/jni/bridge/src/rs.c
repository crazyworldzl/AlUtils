/*
 * Reed-Solomon coding and decoding
 * Phil Karn (karn at ka9q.ampr.org) September 1996
 * 
 * This file is derived from the program "new_rs_erasures.c" by Robert
 * Morelos-Zaragoza (robert at spectra.eng.hawaii.edu) and Hari Thirumoorthy
 * (harit at spectra.eng.hawaii.edu), Aug 1995
 *
 * I've made changes to improve performance, clean up the code and make it
 * easier to follow. Data is now passed to the encoding and decoding functions
 * through arguments rather than in global arrays. The decode function returns
 * the number of corrected symbols, or -1 if the word is uncorrectable.
 *
 * This code supports a symbol size from 2 bits up to 16 bits,
 * implying a block size of 3 2-bit symbols (6 bits) up to 65535
 * 16-bit symbols (1,048,560 bits). The code parameters are set in rs.h.
 *
 * Note that if symbols larger than 8 bits are used, the type of each
 * data array element switches from unsigned char to unsigned int. The
 * caller must ensure that elements larger than the symbol range are
 * not passed to the encoder or decoder.
 *
 */
#include <stdio.h>
#include "globdef.h"
#include "rs.h"

#if (KK >= NN)
#error "KK must be less than 2**MM - 1"
#endif

/* This defines the type used to store an element of the Galois Field
 * used by the code. Make sure this is something larger than a char if
 * if anything larger than GF(256) is used.
 *
 * Note: unsigned char will work up to GF(256) but int seems to run
 * faster on the Pentium.
 */
typedef unsigned char gf;

/* Alpha exponent for the first root of the generator polynomial */
#define B0  1

/* index->polynomial form conversion table */
//gf Alpha_to[NN + 1];
const gf Alpha_to[256] = {
    0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1d, 0x3a, 0x74, 0xe8, 0xcd, 0x87, 0x13, 0x26, 0x4c, 0x98, 0x2d, 0x5a, 0xb4, 0x75, 0xea, 0xc9,  
    0x8f, 0x03, 0x06, 0x0c, 0x18, 0x30, 0x60, 0xc0, 0x9d, 0x27, 0x4e, 0x9c, 0x25, 0x4a, 0x94, 0x35, 0x6a, 0xd4, 0xb5, 0x77, 0xee, 0xc1, 0x9f, 0x23,
    0x46, 0x8c, 0x05, 0x0a, 0x14, 0x28, 0x50, 0xa0, 0x5d, 0xba, 0x69, 0xd2, 0xb9, 0x6f, 0xde, 0xa1, 0x5f, 0xbe, 0x61, 0xc2, 0x99, 0x2f, 0x5e, 0xbc,
    0x65, 0xca, 0x89, 0x0f, 0x1e, 0x3c, 0x78, 0xf0, 0xfd, 0xe7, 0xd3, 0xbb, 0x6b, 0xd6, 0xb1, 0x7f, 0xfe, 0xe1, 0xdf, 0xa3, 0x5b, 0xb6, 0x71, 0xe2,
    0xd9, 0xaf, 0x43, 0x86, 0x11, 0x22, 0x44, 0x88, 0x0d, 0x1a, 0x34, 0x68, 0xd0, 0xbd, 0x67, 0xce, 0x81, 0x1f, 0x3e, 0x7c, 0xf8, 0xed, 0xc7, 0x93,
    0x3b, 0x76, 0xec, 0xc5, 0x97, 0x33, 0x66, 0xcc, 0x85, 0x17, 0x2e, 0x5c, 0xb8, 0x6d, 0xda, 0xa9, 0x4f, 0x9e, 0x21, 0x42, 0x84, 0x15, 0x2a, 0x54,
    0xa8, 0x4d, 0x9a, 0x29, 0x52, 0xa4, 0x55, 0xaa, 0x49, 0x92, 0x39, 0x72, 0xe4, 0xd5, 0xb7, 0x73, 0xe6, 0xd1, 0xbf, 0x63, 0xc6, 0x91, 0x3f, 0x7e,
    0xfc, 0xe5, 0xd7, 0xb3, 0x7b, 0xf6, 0xf1, 0xff, 0xe3, 0xdb, 0xab, 0x4b, 0x96, 0x31, 0x62, 0xc4, 0x95, 0x37, 0x6e, 0xdc, 0xa5, 0x57, 0xae, 0x41,
    0x82, 0x19, 0x32, 0x64, 0xc8, 0x8d, 0x07, 0x0e, 0x1c, 0x38, 0x70, 0xe0, 0xdd, 0xa7, 0x53, 0xa6, 0x51, 0xa2, 0x59, 0xb2, 0x79, 0xf2, 0xf9, 0xef,
    0xc3, 0x9b, 0x2b, 0x56, 0xac, 0x45, 0x8a, 0x09, 0x12, 0x24, 0x48, 0x90, 0x3d, 0x7a, 0xf4, 0xf5, 0xf7, 0xf3, 0xfb, 0xeb, 0xcb, 0x8b, 0x0b, 0x16,
    0x2c, 0x58, 0xb0, 0x7d, 0xfa, 0xe9, 0xcf, 0x83, 0x1b, 0x36, 0x6c, 0xd8, 0xad, 0x47, 0x8e, 0x00 };

/* Polynomial->index form conversion table */
//gf Index_of[NN + 1];
const gf Index_of[NN + 1] = {
    0xff, 0x00, 0x01, 0x19, 0x02, 0x32, 0x1a, 0xc6, 0x03, 0xdf, 0x33, 0xee, 0x1b, 0x68, 0xc7, 0x4b, 0x04, 0x64, 0xe0, 0x0e, 0x34, 0x8d, 0xef, 0x81,
    0x1c, 0xc1, 0x69, 0xf8, 0xc8, 0x08, 0x4c, 0x71, 0x05, 0x8a, 0x65, 0x2f, 0xe1, 0x24, 0x0f, 0x21, 0x35, 0x93, 0x8e, 0xda, 0xf0, 0x12, 0x82, 0x45,
    0x1d, 0xb5, 0xc2, 0x7d, 0x6a, 0x27, 0xf9, 0xb9, 0xc9, 0x9a, 0x09, 0x78, 0x4d, 0xe4, 0x72, 0xa6, 0x06, 0xbf, 0x8b, 0x62, 0x66, 0xdd, 0x30, 0xfd,  
    0xe2, 0x98, 0x25, 0xb3, 0x10, 0x91, 0x22, 0x88, 0x36, 0xd0, 0x94, 0xce, 0x8f, 0x96, 0xdb, 0xbd, 0xf1, 0xd2, 0x13, 0x5c, 0x83, 0x38, 0x46, 0x40,
    0x1e, 0x42, 0xb6, 0xa3, 0xc3, 0x48, 0x7e, 0x6e, 0x6b, 0x3a, 0x28, 0x54, 0xfa, 0x85, 0xba, 0x3d, 0xca, 0x5e, 0x9b, 0x9f, 0x0a, 0x15, 0x79, 0x2b,
    0x4e, 0xd4, 0xe5, 0xac, 0x73, 0xf3, 0xa7, 0x57, 0x07, 0x70, 0xc0, 0xf7, 0x8c, 0x80, 0x63, 0x0d, 0x67, 0x4a, 0xde, 0xed, 0x31, 0xc5, 0xfe, 0x18,  
    0xe3, 0xa5, 0x99, 0x77, 0x26, 0xb8, 0xb4, 0x7c, 0x11, 0x44, 0x92, 0xd9, 0x23, 0x20, 0x89, 0x2e, 0x37, 0x3f, 0xd1, 0x5b, 0x95, 0xbc, 0xcf, 0xcd,
    0x90, 0x87, 0x97, 0xb2, 0xdc, 0xfc, 0xbe, 0x61, 0xf2, 0x56, 0xd3, 0xab, 0x14, 0x2a, 0x5d, 0x9e, 0x84, 0x3c, 0x39, 0x53, 0x47, 0x6d, 0x41, 0xa2,
    0x1f, 0x2d, 0x43, 0xd8, 0xb7, 0x7b, 0xa4, 0x76, 0xc4, 0x17, 0x49, 0xec, 0x7f, 0x0c, 0x6f, 0xf6, 0x6c, 0xa1, 0x3b, 0x52, 0x29, 0x9d, 0x55, 0xaa,
    0xfb, 0x60, 0x86, 0xb1, 0xbb, 0xcc, 0x3e, 0x5a, 0xcb, 0x59, 0x5f, 0xb0, 0x9c, 0xa9, 0xa0, 0x51, 0x0b, 0xf5, 0x16, 0xeb, 0x7a, 0x75, 0x2c, 0xd7,  
    0x4f, 0xae, 0xd5, 0xe9, 0xe6, 0xe7, 0xad, 0xe8, 0x74, 0xd6, 0xf4, 0xea, 0xa8, 0x50, 0x58, 0xaf };

/* No legal value in index form represents zero, so
 * we need a special value for this purpose
 */
#define A0  (NN)

/* Generator polynomial g(x)
 * Degree of g(x) = 2*TT
 * has roots @**B0, @**(B0+1), ... ,@^(B0+2*TT-1)
 */
//gf Gg[NN - KK + 1];
gf Gg[NN - KK + 1] = {
   0x12, 0xfb, 0xd7, 0x1c, 0x50, 0x6b, 0xf8, 0x35, 0x54, 0xc2, 0x5b, 0x3b, 0xb0,
   0x63, 0xcb, 0x89, 0x2b, 0x68, 0x89, 0x00, 0x2c, 0x95, 0x94, 0xda, 0x4b, 0x0b,
   0xad, 0xfe, 0xc2, 0x6d, 0x08, 0x0b, 0x00 };




/* Compute x % NN, where NN is 2**MM - 1,
 * without a slow divide
 */
static inline gf
modnn(int x)
{
  while (x >= NN) {
    x -= NN;
    x = (x >> MM) + (x & NN);
  }
  return x;
}

#define  rs_min(a,b)  ((a) < (b) ? (a) : (b))

#define  CLEAR(a,n) {\
  int ci;\
  for(ci=(n)-1;ci >=0;ci--)\
    (a)[ci] = 0;\
  }

#define  COPY(a,b,n) {\
  int ci;\
  for(ci=(n)-1;ci >=0;ci--)\
    (a)[ci] = (b)[ci];\
  }
#define  COPYDOWN(a,b,n) {\
  int ci;\
  for(ci=(n)-1;ci >=0;ci--)\
    (a)[ci] = (b)[ci];\
  }

void init_rs(void)
{
  generate_gf();
  gen_poly();
}

/* generate GF(2**m) from the irreducible polynomial p(X) in p[0]..p[m]
   lookup tables:  index->polynomial form   alpha_to[] contains j=alpha**i;
                   polynomial form -> index form  index_of[j=alpha**i] = i
   alpha=2 is the primitive element of GF(2**m)
   HARI's COMMENT: (4/13/94) alpha_to[] can be used as follows:
        Let @ represent the primitive element commonly called "alpha" that
   is the root of the primitive polynomial p(x). Then in GF(2^m), for any
   0 <= i <= 2^m-2,
        @^i = a(0) + a(1) @ + a(2) @^2 + ... + a(m-1) @^(m-1)
   where the binary vector (a(0),a(1),a(2),...,a(m-1)) is the representation
   of the integer "alpha_to[i]" with a(0) being the LSB and a(m-1) the MSB. Thus for
   example the polynomial representation of @^5 would be given by the binary
   representation of the integer "alpha_to[5]".
                   Similarily, index_of[] can be used as follows:
        As above, let @ represent the primitive element of GF(2^m) that is
   the root of the primitive polynomial p(x). In order to find the power
   of @ (alpha) that has the polynomial representation
        a(0) + a(1) @ + a(2) @^2 + ... + a(m-1) @^(m-1)
   we consider the integer "i" whose binary representation with a(0) being LSB
   and a(m-1) MSB is (a(0),a(1),...,a(m-1)) and locate the entry
   "index_of[i]". Now, @^index_of[i] is that element whose polynomial 
    representation is (a(0),a(1),a(2),...,a(m-1)).
   NOTE:
        The element alpha_to[2^m-1] = 0 always signifying that the
   representation of "@^infinity" = 0 is (0,0,0,...,0).
        Similarily, the element index_of[0] = A0 always signifying
   that the power of alpha which has the polynomial representation
   (0,0,...,0) is "infinity".
 
*/

void
generate_gf(void)
{
/*
  register int i, mask;

  mask = 1;
  Alpha_to[MM] = 0;
  for (i = 0; i < MM; i++) {
    Alpha_to[i] = mask;
    Index_of[Alpha_to[i]] = i;
    // If Pp[i] == 1 then, term @^i occurs in poly-repr of @^MM 
    if (Pp[i] != 0)
      Alpha_to[MM] ^= mask;  // Bit-wise EXOR operation 
    mask <<= 1;  // single left-shift 
  }
  Index_of[Alpha_to[MM]] = MM;
  //
  // Have obtained poly-repr of @^MM. Poly-repr of @^(i+1) is given by
  // poly-repr of @^i shifted left one-bit and accounting for any @^MM
  // term that may occur when poly-repr of @^i is shifted.
  //
  mask >>= 1;
  for (i = MM + 1; i < NN; i++) {
    if (Alpha_to[i - 1] >= mask)
      Alpha_to[i] = Alpha_to[MM] ^ ((Alpha_to[i - 1] ^ mask) << 1);
    else
      Alpha_to[i] = Alpha_to[i - 1] << 1;
    Index_of[Alpha_to[i]] = i;
  }
  Index_of[0] = A0;
  Alpha_to[NN] = 0;
*/
}


/*
 * Obtain the generator polynomial of the TT-error correcting, length
 * NN=(2**MM -1) Reed Solomon code from the product of (X+@**(B0+i)), i = 0,
 * ... ,(2*TT-1)
 *
 * Examples:
 *
 * If B0 = 1, TT = 1. deg(g(x)) = 2*TT = 2.
 * g(x) = (x+@) (x+@**2)
 *
 * If B0 = 0, TT = 2. deg(g(x)) = 2*TT = 4.
 * g(x) = (x+1) (x+@) (x+@**2) (x+@**3)
 */
void
gen_poly(void)
{
/*
  register int i, j;

  Gg[0] = Alpha_to[B0];
  Gg[1] = 1;    // g(x) = (X+@**B0) initially 
  for (i = 2; i <= NN - KK; i++) {
    Gg[i] = 1;
    //
    // Below multiply (Gg[0]+Gg[1]*x + ... +Gg[i]x^i) by
    // (@**(B0+i-1) + x)
    //
    for (j = i - 1; j > 0; j--)
      if (Gg[j] != 0)
        Gg[j] = Gg[j - 1] ^ Alpha_to[modnn((Index_of[Gg[j]]) + B0 + i - 1)];
      else
        Gg[j] = Gg[j - 1];
    // Gg[0] can never be zero 
    Gg[0] = Alpha_to[modnn((Index_of[Gg[0]]) + B0 + i - 1)];
  }
  // convert Gg[] to index form for quicker encoding 
  for (i = 0; i <= NN - KK; i++)
    Gg[i] = Index_of[Gg[i]];
*/
}


/*
 * take the string of symbols in data[i], i=0..(k-1) and encode
 * systematically to produce NN-KK parity symbols in bb[0]..bb[NN-KK-1] data[]
 * is input and bb[] is output in polynomial form. Encoding is done by using
 * a feedback shift register with appropriate connections specified by the
 * elements of Gg[], which was generated above. Codeword is   c(X) =
 * data(X)*X**(NN-KK)+ b(X)
 */
int
encode_rs(dtype data[KK], dtype bb[NN-KK])
{
  register int i, j;
  gf feedback;

  CLEAR(bb,NN-KK);
  for (i = KK - 1; i >= 0; i--) {
#if (MM != 8)
    if(data[i] > NN)
      return -1;  /* Illegal symbol */
#endif
    feedback = Index_of[data[i] ^ bb[NN - KK - 1]];
    if (feedback != A0) {  /* feedback term is non-zero */
      for (j = NN - KK - 1; j > 0; j--)
        if (Gg[j] != A0)
          bb[j] = bb[j - 1] ^ Alpha_to[modnn(Gg[j] + feedback)];
        else
          bb[j] = bb[j - 1];
      bb[0] = Alpha_to[modnn(Gg[0] + feedback)];
    } else {  /* feedback term is zero. encoder becomes a
         * single-byte shifter */
      for (j = NN - KK - 1; j > 0; j--)
        bb[j] = bb[j - 1];
      bb[0] = 0;
    }
  }
  return 0;
}

/*
 * Performs ERRORS+ERASURES decoding of RS codes. If decoding is successful,
 * writes the codeword into data[] itself. Otherwise data[] is unaltered.
 *
 * Return number of symbols corrected, or -1 if codeword is illegal
 * or uncorrectable.
 * 
 * First "no_eras" erasures are declared by the calling program. Then, the
 * maximum # of errors correctable is t_after_eras = floor((NN-KK-no_eras)/2).
 * If the number of channel errors is not greater than "t_after_eras" the
 * transmitted codeword will be recovered. Details of algorithm can be found
 * in R. Blahut's "Theory ... of Error-Correcting Codes".
 */

static  gf u,q,tmp,num1,num2,den,discr_r;
static  gf recd[NN];
static  gf lambda[NN-KK + 1], s[NN-KK + 1];  /* Err+Eras Locator poly and syndrome poly */
static  gf b[NN-KK + 1], t[NN-KK + 1], omega[NN-KK + 1];
static  gf root[NN-KK], reg[NN-KK + 1], loc[NN-KK];


int
//eras_dec_rs(dtype data[NN], int eras_pos[NN-KK], int no_eras)
eras_dec_rs(dtype data[NN], char eras_pos[NN-KK], char no_eras)
{
  int deg_lambda, el, deg_omega;
  int i, j, r;
        /*
  gf u,q,tmp,num1,num2,den,discr_r;
  gf recd[NN];
  gf lambda[NN-KK + 1], s[NN-KK + 1];  // Err+Eras Locator poly and syndrome poly 
  gf b[NN-KK + 1], t[NN-KK + 1], omega[NN-KK + 1];
  gf root[NN-KK], reg[NN-KK + 1], loc[NN-KK];
        */
  int syn_error, count;

  /* data[] is in polynomial form, copy and convert to index form */
  for (i = NN-1; i >= 0; i--){
#if (MM != 8)
    if(data[i] > NN)
      return -1;  /* Illegal symbol */
#endif
    recd[i] = Index_of[data[i]];
  }
  /* first form the syndromes; i.e., evaluate recd(x) at roots of g(x)
   * namely @**(B0+i), i = 0, ... ,(NN-KK-1)
   */
  syn_error = 0;
  for (i = 1; i <= NN-KK; i++) {
    tmp = 0;
    for (j = 0; j < NN; j++)
      if (recd[j] != A0)  /* recd[j] in index form */
        tmp ^= Alpha_to[modnn(recd[j] + (B0+i-1)*j)];
    syn_error |= tmp;  /* set flag if non-zero syndrome =>
           * error */
    /* store syndrome in index form  */
    s[i] = Index_of[tmp];
  }
  if (!syn_error) {
    /*
     * if syndrome is zero, data[] is a codeword and there are no
     * errors to correct. So return data[] unmodified
     */
    return 0;
  }
  CLEAR(&lambda[1],NN-KK);
  lambda[0] = 1;
  if (no_eras > 0) {
    /* Init lambda to be the erasure locator polynomial */
    lambda[1] = Alpha_to[eras_pos[0]];
    for (i = 1; i < no_eras; i++) {
      u = eras_pos[i];
      for (j = i+1; j > 0; j--) {
        tmp = Index_of[lambda[j - 1]];
        if(tmp != A0)
          lambda[j] ^= Alpha_to[modnn(u + tmp)];
      }
    }
#ifdef ERASURE_DEBUG
    /* find roots of the erasure location polynomial */
    for(i=1;i<=no_eras;i++)
      reg[i] = Index_of[lambda[i]];
    count = 0;
    for (i = 1; i <= NN; i++) {
      q = 1;
      for (j = 1; j <= no_eras; j++)
        if (reg[j] != A0) {
          reg[j] = modnn(reg[j] + j);
          q ^= Alpha_to[reg[j]];
        }
      if (!q) {
        /* store root and error location
         * number indices
         */
        root[count] = i;
        loc[count] = NN - i;
        count++;
      }
    }
    if (count != no_eras) {
      printf("\n lambda(x) is WRONG\n");
      return -1;
    }
#ifndef NO_PRINT
    printf("\n Erasure positions as determined by roots of Eras Loc Poly:\n");
    for (i = 0; i < count; i++)
      printf("%d ", loc[i]);
    printf("\n");
#endif
#endif
  }
  for(i=0;i<NN-KK+1;i++)
    b[i] = Index_of[lambda[i]];

  /*
   * Begin Berlekamp-Massey algorithm to determine error+erasure
   * locator polynomial
   */
  r = no_eras;
  el = no_eras;
  while (++r <= NN-KK) {  /* r is the step number */
    /* Compute discrepancy at the r-th step in poly-form */
    discr_r = 0;
    for (i = 0; i < r; i++){
      if ((lambda[i] != 0) && (s[r - i] != A0)) {
        discr_r ^= Alpha_to[modnn(Index_of[lambda[i]] + s[r - i])];
      }
    }
    discr_r = Index_of[discr_r];  /* Index form */
    if (discr_r == A0) {
      /* 2 lines below: B(x) <-- x*B(x) */
      COPYDOWN(&b[1],b,NN-KK);
      b[0] = A0;
    } else {
      /* 7 lines below: T(x) <-- lambda(x) - discr_r*x*b(x) */
      t[0] = lambda[0];
      for (i = 0 ; i < NN-KK; i++) {
        if(b[i] != A0)
          t[i+1] = lambda[i+1] ^ Alpha_to[modnn(discr_r + b[i])];
        else
          t[i+1] = lambda[i+1];
      }
      if (2 * el <= r + no_eras - 1) {
        el = r + no_eras - el;
        /*
         * 2 lines below: B(x) <-- inv(discr_r) *
         * lambda(x)
         */
        for (i = 0; i <= NN-KK; i++)
          b[i] = (lambda[i] == 0) ? A0 : modnn(Index_of[lambda[i]] - discr_r + NN);
      } else {
        /* 2 lines below: B(x) <-- x*B(x) */
        COPYDOWN(&b[1],b,NN-KK);
        b[0] = A0;
      }
      COPY(lambda,t,NN-KK+1);
    }
  }

  /* Convert lambda to index form and compute deg(lambda(x)) */
  deg_lambda = 0;
  for(i=0;i<NN-KK+1;i++){
    lambda[i] = Index_of[lambda[i]];
    if(lambda[i] != A0)
      deg_lambda = i;
  }
  /*
   * Find roots of the error+erasure locator polynomial. By Chien
   * Search
   */
  COPY(&reg[1],&lambda[1],NN-KK);
  count = 0;    /* Number of roots of lambda(x) */
  for (i = 1; i <= NN; i++) {
    q = 1;
    for (j = deg_lambda; j > 0; j--)
      if (reg[j] != A0) {
        reg[j] = modnn(reg[j] + j);
        q ^= Alpha_to[reg[j]];
      }
    if (!q) {
      /* store root (index-form) and error location number */
      root[count] = i;
      loc[count] = NN - i;
      count++;
    }
  }

#ifdef DEBUG_RS
  printf("\n Final error positions:\t");
  for (i = 0; i < count; i++)
    printf("%d ", loc[i]);
  printf("\n");
#endif

  if (deg_lambda != count) {
    /*
     * deg(lambda) unequal to number of roots => uncorrectable
     * error detected
     */
    return -1;
  }
  /*
   * Compute err+eras evaluator poly omega(x) = s(x)*lambda(x) (modulo
   * x**(NN-KK)). in index form. Also find deg(omega).
   */
  deg_omega = 0;
  for (i = 0; i < NN-KK;i++){
    tmp = 0;
    j = (deg_lambda < i) ? deg_lambda : i;
    for(;j >= 0; j--){
      if ((s[i + 1 - j] != A0) && (lambda[j] != A0))
        tmp ^= Alpha_to[modnn(s[i + 1 - j] + lambda[j])];
    }
    if(tmp != 0)
      deg_omega = i;
    omega[i] = Index_of[tmp];
  }
  omega[NN-KK] = A0;

  /*
   * Compute error values in poly-form. num1 = omega(inv(X(l))), num2 =
   * inv(X(l))**(B0-1) and den = lambda_pr(inv(X(l))) all in poly-form
   */
  for (j = count-1; j >=0; j--) {
    num1 = 0;
    for (i = deg_omega; i >= 0; i--) {
      if (omega[i] != A0)
        num1  ^= Alpha_to[modnn(omega[i] + i * root[j])];
    }
    num2 = Alpha_to[modnn(root[j] * (B0 - 1) + NN)];
    den = 0;

    /* lambda[i+1] for i even is the formal derivative lambda_pr of lambda[i] */
    for (i = rs_min(deg_lambda,NN-KK-1) & ~1; i >= 0; i -=2) {
      if(lambda[i+1] != A0)
        den ^= Alpha_to[modnn(lambda[i+1] + i * root[j])];
    }
    if (den == 0) {
#ifdef DEBUG_RS
      printf("\n ERROR: denominator = 0\n");
#endif
      return -1;
    }
    /* Apply error to data */
    if (num1 != 0) {
      data[loc[j]] ^= Alpha_to[modnn(Index_of[num1] + Index_of[num2] + NN - Index_of[den])];
    }
  }
  return count;
}
