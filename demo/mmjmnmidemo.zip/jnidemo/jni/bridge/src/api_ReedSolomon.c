/***********************************************************************************
* Unit    : api_ReedSolomon 
* Layer   : API
*
* See api_ReedSolomon.h for details
*
* RSI - Laurent Battista
***********************************************************************************/


//#include <stdio.h>
#include <string.h>
#include "globdef.h"
#include "rs.h"
#include "api_ReedSolomon.h"
//---------------------------------------------------------------------------

/*******************************************************************************
* Unit's initialization: must be called at least once before using the         *
* functions of the unit.                                                       *
*******************************************************************************/
void API_InitReedSolomon(void)
{
  init_rs();
}

/*******************************************************************************
* Clear the Reed Solomon structure buffers pointed by rs.                      *
*******************************************************************************/
void ClearReedSolomon(TReedSolomonBuff *rs)
{
  memset(rs->CodeWord, 0, sizeof(rs->CodeWord));
  memset(rs->PosEras,  0, sizeof(rs->PosEras));
  rs->PosNumber = 0; // Don't forget to clear PosNumer if erasure recovery functionality is not used !
}

/*******************************************************************************
* Compute a Reed Solomon (255,223) code word.                                  *
* Input: pointer to the rs struct: <rs.data> array filled with datas to encode.*
* Output: <rs.CodeWord> array filled and ready to use.                         *
* Return value = -1 if MM define is wrong, else always 0.                      *
*******************************************************************************/
int EncodeReedSolomon(TReedSolomonBuff *rs)
{
  return encode_rs(rs->CodeWord, rs->CodeWord+KK);
}

/*******************************************************************************
* Decode a Reed Solomon (255, 223) Code Word and store the corrected values    *
* into data array.                                                             *
* Input: pointer to rs struct:                                                 *
*        - <rs.CodeWord> array filled with values to decode.                   *
*        - if needed, <rs.PosEras> array filled with know erasures positions.  *
*        - <PosNumber> value with the number erasures. IMPORTANT: Set the      *
*          erasures value to 0 if theres is no know erasures to correct.       *
* OutPut: <rs.data> array filled with corrected datas if possible.             *
* Return: 0 for no correction, all datas values are good, or                   *
*         Number of bytes corrected, all datas values are good, or             *
*         -1 for too many errors, datas are corrupted.                         *
*******************************************************************************/
int DecodeReedSolomon(TReedSolomonBuff *rs)
{
   return eras_dec_rs(rs->CodeWord, rs->PosEras, rs->PosNumber);
}

/****************************************************************************
* Block Interleaver.                                                        *
****************************************************************************/
void BufferInterleaving(char Buff[EDGE_SIZE][EDGE_SIZE])
{
int ix, iy;
char tmp;
   
      for (ix=0; ix<(EDGE_SIZE); ix++) {   // Pointage X de l'octet courant 
        for (iy=ix; iy<(EDGE_SIZE); iy++) { // Pointage Y de l'octet courant 
          tmp = Buff[iy][ix];       
          Buff[iy][ix] = Buff[ix][iy]; 
          Buff[ix][iy] = tmp;   // Pointage index de l'octet courant
        }
      } // End for iX
}

/****************************************************************************
* This embOS task wait an Q msg to decode Reed Solomon codes.               *
****************************************************************************/
void Task_RSCode(void)
{
/*
int i, status;

  InitReedSolomon();

  OS_Q_Create(&MemoryQ, &QMsg, sizeof(QMsg));

  ThisTime = BeforeTime = ThisBytesCnt = BeforeBytesCnt = 0;
  CodeWordCnt = CodeWordOK = CodeWordCorrected = CodeWordUncorrectable = ByteCorrected = 0;

  while (1) {

    // Awaiting a new message from radio receiver 
    Len = OS_Q_GetPtr(&MemoryQ, (void **)&pMsg);

    // Reed Solomon control and correct
    for (i=0; i<CODE_WORDS_PER_PACKET; i++) {

      memcpy(rsCodeWord, pMsg, sizeof(rsCodeWord));
      pMsg += sizeof(rsCodeWord);

      status = CtrlReedSolomon();
      switch (status) { 
        case -1 : CodeWordUncorrectable++; XLDebugAnswer("X", 1); break;
        case 0  : CodeWordOK++; XLDebugAnswer(".", 1); break;
        default : CodeWordCorrected++; ByteCorrected += status; XLDebugAnswer("c", 1); break;
      }

      // � revoir car il y a echange de donn�es sans synchronisation des taches 
      pcmStreamingWriteData(rsdata, sizeof(rsdata));
      CodeWordCnt++;

      if ((CodeWordCnt % 50) == 0) { // Display 50 chars take about 1 sec       
        XLDebugAnswer("\033[50D", 0); // Cursor backward every 50 chars
        XLDebugAnswer(SAVE_CURSOR,0);
        XLDebugAnswer(CURSOR_DOWN, 0);
        sprintf(disp, "Rx Bytes = %d, Corrected Bytes = %d, Codes Words lost = %d  \n", CodeWordCnt*255, ByteCorrected, CodeWordUncorrectable);
        XLDebugAnswer(disp,0);

        BeforeTime = ThisTime; ThisTime = OS_GetTime();
        BeforeBytesCnt = ThisBytesCnt; ThisBytesCnt = CodeWordCnt*233;
        DivRes = div(ThisBytesCnt-BeforeBytesCnt, 1024);
        sprintf(disp, "Data payload rate = %d.%d KiB/s", DivRes.quot, (DivRes.rem*100)/1024); 
        XLDebugAnswer(disp,0);
        XLDebugAnswer(UNSAVE_CURSOR, 0);
      }

    } // end for

    OS_Q_Purge(&MemoryQ);

  } // End While
*/

}
