#include <stdio.h>
#include <unistd.h>
#include "evlog.h"
#include "queues.h"
#include "WlMessageProcess.h"
#include "wlscom.h"
#include "commclient.h"
#include "WlStreamMessageProcess.h"

extern int reset_to_bootloader(DQueues& queues, type_run_mode mode);
extern int reset_to_application(DQueues& queues, type_run_mode mode);
int main(int argc, char* argv[])
{
	int c = 0;
	uint32_t force_reset_flag = 1;

	//log level control
	EvLog::instance().enable_level(EVL_ERROR);//default level
	
	for(c = 2; c < argc; c++){
		if((0 == strcmp(argv[c], "-d")) || (0 == strcmp(argv[c], "-D")) ){
			EvLog::instance().enable_level(EVL_INFO);
		}
	}

	//support  debug stream sniffer information
	WLVSStreamMngr::instance()->DebugEnable(false);;//default setting
	
	for(c = 2; c < argc; c++){
		if((0 == strcmp(argv[c], "-s")) || (0 == strcmp(argv[c], "-S")) ){
			WLVSStreamMngr::instance()->DebugEnable(true);
		}
	}

	//force reset configuration	
	for(c = 2; c < argc; c++){
		if((0 == strcmp(argv[c], "-nr")) || (0 == strcmp(argv[c], "-NR")) ){
			force_reset_flag = 0;
		}
	}

	
	//wiselink or IB2
	set_programmer_mode(For_Wiselink_Ap); //Default is for Wiselink AP
	
	for(c = 2; c < argc; c++){
		if((0 == strcmp(argv[c], "-e")) || (0 == strcmp(argv[c], "-E")) ){
			set_programmer_mode(For_IB2_AP); 
			fprintf(stdout, "===== bridge for IB2 =====\n");
		}
	}
        

	char* rx_queue_name = NULL;
	char* tx_queue_name = NULL;

	if (get_programmer_mode() == For_IB2_AP)
	{
		rx_queue_name = (char*)malloc(32);
		memset(rx_queue_name, 0, 32);

		tx_queue_name = (char*)malloc(32);
		memset(tx_queue_name, 0, 32);

		strcpy(rx_queue_name, IB2_RX_QUEUE_NAME);
		strcpy(tx_queue_name, IB2_TX_QUEUE_NAME);
	}


	DQueues dqueue(rx_queue_name, tx_queue_name);
	CommClientCtrl commClientCtrl(dqueue, "", 0, get_programmer_mode());
	WLScom wlscom(dqueue);
	
	if(1 == force_reset_flag){
		EvLog::instance().log_printf(EVL_INFO, "Will reset MCU....\n");
		reset_to_application(dqueue, get_programmer_mode());
		EvLog::instance().log_printf(EVL_INFO, "MCU reset and application started\n");
	}

	commClientCtrl.ResetSequence();

	if (argc == 1)
		wlscom.start("", 0);
	else 
		wlscom.start(argv[1], 0);
	commClientCtrl.stop_work_thread();

	if (rx_queue_name)
	{
		free(rx_queue_name);
		rx_queue_name = NULL;
	}

	if (tx_queue_name)
	{
		free(tx_queue_name);
		tx_queue_name = NULL;
	}

	while (1)
	{
		sleep(1000*1000);
	}

    return -1;

}

