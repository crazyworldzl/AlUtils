#include <stdio.h>
#include <stdlib.h>
#include <openssl/rand.h>
#include "globdef.h"
#include "cJSON.h"
#include "WlStreamMessageProcess.h"
#include "aes_defs.h"
#include "aes.h"
#include "aesalgo.h"
#include "utils.h"
#include "base64.h"

#define AES_IV_KEY_SIZE             16
#define NONCE_LENGTH 				12
#define RADIO_PACKET_LENGTH 		223
#define AES_BLOCKS_PER_RADIO_PACKET 14
void WLVSStreamMngr::StartStream(u8 device_addr, u8 encrypted_flag)
{
	ClearReedSolomon(&rs1);

	CorrectedSymboles = 0;
	IncorrectCodeWords = 0;
	BadCrcCnt =0;
	MissedPackets = 0;

	
	StreamPacketBufferIndex = 0;
	NbBytesInStreamPacketBuffer = 0;

	LastRadioPacketNumber = 0;
	ReadyFlg = 0;

	DeviceAddr = device_addr;
#ifdef SNIFFER_VS_DATA
	if (vsSniffer) vsSniffer->start();
#endif	
	SetDecrypto(encrypted_flag, LaterDecrypt_required, LaterDecrypt_Key, LaterDecrypt_IV);

}

void WLVSStreamMngr::StopStream(u8 device_addr)
{
	if (device_addr == DeviceAddr)
	{
		//cleanup
		DeviceAddr = 0;
#ifdef SNIFFER_VS_DATA		
		if (vsSniffer) vsSniffer->stop();
#endif
		DoDecrypt_required = 0;
		memset(DoDecrypt_Key, 0, sizeof(DoDecrypt_Key));
		memset(DoDecrypt_IV, 0, sizeof(DoDecrypt_IV));
	}
}

void WLVSStreamMngr::SetDecrypto(u8 encrypted_flag, u8 decrypt_required, u8 * decrypt_key, u8 * decrypt_iv)
{
	Encrypted_flag = encrypted_flag;
	DoDecrypt_required = decrypt_required;
	memcpy(DoDecrypt_Key, decrypt_key, sizeof(DoDecrypt_Key));
	memcpy(DoDecrypt_IV, decrypt_iv, sizeof(DoDecrypt_IV));
}

void WLVSStreamMngr::PrepareDecrypto(u8 decrypt_required, u8 * decrypt_key, u8 * decrypt_iv)
{
    u8* kk = LaterDecrypt_Key;
    u8* ii = LaterDecrypt_IV;

	LaterDecrypt_required = decrypt_required;
	memcpy(LaterDecrypt_Key, decrypt_key, sizeof(LaterDecrypt_Key));
	memcpy(LaterDecrypt_IV, decrypt_iv, sizeof(LaterDecrypt_IV));

    EvLog::instance().log_printf(EVL_ERROR, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
    EvLog::instance().log_printf(EVL_ERROR, "Key:(%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x), IV(%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x)\n\r",
                                           kk[0], kk[1], kk[2], kk[3], kk[4], kk[5], kk[6], kk[7], kk[8], kk[9], kk[10], kk[11], kk[12], kk[13], kk[14], kk[15],
                                           ii[0], ii[1], ii[2], ii[3], ii[4], ii[5], ii[6], ii[7], ii[8], ii[9], ii[10], ii[11], ii[12], ii[13], ii[14], ii[15]);

    EvLog::instance().log_printf(EVL_ERROR, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");

}

void WLVSStreamMngr::mergePackets(u8* streamPacket, u16 streamPacketLength, u16 blockNumber)
{
    
    EvLog::instance().log_printf(EVL_ERROR, "Stream got (%d)\n", blockNumber);
	if (sizeof(StreamPacketBuffer) - NbBytesInStreamPacketBuffer >= streamPacketLength)
	{
		if (StreamPacketBufferIndex == 0)
		{
			StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK)>>24)&0xFF;
			StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK)>>16)&0xFF;
			StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK)>>8)&0xFF;
			StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK))&0xFF;
		}

		if (blockNumber == 0)
		{
			memcpy(&StreamPacketBuffer[NbBytesInStreamPacketBuffer] , streamPacket, streamPacketLength);
			NbBytesInStreamPacketBuffer += streamPacketLength;
			StreamPacketBufferIndex++;
		}
		else if ((LastRadioPacketNumber + 1) != blockNumber){

			MissedPackets += (blockNumber - LastRadioPacketNumber - 1);
			EvLog::instance().log_printf(EVL_ERROR, "Missed packets(Total:%d), expected (%d), got (%d)\n", MissedPackets, LastRadioPacketNumber+1, blockNumber);

			
			if ((LastRadioPacketNumber + STREAMING_NB_RADIO_BLOCK_PER_FRAME - StreamPacketBufferIndex) < blockNumber)
			{
				//fill 0xff as missed data
				memset(&StreamPacketBuffer[NbBytesInStreamPacketBuffer], 0xFF, (STREAMING_NB_RADIO_BLOCK_PER_FRAME - StreamPacketBufferIndex)*STREAMING_NB_BYTES_PER_RADIO_BLOCK);

				memcpy(ReadyFrameBuffer, StreamPacketBuffer, STREAMING_MAX_BYTES_PER_FRAME);
				ReadyFlg = 1;

				NbBytesInStreamPacketBuffer = 0;
				StreamPacketBufferIndex = 0;
				StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK)>>24)&0xFF;
				StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK)>>16)&0xFF;
				StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK)>>8)&0xFF;
				StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK))&0xFF;
				memcpy(&StreamPacketBuffer[NbBytesInStreamPacketBuffer], streamPacket, streamPacketLength);
				NbBytesInStreamPacketBuffer += streamPacketLength;
				StreamPacketBufferIndex++;
			} else {
                /*
                if (blockNumber  < LastRadioPacketNumber)
                {
                    fprintf(stdout, "###############################################################\n");
                    //fill 0xff as missed data
    				memset(&StreamPacketBuffer[NbBytesInStreamPacketBuffer], 0xFF, (STREAMING_NB_RADIO_BLOCK_PER_FRAME - StreamPacketBufferIndex)*STREAMING_NB_BYTES_PER_RADIO_BLOCK);

    				memcpy(ReadyFrameBuffer, StreamPacketBuffer, STREAMING_MAX_BYTES_PER_FRAME);
    				ReadyFlg = 1;

    				NbBytesInStreamPacketBuffer = 0;
    				StreamPacketBufferIndex = 0;
    				StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK)>>24)&0xFF;
    				StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK)>>16)&0xFF;
    				StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK)>>8)&0xFF;
    				StreamPacketBuffer[NbBytesInStreamPacketBuffer++] = ((blockNumber*STREAMING_NB_BYTES_PER_RADIO_BLOCK))&0xFF;
    				memcpy(&StreamPacketBuffer[NbBytesInStreamPacketBuffer], streamPacket, streamPacketLength);
    				NbBytesInStreamPacketBuffer += streamPacketLength;
    				StreamPacketBufferIndex++;
                }
                else
                {
				*/
                    u8 NbBlockToStuff = blockNumber - (LastRadioPacketNumber + 1);
					if (NbBlockToStuff > (STREAMING_NB_RADIO_BLOCK_PER_FRAME - StreamPacketBufferIndex) )
						NbBlockToStuff = STREAMING_NB_RADIO_BLOCK_PER_FRAME - StreamPacketBufferIndex; 
                    //fill 0xff as missed data
                    memset(&StreamPacketBuffer[NbBytesInStreamPacketBuffer], 0xFF, NbBlockToStuff * STREAMING_NB_BYTES_PER_RADIO_BLOCK);
                    NbBytesInStreamPacketBuffer += NbBlockToStuff * STREAMING_NB_BYTES_PER_RADIO_BLOCK;
                    StreamPacketBufferIndex += NbBlockToStuff;
                    
					if (StreamPacketBufferIndex == STREAMING_NB_RADIO_BLOCK_PER_FRAME)
					{
						memcpy(ReadyFrameBuffer, StreamPacketBuffer, STREAMING_MAX_BYTES_PER_FRAME);
						ReadyFlg = 1;

						NbBytesInStreamPacketBuffer = 0;
						StreamPacketBufferIndex = 0;					
					}
                    memcpy(&StreamPacketBuffer[NbBytesInStreamPacketBuffer], streamPacket, streamPacketLength);
                    NbBytesInStreamPacketBuffer += streamPacketLength;
                    StreamPacketBufferIndex++;
                //}
			}
				
		} else {
			memcpy(&StreamPacketBuffer[NbBytesInStreamPacketBuffer], streamPacket, streamPacketLength);
			NbBytesInStreamPacketBuffer += streamPacketLength;
			StreamPacketBufferIndex++;
		}

		LastRadioPacketNumber = blockNumber;	
	}

	if (NbBytesInStreamPacketBuffer >= sizeof(StreamPacketBuffer))
	{
		memcpy(ReadyFrameBuffer, StreamPacketBuffer, STREAMING_MAX_BYTES_PER_FRAME);
		ReadyFlg = 1;

		NbBytesInStreamPacketBuffer = 0;
		StreamPacketBufferIndex = 0;
	}
}

void WLVSStreamMngr::Increment_IV(u8* iv_instance)
{
	u32 c = 0;
	c = ((iv_instance[12] << 24)|
		 (iv_instance[13] << 16)|
		 (iv_instance[14] << 8)|
		 (iv_instance[15]));
	c++;
	if (!c) c++;
	iv_instance[12] = (u8)((c >> 24)&0xff);
	iv_instance[13] = (u8) ((c >> 16)&0xff);
	iv_instance[14] = (u8) ((c >> 8)&0xff);
	iv_instance[15] = (u8) (c&0xff);
}

void WLVSStreamMngr::DecryptFrame()
{
 	aesCipherContext ctx_aes128;
	u8 *input;
	u8 *output;
	u8 crypto_block[AES_BLOCK_SIZE];
	u8 current_iv[AES_IV_KEY_SIZE];
	u32 total_len = sizeof(ReadyFrameBuffer)-4;

	ctx_aes128.Nr = aesKeySetupEnc(ctx_aes128.rk, DoDecrypt_Key, 128);
	
	input = ReadyFrameBuffer+4;
	output = ReadyFrameBuffer+4;

	memcpy(current_iv, DoDecrypt_IV, AES_IV_KEY_SIZE);
	
	u32 Offset = (ReadyFrameBuffer[0] << 24)|(ReadyFrameBuffer[1]<<16)|(ReadyFrameBuffer[2]<<8)|ReadyFrameBuffer[3];
	u32 BlockId = (Offset/RADIO_PACKET_LENGTH)*AES_BLOCKS_PER_RADIO_PACKET + 1;

	//we use last 4 bytes of IV as AES-CTR counter 
	current_iv[12] = (BlockId >> 24)&0xFF;
	current_iv[13] = (BlockId >> 16)&0xFF;
	current_iv[14] = (BlockId >> 8) &0xFF;
	current_iv[15] = (BlockId ) & 0xFF;

	while (total_len > 0)
	{
		u32 curr_len = total_len;
		u32 curr_blocks;
		if (curr_len > RADIO_PACKET_LENGTH)
			curr_len = RADIO_PACKET_LENGTH;
		total_len -= curr_len;
		curr_blocks = (curr_len + 15)/16;
		for (u32 i = curr_blocks; i > 0; i--)
		{
			aesEncrypt(ctx_aes128.rk, ctx_aes128.Nr, current_iv, crypto_block);
			Increment_IV(current_iv);
			for ( u32 j = 0; j < AES_BLOCK_SIZE;j++)
			{
				*output = *input ^ crypto_block[j];
				input++;
				output++;
				if (--curr_len == 0) break;
			}
		}
	}
}

void WLVSStreamMngr::DecryptFrameEx(u8 *pbuffer)
{
 	aesCipherContext ctx_aes128;
	u8 *input;
	u8 *output;
	u8 crypto_block[AES_BLOCK_SIZE];
	u8 current_iv[AES_IV_KEY_SIZE];
	u32 total_len = sizeof(ReadyFrameBuffer)-4;

	ctx_aes128.Nr = aesKeySetupEnc(ctx_aes128.rk, DoDecrypt_Key, 128);
	
	input = ReadyFrameBuffer+4;
	//output = ReadyFrameBuffer+4;
	memcpy(pbuffer, ReadyFrameBuffer, 4);
    output = pbuffer + 4;

	memcpy(current_iv, DoDecrypt_IV, AES_IV_KEY_SIZE);
	
	u32 Offset = (ReadyFrameBuffer[0] << 24)|(ReadyFrameBuffer[1]<<16)|(ReadyFrameBuffer[2]<<8)|ReadyFrameBuffer[3];
	u32 BlockId = (Offset/RADIO_PACKET_LENGTH)*AES_BLOCKS_PER_RADIO_PACKET + 1;

	//we use last 4 bytes of IV as AES-CTR counter 
	current_iv[12] = (BlockId >> 24)&0xFF;
	current_iv[13] = (BlockId >> 16)&0xFF;
	current_iv[14] = (BlockId >> 8) &0xFF;
	current_iv[15] = (BlockId ) & 0xFF;

	while (total_len > 0)
	{
		u32 curr_len = total_len;
		u32 curr_blocks;
		if (curr_len > RADIO_PACKET_LENGTH)
			curr_len = RADIO_PACKET_LENGTH;
		total_len -= curr_len;
		curr_blocks = (curr_len + 15)/16;
		for (u32 i = curr_blocks; i > 0; i--)
		{
			aesEncrypt(ctx_aes128.rk, ctx_aes128.Nr, current_iv, crypto_block);
			Increment_IV(current_iv);
			for ( u32 j = 0; j < AES_BLOCK_SIZE;j++)
			{
				*output = *input ^ crypto_block[j];
				input++;
				output++;
				if (--curr_len == 0) break;
			}
		}
	}
}

u16 WLVSStreamMngr::GetAvailableFrameData(u8** frame_pptr)
{
	u16 len = 0;
    u8 buffer[STREAMING_MAX_BYTES_PER_FRAME + 10];
    
	if (ReadyFlg == 1) 		//one frame is ready
	{
		if (DoDecrypt_required)
		{
			DecryptFrame();
		}
        
		if (Encrypted_flag && !DoDecrypt_required)
		{
			*frame_pptr = ReadyFrameBuffer;
			len = STREAMING_MAX_BYTES_PER_FRAME;
            
            #ifdef SNIFFER_VS_DATA
            DecryptFrameEx(buffer);//do decrypt to save streaming data.
		    if (vsSniffer)vsSniffer->OneFrameGot(buffer + 4, len - 4);
            #endif
		}
		else
		{
			*frame_pptr = ReadyFrameBuffer;
			len = STREAMING_MAX_BYTES_PER_FRAME;

            #ifdef SNIFFER_VS_DATA
		    if (vsSniffer)vsSniffer->OneFrameGot(*frame_pptr + 4, len - 4);
            #endif
		}
		
		ReadyFlg = 0;
		
		return len;
	} else {
		return 0;
	}
}

void WLVSStreamMngr:: DebugEnable(bool flag)
{
    if (flag == true)
    {
		vsSniffer = new VSFramesSniffer2File("/run/wiselink/vs_stream.h264");
    }
    else
    {
        vsSniffer = NULL;
    }
}

void WLVSStreamMngr::PushStreamData(u8 device_addr, TWS_FHSS_Packet * pWSPacket)
{

	if ( device_addr != DeviceAddr ) return;
	
	u16 block_number = (pWSPacket->header.BlockNumber_msb<<8) + pWSPacket->header.BlockNumber_lsb;


	BufferInterleaving((char(*)[EDGE_SIZE])pWSPacket->Buffer);
	pWSPacket->header.fInterLeaving = 0;
	memcpy(rs1.CodeWord, pWSPacket->Buffer, sizeof(rs1.CodeWord));
	int status = DecodeReedSolomon(&rs1);
	if (status == -1) {
		IncorrectCodeWords++;
	} else {
		CorrectedSymboles += status;
	}	
	//crc check
	pWSPacket->header.fCRC_Status = 1;
	if (pWSPacket->header.fCRC_Enabled)
	{
		pWSPacket->header.fCRC_Status = 1;
		u16 Crc = ccitt_crc16(rs1.Data, sizeof(rs1.Data), CRC16_CCITT_FFFF);
		if (Crc != (pWSPacket->header.CRC_msb<<8) + pWSPacket->header.CRC_lsb) {
			pWSPacket->header.fCRC_Status = 0;
			BadCrcCnt++;
		}
	}

	if (status == -1 || pWSPacket->header.fCRC_Status == 0)
	{
		EvLog::instance().log_printf(EVL_ERROR, "Got one frame: blockid(%d)-siteID(%x-%x), IncorrectCodeWords(%d), BadCrcCnt(%d)\n", block_number, pWSPacket->header.SiteID_lsb, pWSPacket->header.SiteID_msb, IncorrectCodeWords, BadCrcCnt);
	}
	
	mergePackets(rs1.Data, sizeof(rs1.Data), block_number);
}


int WLTxVSStartResponse::toJSONString(char* json_str, int json_nb)
{   
    int code;
    cJSON* root = cJSON_CreateObject();
    if (!root){ return 0; }
    
    EvLog::instance().log_printf(EVL_INFO, "WLTxVSStartResponse: dev:%d, code:%d\n", 
                vs_start_response_msg->address.address_space.index, vs_start_response_msg->status);


	WLVSStreamMngr::instance()->StartStream(vs_start_response_msg->address.address_space.index,
											vs_start_response_msg->status == VS_STARTED_DELAYED_CRYPTO_STREAMING? 1:0);	
    cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
    cJSON_AddNumberToObject(root, "Device", vs_start_response_msg->address.address_space.index);
    cJSON_AddNumberToObject(root, "Code", vs_start_response_msg->status);
    
    char* JsonChar = cJSON_Print(root);
    if (!JsonChar)
    {
        cJSON_Delete(root);
        return 0;
    }
    
    int size = strlen(JsonChar);

    if ( size < json_nb)
    {
        strncpy(json_str, JsonChar, json_nb);
    }
    else
    {
        size = 0;
    }
    
    free(JsonChar);
    cJSON_Delete(root);
    return size;

}

int WLTxVSStopResponse::toJSONString(char* json_str, int json_nb)
{
    cJSON* root = cJSON_CreateObject();
    if (!root){ return 0; }
    
    EvLog::instance().log_printf(EVL_INFO, "WLTxVSStopResponse: dev:%d, code:%d\n", 
                vs_stop_response_msg->address.address_space.index, vs_stop_response_msg->status);

	//if (vs_stop_response_msg->status == VS_STOPPED)
	//{
	WLVSStreamMngr::instance()->StopStream(vs_stop_response_msg->address.address_space.index);
    
    cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
    cJSON_AddNumberToObject(root, "Device", vs_stop_response_msg->address.address_space.index);        
    cJSON_AddNumberToObject(root, "Code", vs_stop_response_msg->status);
    
    char* JsonChar = cJSON_Print(root);
    if (!JsonChar)
    {
        cJSON_Delete(root);
        return 0;
    }
    
    int size = strlen(JsonChar);

    if ( size < json_nb)
    {
        strncpy(json_str, JsonChar, json_nb);
    }
    else 
    {
        size = 0;
    }
    
    free(JsonChar);
    cJSON_Delete(root);
    return size;
	//}

    //return 0;
}

int WLTxVSStreamData::toJSONString(char* json_str, int json_nb)
{
	u8* frame_data_ptr;
	u16 len;
    u8 *pBase64In;
    u8 *pBase64Out;
    u32 inLength;
    u32 outLength;
    u32 blockID;
    u32 offset;
    
    Base64 base64;
    cJSON* root = cJSON_CreateObject();
    if (!root){ return 0; }
        
	WLVSStreamMngr::instance()->PushStreamData(vs_data_msg->device_addr.address_space.index, &vs_data_msg->video_data);
	len = WLVSStreamMngr::instance()->GetAvailableFrameData(&frame_data_ptr);
    
	if (len) 
    {
        cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
        cJSON_AddNumberToObject(root, "Device", WLVSStreamMngr::instance()->GetDevAddr());        

        //blockID = ((frame_data_ptr[0] << 24)| (frame_data_ptr[1] << 16) | (frame_data_ptr[2] << 8) | (frame_data_ptr[3] << 0)) / 223;

        offset = (frame_data_ptr[0] << 24)| (frame_data_ptr[1] << 16) | (frame_data_ptr[2] << 8) | (frame_data_ptr[3] << 0);
        blockID = (offset / RADIO_PACKET_LENGTH) * AES_BLOCKS_PER_RADIO_PACKET + 1;
        
        cJSON_AddNumberToObject(root, "BlockID", blockID);  

        inLength = len - 4;        
        pBase64In = frame_data_ptr + 4;
        
        pBase64Out = new u8[inLength * 2];
        if (!pBase64Out)
        {
            cJSON_Delete(root);
            return 0;
        }
        
        outLength = inLength * 2;
        memset(pBase64Out, 0, outLength);
        
        //convert base64
        base64.Encode((const char *)pBase64In, inLength,(char * )pBase64Out, outLength);
        len = strlen((const char *)pBase64Out);
        
        EvLog::instance().log_printf(EVL_INFO, "Stream Base64 in:%d, out:%d\r\n", inLength, outLength);
        
        cJSON_AddNumberToObject(root, "Length", len);
        cJSON_AddStringToObject(root, "Data", (const char *)pBase64Out);
        
        delete pBase64Out;
	} 
    else 
	{
        //EvLog::instance().log_printf(EVL_INFO, "WLTxVSStreamData not available data!\r\n", inLength, outLength);
        cJSON_Delete(root);
		return 0;
	}

    char* JsonChar = cJSON_Print(root);
    if (!JsonChar)
    {
        cJSON_Delete(root);
        return 0;
    }
    
    int size = strlen(JsonChar);

    if ( size < json_nb)
    {
        strncpy(json_str, JsonChar, json_nb);
    }
    else
    {
        size = 0;
    } 
    
    free(JsonChar);
    cJSON_Delete(root);

    return size;   
}

void WLStreamingStartProcess::process(cJSON* root)
{
    _REQUEST_STREAMING msg;

	u8 auto_mode = 1;
	cJSON* jDevAddr = cJSON_GetObjectItem(root, "Addr");
	cJSON* jCryptoMode = cJSON_GetObjectItem(root, "CryptoMode");
	cJSON* jDuration = cJSON_GetObjectItem(root, "Duration");
	if (!jDevAddr || jDevAddr->type != cJSON_Number)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}
	if (jCryptoMode && jCryptoMode->type == cJSON_Number)
	{
		auto_mode = 0;
	}
    

	msg.duration = 0; //forever is default
	if (auto_mode == 1) //if application doesn't specify crypto, we auto crypto stream, and decrypt frame on wiselink bridge
	{
		msg.security_type = 1;
		//generate random KEY and IV
		if ( 1 != RAND_bytes(msg.key, sizeof(msg.key)))
		{
			//it's unlikely to enter here
			RAND_pseudo_bytes(msg.key, sizeof(msg.key));
		}
		if ( 1 != RAND_bytes(msg.iv, sizeof(msg.iv)))
		{
			RAND_pseudo_bytes(msg.iv, sizeof(msg.iv));
		}
		WLVSStreamMngr::instance()->PrepareDecrypto(msg.security_type, msg.key, msg.iv);
	} else {
		//if application specify, we pass streaming with raw data
		msg.security_type = jCryptoMode->valueint? 1:0;
		//parse key and iv
		cJSON* jKey = cJSON_GetObjectItem(root, "CryptoKey");
		cJSON* jIV = cJSON_GetObjectItem(root, "NonceKey");
		if (jKey && jIV && jKey->type == cJSON_String && jIV->type == cJSON_String)
		{
			convertstring2hex(jKey->valuestring, msg.key, sizeof(msg.key));
			convertstring2hex(jIV->valuestring, msg.iv, sizeof(msg.iv));
			WLVSStreamMngr::instance()->PrepareDecrypto(0, msg.key, msg.iv);
		} else if (!jKey && !jIV && msg.security_type == 1) {
			//generate random KEY and IV
			if ( 1 != RAND_bytes(msg.key, sizeof(msg.key)))
			{
				//it's unlikely to enter here
				RAND_pseudo_bytes(msg.key, sizeof(msg.key));
			}
			if ( 1 != RAND_bytes(msg.iv, sizeof(msg.iv)))
			{
				RAND_pseudo_bytes(msg.iv, sizeof(msg.iv));
			}
			WLVSStreamMngr::instance()->PrepareDecrypto(msg.security_type, msg.key, msg.iv);	
		}
		else{

			memset(msg.key, 0, sizeof(msg.key));
			memset(msg.iv, 0, sizeof(msg.iv));
			WLVSStreamMngr::instance()->PrepareDecrypto(0, msg.key, msg.iv);		
		}

	}
	if (jDuration && jDuration->type == cJSON_Number)
	{
		u8 duration = (u8) jDuration->valueint;
		if (duration >= 3 && duration <= (1800/10)) //from 30 seconds ~ 30 min
			msg.duration = duration;
	}

    //
	msg.msg_id = E_DBGP_APP_SET_DEVICE_STREAMING_REQ;
	msg.address.address_type = ADDRESS_INDEX;
	msg.address.address_space.index = jDevAddr->valueint;
	msg.start_stop = START;
	//msg.security_type = jsonCryptoMode->valueint;

	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));

}

void WLStreamingStopProcess::process(cJSON* root)
{

    cJSON* jsonAddr = cJSON_GetObjectItem(root, "Addr");
	cJSON* jsonoption = cJSON_GetObjectItem(root, "option");

	if ( (!jsonAddr || jsonAddr->type != cJSON_Number) || (!jsonoption || jsonoption->type != cJSON_Number) )
    {
        //parse error
        EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed\n");
        return;
    }
	
	
    EvLog::instance().log_printf(EVL_ERROR, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Recv WLStreamingStopProcess \n");
	_REQUEST_STREAMING msg;
	msg.msg_id = E_DBGP_APP_SET_DEVICE_STREAMING_REQ;
	msg.address.address_type = ADDRESS_INDEX;
	msg.address.address_space.index = jsonAddr->valueint;
	msg.start_stop = STOP;

	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}

