#ifndef ANDROID_MService_H
#define ANDROID_MService_H
 
#include <utils/RefBase.h>
#include <binder/IInterface.h>
#include <binder/Parcel.h>
 
namespace android
{
    class MService : public BBinder
    {
    private:
        //mutable Mutex m_Lock;
        //int32_t m_NextConnId;
 
    public:
        static int Instance();
        MService();
        virtual ~MService();
        virtual status_t onTransact(uint32_t, const Parcel&, Parcel*, uint32_t);
    };
}
 
#endif
