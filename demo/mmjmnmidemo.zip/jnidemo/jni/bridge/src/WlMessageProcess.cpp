#include <stdio.h>
#include <stdlib.h>
#include "globdef.h"
#include "cJSON.h"
#include "evlog.h"
#include "WlMessageProcess.h"
#include "WlStreamMessageProcess.h"
#include "base64.h"

#ifndef _RELEASE_
#include <assert.h>
#else
#define assert(...)
#endif


typedef struct {
	u8 long_frame_change;
	u8 short_frame_count;
	u8 short_frame_total;
} SENSITIVITY_SUPERVISION;

static SENSITIVITY_SUPERVISION sen = {0,0,0};
static SENSITIVITY_SUPERVISION sup = {0,0,0};

extern void DeNibble(u8 ch, u8 * p1, u8 * p2);
extern void ConvertHex2String(u8 * in_ptr, u16 in_length, u8 * out_ptr, u16 out_length);
extern u8 Nibble(char ch);
extern int ConvertString2Hex(const char* hexStr, u8* hexDat, int len);





static void UpdateNumber(SENSITIVITY_SUPERVISION * ptr, u16 array_size)
{
	ptr->long_frame_change = 1;
	ptr->short_frame_count = 0;
	ptr->short_frame_total = array_size;
	printf("UpdataNumber: frame change %d, frame count %d, frame total %d\n", ptr->long_frame_change,ptr->short_frame_count,ptr->short_frame_total);
}

static u8 CheckNumber(SENSITIVITY_SUPERVISION * ptr)
{
	if( ptr->long_frame_change == 1){
		ptr->long_frame_change = 0;
		ptr->short_frame_count = 1;
		printf("UpdataNumber: frame change %d, frame count %d, frame total %d\n", ptr->long_frame_change,ptr->short_frame_count,ptr->short_frame_total);
	}else{
		ptr->short_frame_count ++;
		printf("UpdataNumber: frame change %d, frame count %d, frame total %d\n", ptr->long_frame_change,ptr->short_frame_count,ptr->short_frame_total);
	}
	if(ptr->short_frame_count == ptr->short_frame_total){
		ptr->long_frame_change = 0;
		ptr->short_frame_count = 0;
		ptr->short_frame_total = 0;
		printf("UpdataNumber: frame change %d, frame count %d, frame total %d\n", ptr->long_frame_change,ptr->short_frame_count,ptr->short_frame_total);
		return 1;
	}else{
		printf("UpdataNumber: frame change %d, frame count %d, frame total %d\n", ptr->long_frame_change,ptr->short_frame_count,ptr->short_frame_total);
		return 0;
	}
}

WLRxProcess & (*WLJsonStreamProcessor::createlist[])(WLScom&) =
{
	WLRxVersionProcess::CREATE,
    WLRxEnrollProcess::CREATE,
    WLRxRemoveProcess::CREATE,
    WLRxArmDevicesProcess::CREATE,
    WLRxDisarmDevicesProcess::CREATE,
	WLRxQuerySiteIDProcess::CREATE,
	WLRxQueryDevicesInfoProcess::CREATE,
    WLRxSetSiteIDProcess::CREATE,
    WLRxSetDevicesInfoProcess::CREATE,
	WLRxRangeTestProcess::CREATE,
	WLRxControlLedProcess::CREATE,
	WLRxSetRadioCyclicityProcess::CREATE,
	WLRxRequestPStatProcess::CREATE,
	WLRxRequestMaintanceProcess::CREATE,
	WLRxRequestMonitorProcess::CREATE,
    WLRxConfigVideoProcess::CREATE,
    WLRxGetVideoClipProcess::CREATE,
    WLRxGetVideoSnapshotProcess::CREATE,
    WLRxQueryDeviceSensitivityProcess::CREATE,
    WLRxSetDeviceSensitivityProcess::CREATE,
    WLRxSetDeviceSupervisionProcess::CREATE,
    WLStreamingStartProcess::CREATE,
    WLStreamingStopProcess::CREATE,

	/* for ib2 co-processor*/
	CPSetZoneConfigProcess::CREATE,
	CPSetFireConfigProcess::CREATE,
	CPSetSirenConfigProcess::CREATE,
	CPSetTriggerConfigProcess::CREATE,
	CPSetAuxenConfigProcess::CREATE,
	CPSetAcConfigProcess::CREATE,
	
	CPGetBatteryACProcess::CREATE,
	CPGetAUXProcess::CREATE,
	CPGetEX_LTE_WIFIProcess::CREATE,
	
	CPSetIB2DownloadFrameProcess::CREATE,

	CPSetIB2RunProcess::CREATE,
	HQProcess::CREATE,
	//Todo
	NULL,

};

WLRxProcess& WLRxVersionProcess::CREATE(WLScom& wlscom) { return *new WLRxVersionProcess(wlscom); }
WLRxProcess& WLRxEnrollProcess::CREATE(WLScom& wlscom)  { return *new WLRxEnrollProcess(wlscom); }
WLRxProcess& WLRxRemoveProcess::CREATE(WLScom& wlscom) { return *new WLRxRemoveProcess(wlscom); }
WLRxProcess& WLRxArmDevicesProcess::CREATE(WLScom& wlscom) { return *new WLRxArmDevicesProcess(wlscom); }
WLRxProcess& WLRxDisarmDevicesProcess::CREATE(WLScom& wlscom) { return *new WLRxDisarmDevicesProcess(wlscom); }
WLRxProcess& WLRxQueryDevicesInfoProcess::CREATE(WLScom& wlscom) { return *new WLRxQueryDevicesInfoProcess(wlscom); }
WLRxProcess& WLRxQuerySiteIDProcess::CREATE(WLScom & wlscom) { return *new WLRxQuerySiteIDProcess(wlscom) ; }
WLRxProcess& WLRxSetSiteIDProcess::CREATE(WLScom& wlscom) { return *new WLRxSetSiteIDProcess(wlscom); }
WLRxProcess& WLRxSetDevicesInfoProcess::CREATE(WLScom& wlscom) { return *new WLRxSetDevicesInfoProcess(wlscom); }
WLRxProcess& WLRxRangeTestProcess::CREATE(WLScom& wlscom) { return *new WLRxRangeTestProcess(wlscom); }
WLRxProcess& WLRxControlLedProcess::CREATE(WLScom& wlscom) { return *new WLRxControlLedProcess(wlscom); }
WLRxProcess& WLRxSetRadioCyclicityProcess::CREATE(WLScom& wlscom) { return *new WLRxSetRadioCyclicityProcess(wlscom); }
WLRxProcess& WLRxRequestPStatProcess::CREATE(WLScom& wlscom) { return *new WLRxRequestPStatProcess(wlscom); }
WLRxProcess& WLRxRequestMaintanceProcess::CREATE(WLScom& wlscom) { return *new WLRxRequestMaintanceProcess(wlscom); }
WLRxProcess& WLRxRequestMonitorProcess::CREATE(WLScom& wlscom) { return *new WLRxRequestMonitorProcess(wlscom); }
WLRxProcess& WLRxConfigVideoProcess::CREATE(WLScom& wlscom) { return *new WLRxConfigVideoProcess(wlscom); }
WLRxProcess& WLRxGetVideoClipProcess::CREATE(WLScom& wlscom) { return *new WLRxGetVideoClipProcess(wlscom); }
WLRxProcess& WLRxGetVideoSnapshotProcess::CREATE(WLScom& wlscom) { return *new WLRxGetVideoSnapshotProcess(wlscom); }
WLRxProcess& WLRxQueryDeviceSensitivityProcess::CREATE(WLScom& wlscom) { return *new WLRxQueryDeviceSensitivityProcess(wlscom); }
WLRxProcess& WLRxSetDeviceSensitivityProcess::CREATE(WLScom& wlscom) { return *new WLRxSetDeviceSensitivityProcess(wlscom); }
WLRxProcess& WLRxSetDeviceSupervisionProcess::CREATE(WLScom& wlscom) { return *new WLRxSetDeviceSupervisionProcess(wlscom); }
WLRxProcess& WLStreamingStartProcess::CREATE(WLScom& wlscom) {return *new WLStreamingStartProcess(wlscom); }
WLRxProcess& WLStreamingStopProcess::CREATE(WLScom& wlscom) {return *new WLStreamingStopProcess(wlscom); }

/* for ib2 co-processor*/
WLRxProcess& CPSetZoneConfigProcess::CREATE(WLScom& wlscom) { return *new CPSetZoneConfigProcess(wlscom); }
WLRxProcess& CPSetFireConfigProcess::CREATE(WLScom& wlscom) { return *new CPSetFireConfigProcess(wlscom); }
WLRxProcess& CPSetSirenConfigProcess::CREATE(WLScom& wlscom) { return *new CPSetSirenConfigProcess(wlscom); }
WLRxProcess& CPSetTriggerConfigProcess::CREATE(WLScom& wlscom) { return *new CPSetTriggerConfigProcess(wlscom); }
WLRxProcess& CPSetAuxenConfigProcess::CREATE(WLScom& wlscom) { return *new CPSetAuxenConfigProcess(wlscom); }
WLRxProcess& CPSetAcConfigProcess::CREATE(WLScom& wlscom) { return *new CPSetAcConfigProcess(wlscom); }

WLRxProcess& CPGetBatteryACProcess::CREATE(WLScom& wlscom) { return *new CPGetBatteryACProcess(wlscom); }
WLRxProcess& CPGetAUXProcess::CREATE(WLScom& wlscom) { return *new CPGetAUXProcess(wlscom); }
WLRxProcess& CPGetEX_LTE_WIFIProcess::CREATE(WLScom& wlscom) { return *new CPGetEX_LTE_WIFIProcess(wlscom); }

WLRxProcess& CPSetIB2DownloadFrameProcess::CREATE(WLScom& wlscom) { return *new CPSetIB2DownloadFrameProcess(wlscom); }

WLRxProcess& CPSetIB2RunProcess::CREATE(WLScom& wlscom) { return *new CPSetIB2RunProcess(wlscom); }
WLRxProcess& HQProcess::CREATE(WLScom& wlscom){return *new HQProcess(wlscom);}



void WLRxProcess::do_start_run()
{
	if (!_b_started_run)
	{
		_b_started_run =true;
		_RUN_MODE_MSG msg;
		msg.msg_id = E_DBGP_APP_SET_RUN_MODE;
		msg.mode = 1; //run normal
		_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
	}
}
void HQProcess::process(cJSON* root){
	_b_started_run =true;
		_RUN_MODE_MSG msg;
		msg.msg_id = E_DBGP_APP_SET_RUN_MODE;
		msg.mode = 1; //run normal
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));

}
void WLRxVersionProcess::process(cJSON* root)
{
	_GET_BOARD_VERSION_MSG msg;
	msg.msg_id = E_DBGP_APP_GET_BOARD_VERSION;
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}

void WLRxQueryDevicesInfoProcess::process(cJSON* root)
{
	_REQUEST_DEVICE_INFO_STATUS_MSG msg;
	msg.msg_id = E_DBGP_APP_SET_UPLOAD_DEVICE_INFO;
	msg.address.address_type = ADDRESS_INDEX;
	msg.address.address_space.index = 0xff;
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}

void WLRxQuerySiteIDProcess::process(cJSON* root)
{
	_GET_SITEID_MSG msg;
	msg.msg_id = E_DBGP_APP_GET_SITE_ADDRESS;
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
	
}

void WLRxSetSiteIDProcess::process(cJSON* root)
{
	u16 len = 0;
	cJSON* jsonItem = cJSON_GetObjectItem(root, "SiteID");	
	if (jsonItem && jsonItem->type  == cJSON_String)
	{
		_SET_SITEID_MSG msg;
		msg.msg_id = E_DBGP_APP_SET_SITE_ADDRESS;
		msg.length = ConvertString2Hex(jsonItem->valuestring, msg.site_id, sizeof(msg.site_id));
			
		len = (sizeof(msg.msg_id) + sizeof(msg.length) + msg.length);
		
		_wlscom.put_tx_msg((const u8*)&msg, len);
		
		EvLog::instance().log_printf(EVL_INFO, "SetSiteID JSON -> Tx Msg\n");			
		
	} else {
		EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [SiteID] failed %s:%d\n", __FILE__, __LINE__);
	}
}

void WLRxSetDevicesInfoProcess::process(cJSON* root)
{
	cJSON* jsonArray = cJSON_GetObjectItem(root, "ADeviceList");	
	if (jsonArray && jsonArray->type == cJSON_Array)
	{
		int arraySize = cJSON_GetArraySize(jsonArray);
		printf("Set info array size %02x\n",arraySize);
		//assert(arraySize > 0);
		if (arraySize <= 0)  return; //we don't push to blackbox because there' no items in databse
        EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [CycleValue] msgSize=%d   %s:%d\n", arraySize ,__FILE__, __LINE__);




        _SET_DEVICES_INFO_MSG msg;

		for (int i  = 0; i < arraySize; i++)
		{
			
			msg.msg_id = E_DBGP_APP_SET_DEVICE_INFO;

			
			cJSON* obj = cJSON_GetArrayItem(jsonArray, i);
			
			if (obj && obj->type == cJSON_Object)
			{
				cJSON* a = cJSON_GetObjectItem(obj,"Addr");
				
				if (a && a->type == cJSON_Number){
					msg.device.address.address_type = ADDRESS_INDEX;
					msg.device.address.address_space.index = a->valueint;
				}else{					
					EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Addr] failed %s:%d\n", __FILE__, __LINE__);
				}
				
				a = cJSON_GetObjectItem(obj, "Type");
				//assert(a && a->type == cJSON_Number);
				if (a && a->type == cJSON_Number)
					msg.device.type = a->valueint;
				else
					EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Type] failed %s:%d\n", __FILE__, __LINE__);
					
				
				a = cJSON_GetObjectItem(obj, "CycleValue");
				//assert(a && a->type == cJSON_Number);
				if (a && a->type == cJSON_Number)
					msg.device.cycle_value = a->valueint;
				else
					EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [CycleValue] failed %s:%d\n", __FILE__, __LINE__);
					
				a = cJSON_GetObjectItem(obj, "FastCycleAllowed");
				//assert(a && a->type == cJSON_Number);
				if (a && a->type == cJSON_Number)
					msg.device.fastcycleallowed_flag = a->valueint;
				else
					EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [FastCycleAllowed] failed %s:%d\n", __FILE__, __LINE__);
	
				a = cJSON_GetObjectItem(obj, "SerialNumber");
				if (a && a->type == cJSON_String)
				{
					ConvertString2Hex(a->valuestring, msg.device.serialnumber, sizeof(msg.device.serialnumber));
				} else {
					EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [SerialNumber] failed %s:%d\n", __FILE__, __LINE__);
				}

				a = cJSON_GetObjectItem(obj, "ClientId");
				if(a && a->type == cJSON_String)
				{
					ConvertString2Hex(a->valuestring, msg.device.client, sizeof(msg.device.client));
				}
				
				a = cJSON_GetObjectItem(obj, "Version");
				if (a && a->type == cJSON_String)
				{
					ConvertString2Hex(a->valuestring, msg.device.version, sizeof(msg.device.version));
				}

				a = cJSON_GetObjectItem(obj, "CryptoKey");
				if (a && a->type == cJSON_String)
				{
					ConvertString2Hex(a->valuestring, msg.device.cryto_key, sizeof(msg.device.cryto_key));
				} else {
					EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [CryptoKey] failed %s:%d\n", __FILE__, __LINE__);
				}
				
				a = cJSON_GetObjectItem(obj, "NonceKey");
				if (a && a->type == cJSON_String)
				{
					ConvertString2Hex(a->valuestring, msg.device.nonce_key, sizeof(msg.device.nonce_key));
				} else {
					EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [NonceKey] failed %s:%d\n", __FILE__, __LINE__);
				}
				
				a = cJSON_GetObjectItem(obj, "Outdoor");
				if(a && a->type == cJSON_Number)
				{
					msg.device.out_door = a->valueint;
				}

				a = cJSON_GetObjectItem(obj, "MeasureCapable");
				if (a && a->type == cJSON_Number)
					msg.device.measurecapable = a->valueint;
				
				a = cJSON_GetObjectItem(obj, "H264Capable");
				if (a && a->type == cJSON_Number)
					msg.device.h264capable = a->valueint;
				
				a = cJSON_GetObjectItem(obj, "StreamingCapable");
				if (a && a->type == cJSON_Number)
					msg.device.videostreamingcapable = a->valueint;
				
                a = cJSON_GetObjectItem(obj, "SupervTime");
                if (a && a->type == cJSON_Number)
                {
                    msg.device.device_supervision_interval= a->valueint;
                    EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [supervision] OK %s:%d:supervtime=%d\n", __FILE__, __LINE__,msg.device.device_supervision_interval);
                }else
                    EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [supervision] failed %s:%d\n", __FILE__, __LINE__);

				a = cJSON_GetObjectItem(obj, "Sensitivity");
				if (a && a->type == cJSON_Number){
					msg.device.pir_sensitivity = a->valueint;
                    EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [sensitivity] OK %s:%d:supervtime=%d\n", __FILE__, __LINE__,msg.device.pir_sensitivity);
				}else
					EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [sensitivity] failed %s:%d\n", __FILE__, __LINE__);
			}

			
			_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
		}
		
		do_start_run();
	}
}

void WLRxQueryDeviceSensitivityProcess::process(cJSON* root)
{


}

void WLRxSetDeviceSensitivityProcess::process(cJSON* root)
{
    cJSON* jsonArray = cJSON_GetObjectItem(root, "DeviceList");
    if (jsonArray && jsonArray->type == cJSON_Array)
    {
    	
        int arraySize = cJSON_GetArraySize(jsonArray);
        if (arraySize <= 0)  return;

		UpdateNumber(&sen, arraySize);
		
        _SET_PIR_SENSITIVITY_MSG msg;
		
        for (int i  = 0; i < arraySize; i++)
        {
            cJSON* obj = cJSON_GetArrayItem(jsonArray, i);
			
        	msg.msg_id = E_DBGP_APP_SET_DEVICE_1ELEMENT;
			msg.index = INDEX_PIR_SENSITIVITY;
            if (obj && obj->type == cJSON_Object)
            {
                cJSON* a = cJSON_GetObjectItem(obj,"Addr");
                if (a && a->type == cJSON_Number)
                {
					msg.address.address_type = ADDRESS_INDEX;
					msg.address.address_space.index = a->valueint;
					
                    EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Sensitivity] OK %s:%d Addr=%d\n", __FILE__, __LINE__,msg.address.address_space.index);
                }
                else                    
                    EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Addr] failed %s:%d\n", __FILE__, __LINE__);
				
                a = cJSON_GetObjectItem(obj, "Sensitivity");
				if (a && a->type == cJSON_Number)
                {            
					msg.value.sensitivity = a->valueint;
                    EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Sensitivity] OK %s:%d Sensitivity=%d\n", __FILE__, __LINE__,msg.value.sensitivity);
                }
				else
					EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Sensitivity] failed %s:%d\n", __FILE__, __LINE__);


				
        		if ( i == 0)
					do_start_run();
				_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));

            }
        }
    }
}

void WLRxSetDeviceSupervisionProcess::process(cJSON* root)
{
    cJSON* jsonArray = cJSON_GetObjectItem(root, "DeviceList");
    if (jsonArray && jsonArray->type == cJSON_Array)
    {
    
        int arraySize = cJSON_GetArraySize(jsonArray);
        if (arraySize <= 0)  return;

		UpdateNumber(&sup, arraySize);

		
        _SET_SENSOR_SUPERVISION_MSG msg;
		
        for (int i  = 0; i < arraySize; i++)
        {
            cJSON* obj = cJSON_GetArrayItem(jsonArray, i);
			
        	msg.msg_id = E_DBGP_APP_SET_DEVICE_1ELEMENT;
			msg.index = INDEX_DEVICE_SUPERVISION_INTERVAL;
            if (obj && obj->type == cJSON_Object)
            {
                cJSON* a = cJSON_GetObjectItem(obj,"Addr");
                if (a && a->type == cJSON_Number)
                {
					msg.address.address_type = ADDRESS_INDEX;
					msg.address.address_space.index = a->valueint;
					
                    EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Sensitivity] OK %s:%d Addr=%d\n", __FILE__, __LINE__,msg.address.address_space.index);
                }
                else                    
                    EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Addr] failed %s:%d\n", __FILE__, __LINE__);
                a = cJSON_GetObjectItem(obj, "Interval");
                if (a && a->type == cJSON_Number)
                {            
                    msg.value.interval= a->valueint;
                    EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Interval] OK %s:%d interval=%d\n", __FILE__, __LINE__,msg.value.interval);
                }
                else
                    EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Interval] failed %s:%d\n", __FILE__, __LINE__);


				
        		if ( i == 0)
					do_start_run();
				_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));

            }
        }
    }
}

//void WLStreamingStartProcess::process(cJSON* root)
//{

//    cJSON* jsonAddr = cJSON_GetObjectItem(root, "Addr");
//	cJSON* jsonCryptoMode = cJSON_GetObjectItem(root, "CryptoMode");
//	cJSON* jsonCryptoKey;
//	cJSON* jsonNonceKey;

//	if ( (!jsonAddr || jsonAddr->type != cJSON_Number) || (!jsonCryptoMode || jsonCryptoMode->type != cJSON_Number) )
//    {
//        //parse error
//        EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed\n");
//        return;
//    }
//	
//	if(jsonCryptoMode->valueint){
//		jsonCryptoKey = cJSON_GetObjectItem(root, "CryptoKey");
//		jsonNonceKey = cJSON_GetObjectItem(root, "NonceKey");
//		
//		if ( (!jsonCryptoKey || jsonCryptoKey->type != cJSON_String) || (!jsonNonceKey || jsonNonceKey->type != cJSON_String) )
//    	{
//        	//parse error
//        	EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed\n");
//        	return;
//    	}
//	}
//	
//	_REQUEST_STREAMING msg;
//	msg.msg_id = E_DBGP_APP_SET_DEVICE_STREAMING_REQ;
//	msg.address.address_type = ADDRESS_INDEX;
//	msg.address.address_space.index = jsonAddr->valueint;
//	msg.start_stop = START;
//	msg.security_type = jsonCryptoMode->valueint;
//	if(jsonCryptoMode->valueint){
//		ConvertString2Hex(jsonCryptoKey->valuestring,&msg.key[0],16);
//		ConvertString2Hex(jsonNonceKey->valuestring,&msg.iv[0],16);
//	}

//	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
//}

////////////
/*
void WLStreamingStartProcess::process(cJSON* root)
{
    _REQUEST_STREAMING msg;

	u8 auto_mode = 1;
	cJSON* jDevAddr = cJSON_GetObjectItem(root, "Addr");
	cJSON* jCryptoMode = cJSON_GetObjectItem(root, "CryptoMode");
	cJSON* jDuration = cJSON_GetObjectItem(root, "Duration");
	if (!jDevAddr || jDevAddr->type != cJSON_Number)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}
	if (jCryptoMode && jCryptoMode->type == cJSON_Number)
	{
		auto_mode = 0;
	}
    

	msg.duration = 0; //forever is default
	if (auto_mode == 1) //if application doesn't specify crypto, we auto crypto stream, and decrypt frame on wiselink bridge
	{
		msg.cypto_mode = 0;
		//generate random KEY and IV
		if ( 1 != RAND_bytes(msg.key, sizeof(msg.key)))
		{
			//it's unlikely to enter here
			RAND_pseudo_bytes(msg.key, sizeof(msg.key));
		}
		if ( 1 != RAND_bytes(msg.iv, sizeof(msg.iv)))
		{
			RAND_pseudo_bytes(msg.iv, sizeof(msg.iv));
		}
		WLVSStreamMngr::instance()->PrepareDecrypto(msg.cypto_mode, msg.key, msg.iv);
	} else {
		//if application specify, we pass streaming with raw data
		msg.cypto_mode = jCryptoMode->valueint? 1:0;
		//parse key and iv
		cJSON* jKey = cJSON_GetObjectItem(root, "CryptoKey");
		cJSON* jIV = cJSON_GetObjectItem(root, "NonceKey");
		if (jKey && jIV && jKey->type == cJSON_String && jIV->type == cJSON_String)
		{
			convertstring2hex(jKey->valuestring, msg.key, sizeof(msg.key));
			convertstring2hex(jIV->valuestring, msg.iv, sizeof(msg.iv));
			WLVSStreamMngr::instance()->PrepareDecrypto(0, msg.key, msg.iv);
		} else if (!jKey && !jIV && msg.cypto_mode == 1) {
			//generate random KEY and IV
			if ( 1 != RAND_bytes(msg.key, sizeof(msg.key)))
			{
				//it's unlikely to enter here
				RAND_pseudo_bytes(msg.key, sizeof(msg.key));
			}
			if ( 1 != RAND_bytes(msg.iv, sizeof(msg.iv)))
			{
				RAND_pseudo_bytes(msg.iv, sizeof(msg.iv));
			}
			WLVSStreamMngr::instance()->PrepareDecrypto(msg.cypto_mode, msg.key, msg.iv);	
		}
		else{

			memset(msg.key, 0, sizeof(msg.key));
			memset(msg.iv, 0, sizeof(msg.iv));
			WLVSStreamMngr::instance()->PrepareDecrypto(0, msg.key, msg.iv);		
		}

	}
	if (jDuration && jDuration->type == cJSON_Number)
	{
		u8 duration = (u8) jDuration->valueint;
		if (duration >= 3 && duration <= (1800/10)) //from 30 seconds ~ 30 min
			msg.duration = duration;
	}

    //
	msg.msg_id = E_DBGP_APP_SET_DEVICE_STREAMING_REQ;
	msg.address.address_type = ADDRESS_INDEX;
	msg.address.address_space.index = jsonAddr->valueint;
	msg.start_stop = START;
	msg.security_type = jsonCryptoMode->valueint;

	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));

}

////////////
void WLStreamingStopProcess::process(cJSON* root)
{

    cJSON* jsonAddr = cJSON_GetObjectItem(root, "Addr");
	cJSON* jsonoption = cJSON_GetObjectItem(root, "option");

	if ( (!jsonAddr || jsonAddr->type != cJSON_Number) || (!jsonoption || jsonoption->type != cJSON_Number) )
    {
        //parse error
        EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed\n");
        return;
    }
	
	
	_REQUEST_STREAMING msg;
	msg.msg_id = E_DBGP_APP_SET_DEVICE_STREAMING_REQ;
	msg.address.address_type = ADDRESS_INDEX;
	msg.address.address_space.index = jsonAddr->valueint;
	msg.start_stop = STOP;

	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}
*/

void WLRxEnrollProcess::process(cJSON* root)
{
    cJSON* jsonItem = cJSON_GetObjectItem(root, "Mode");
    if (jsonItem)
    {
        _ENROLL_START_MSG msg;
        if (jsonItem->valueint)
            msg.msg_id = E_DBGP_APP_SET_START_ENROLLING;
        else
            msg.msg_id = E_DBGP_APP_SET_STOP_ENROLLING;
        do_start_run(); //require protocol running
        _wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
        EvLog::instance().log_printf(EVL_INFO, "Enroll(%d) JSON -> Tx Msg\n", jsonItem->valueint);
    } else {
        EvLog::instance().log_printf(EVL_ERROR, "Get JSON Object [Enroll Mode] failed %s:%d\n", __FILE__, __LINE__);
    }	
}

void WLRxRemoveProcess::process(cJSON* root)
{
    cJSON* jsonItem = cJSON_GetObjectItem(root, "Devices");
    if (!jsonItem || jsonItem->type != cJSON_Array)
    {
        //parse error
        EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed\n");
        return;
    }
    
    int arraySize = cJSON_GetArraySize(jsonItem);
    //assert(arraySize > 0);
    
    if (arraySize <=0 )
    {
        //error
        EvLog::instance().log_printf(EVL_ERROR, "Invalid Array Size %s:%d\n", __FILE__, __LINE__);
        return;
    }
    
    _REMOVE_DEVICES_MSG msg;
    
    for (int i = 0; i < arraySize; i++)
    {
        cJSON* arrayItem = cJSON_GetArrayItem(jsonItem, i);
        assert(arrayItem);
        
        msg.msg_id = E_DBGP_APP_SET_DELETE_DEVICE;
        msg.address.address_type = ADDRESS_INDEX;
        msg.address.address_space.index = arrayItem->valueint;
		
        //send to tx queue
        if(i == 0)
        	do_start_run(); //require protocol running
        _wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
        EvLog::instance().log_printf(EVL_INFO, "Remove JSON -> Tx Msg\n");
    }
}




void WLRxArmDevicesProcess::process(cJSON* root)
{
	cJSON* jsonItem = cJSON_GetObjectItem(root, "Devices");
	if (!jsonItem || jsonItem->type != cJSON_Array)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}
	
	int arraySize = cJSON_GetArraySize(jsonItem);
	//assert(arraySize > 0);
	if (arraySize <=0 )
	{
		//error
		EvLog::instance().log_printf(EVL_ERROR, "Invalid Array Size %s:%d\n", __FILE__, __LINE__);
		return;
	}
    
    _ARM_DEVICES_MSG msg;
    
    for (int i = 0; i < arraySize; i++)
    {
        cJSON* arrayItem = cJSON_GetArrayItem(jsonItem, i);
        assert(arrayItem);
        
        msg.msg_id = E_DBGP_APP_SET_DEVICE_ARM;
        msg.address.address_type = ADDRESS_INDEX;
        msg.address.address_space.index = arrayItem->valueint;

		printf("msg id: %x\n", msg.msg_id);
		printf("msg address type: %x\n", msg.address.address_type);
		printf("msg address index: %x\n", msg.address.address_space.index);
		for(int j = 0; j < 2; j++)
			printf("msg address short %d: %x\n", j, msg.address.address_space.short_address[j]);
		for(int j = 0; j < 8; j++)
			printf("msg address long %d: %x\n", j, msg.address.address_space.long_address[j]);
		printf("sizeof msg: %d\n", sizeof(msg));
		
        //send to tx queue
        if(i == 0)
        	do_start_run(); //require protocol running
        _wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
    }
}

void WLRxDisarmDevicesProcess::process(cJSON* root)
{
	cJSON* jsonItem = cJSON_GetObjectItem(root, "Devices");
	if (!jsonItem || jsonItem->type != cJSON_Array)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}
	
	int arraySize = cJSON_GetArraySize(jsonItem);
	//assert(arraySize > 0);
	if (arraySize <=0 )
	{
		//error
		EvLog::instance().log_printf(EVL_ERROR, "Invalid Array Size %s:%d\n", __FILE__, __LINE__);
		return;
	}
    
    _DISARM_DEVICES_MSG msg;
    
    for (int i = 0; i < arraySize; i++)
    {
        
        cJSON* arrayItem = cJSON_GetArrayItem(jsonItem, i);
        assert(arrayItem);
        
        msg.msg_id = E_DBGP_APP_SET_DEVICE_DISARM;
        msg.address.address_type = ADDRESS_INDEX;
        msg.address.address_space.index = arrayItem->valueint;
		
        //send to tx queue
        _wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
    }
}

void WLRxRangeTestProcess::process(cJSON * root)
{
	cJSON* jDevAddr = cJSON_GetObjectItem(root, "Device");
	cJSON* jMode = cJSON_GetObjectItem(root, "Mode");
	
	if (!jDevAddr ||!jMode || jDevAddr->type != cJSON_Number || jMode->type != cJSON_Number)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}

	u8 addr = jDevAddr->valueint;
	
	_START_STOP p = STOP;

	_START_STOP_MAINTENANCE_MSG msg;
	if (jMode->valueint == 1)
		p = START;
	else
		p = STOP;
	
	msg.msg_id = E_DBGP_APP_SET_DEVICE_MAINTENANCE_TEST;
	msg.address.address_type = ADDRESS_INDEX;
	msg.address.address_space.index = addr;
	msg.mode = RANGE_TEST;
	msg.start_stop = p;


		//send to tx queue
	do_start_run(); //require protocol running
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));	
	
}

void WLRxControlLedProcess::process(cJSON* root)
{
	cJSON* jDevAddr = cJSON_GetObjectItem(root, "Device");
	cJSON* jMode = cJSON_GetObjectItem(root, "Mode");

	if (!jDevAddr ||!jMode || jDevAddr->type != cJSON_Number || jMode->type != cJSON_Number)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}	

	u8 addr = jDevAddr->valueint;
	u8 mode = jMode->valueint;

	_SET_LED_MODE_MSG msg;
	
	msg.msg_id = E_DBGP_APP_SET_SOUND_LIGHT_LED;
	msg.address.address_type = ADDRESS_INDEX;
	msg.address.address_space.index = addr;
	msg.type = _LED;
	msg.mode = (_LED_MODE)mode;
	msg.strength = 0x01;
	msg.duration = 0x01;
	
	//send to tx queue
	do_start_run(); //require protocol running
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));	
}

void WLRxRequestPStatProcess::process(cJSON* root)
{
    cJSON* jDevAddr = cJSON_GetObjectItem(root, "Device");
    
    if (!jDevAddr || jDevAddr->type != cJSON_Number)
    {
        //parse error
        EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
        return;
    }
    
	u8 addr = jDevAddr->valueint;

    _REQUEST_DEVICE_INFO_STATUS_MSG msg;
	
    msg.msg_id = E_DBGP_APP_GET_DEVICE_STATUS;
    msg.address.address_type = ADDRESS_INDEX;
    msg.address.address_space.index = addr;
    
    //send to tx queue
    do_start_run(); //require protocol running
    _wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}

void WLRxSetRadioCyclicityProcess::process(cJSON* root)
{
	cJSON* jdev_list = cJSON_GetObjectItem(root, "Devices");
	cJSON* jmode = cJSON_GetObjectItem(root, "Mode");

	if (!jdev_list ||!jmode || jdev_list->type != cJSON_Array || jmode->type != cJSON_Number)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}		

	int arraySize = cJSON_GetArraySize(jdev_list);
	//assert(arraySize > 0);
	if (arraySize <=0 )
	{
		//error
		EvLog::instance().log_printf(EVL_ERROR, "Invalid Array Size %s:%d\n", __FILE__, __LINE__);
		return;
	}

    
    _SET_RADIO_CYCLICITY_MSG msg;
    
    for (int i = 0; i < arraySize; i++)
    {
        cJSON* arrayItem = cJSON_GetArrayItem(jdev_list, i);
        assert(arrayItem);
        
        msg.msg_id = E_DBGP_APP_SET_DEVICE_1ELEMENT;
        msg.address.address_type = ADDRESS_INDEX;
        msg.address.address_space.index = arrayItem->valueint;
		msg.index = INDEX_DEVICE_FAST_CYCLE_MODE;
		msg.value.mode = jmode->valueint;
		
        //send to tx queue
        if(i == 0)
        	do_start_run(); //require protocol running
        _wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
    }
}

void WLRxRequestMaintanceProcess::process(cJSON* root)
{
	cJSON* jmode = cJSON_GetObjectItem(root, "Mode");

	if (!jmode || jmode->type != cJSON_Number)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}

	_START_STOP p = STOP;

	_START_STOP_MAINTENANCE_MSG msg;
	if (jmode->valueint == 1)
		p = START;
	else
		p = STOP;
	
	msg.msg_id = E_DBGP_APP_SET_DEVICE_MAINTENANCE_TEST;
	//msg.address
	msg.mode = MAINTENANCE;
	msg.start_stop = p;

	
	//send to tx queue
	do_start_run(); //require protocol running
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));	
}

void WLRxConfigVideoProcess::process(cJSON* root)
{
	cJSON* jvideoConfig = cJSON_GetObjectItem(root, "VideoConfig");
    
    EvLog::instance().log_printf(EVL_ERROR, "Config step %s:%d\n", __FILE__, __LINE__);
    if (!jvideoConfig)
    {
    
    EvLog::instance().log_printf(EVL_ERROR, "Config step %s:%d\n", __FILE__, __LINE__);
        return;
    }
    
    if (jvideoConfig->type != cJSON_Object)
    {
    
    EvLog::instance().log_printf(EVL_ERROR, "Config step %s:%d\n", __FILE__, __LINE__);
        return;
    }
    
	cJSON* jformat      = cJSON_GetObjectItem(jvideoConfig, "format");
	cJSON* jduration    = cJSON_GetObjectItem(jvideoConfig, "duration");
	cJSON* jquality     = cJSON_GetObjectItem(jvideoConfig, "quality");
	cJSON* jresolution  = cJSON_GetObjectItem(jvideoConfig, "resolution");
	cJSON* jcolor       = cJSON_GetObjectItem(jvideoConfig, "color");
    
    EvLog::instance().log_printf(EVL_ERROR, "Config step %s:%d\n", __FILE__, __LINE__);
	if (!jformat)
	{
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d, jformat:%d, type:%d\n", __FILE__, __LINE__, jformat, jformat->type);
		return;
	}
    if (jformat->type != cJSON_Number)
    {
        return;
    }
	if (!jduration)
	{
		return;
	}
    if (jduration->type != cJSON_Number)
    {
        return;
    }
	if (!jquality)
	{
		return;
	}
    if (jquality->type != cJSON_Number)
    {
        return;
    }
	if (!jresolution)
	{
		return;
	}
    if (jresolution->type != cJSON_Number)
    {
        return;
    }
	if (!jcolor)
	{
		return;
	}
    if (jcolor->type != cJSON_Number)
    {
        return;
    }

	_CONFIG_REQUEST_IMAGE msg;
	u8 format       = jformat->valueint;
	u8 duration     = jduration->valueint;
	u8 quality      = jquality->valueint;
	u8 resolution   = jresolution->valueint;
	u8 color        = jcolor->valueint;
    
    EvLog::instance().log_printf(EVL_INFO, "Parse Set Clip JSON:f:%d, d:%d, q:%d, r:%d, c:%d\n", format, duration, quality, resolution, color);

    msg.msg_id      = E_DBGP_APP_SET_USER_REQ_IMAGE;
    msg.address.address_type = ADDRESS_INDEX;
    msg.address.address_space.index = 0xff;
	
    msg.format      = format;
    msg.duration    = duration;
    msg.quality     = quality;
    msg.resolution  = resolution;
    msg.color       = color;
	
	msg.action = TRIGGER_TAKE_IMAGE;
	
	//send to tx queue
	do_start_run(); //require protocol running
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));	
}

void WLRxGetVideoClipProcess::process(cJSON* root)
{
	cJSON* jaddr = cJSON_GetObjectItem(root, "Device");

	if (!jaddr)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}
    if (jaddr->type != cJSON_Number)
    {
        return;
    }

	_CONFIG_REQUEST_IMAGE msg;
	u8 addr = jaddr->valueint;
    EvLog::instance().log_printf(EVL_INFO, "Parse Get Clip JSON:addr:%d\n", addr);
	
	msg.msg_id      = E_DBGP_APP_SET_USER_REQ_IMAGE;
    msg.address.address_type = ADDRESS_INDEX;
    msg.address.address_space.index = addr;
	
    msg.format      = 0xff;
    msg.duration    = 0xff;
    msg.quality     = 0xff;
    msg.resolution  = 0xff;
    msg.color       = 0xff;
	
	msg.action = USER_REQUIRE_IMAGE_DATA;

	//send to tx queue
	do_start_run(); //require protocol running
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));	
}

void WLRxGetVideoSnapshotProcess::process(cJSON* root)
{
	cJSON* jaddr = cJSON_GetObjectItem(root, "Device");
    EvLog::instance().log_printf(EVL_ERROR, "@@@@@@@@@@@@ 1%s:%d\n", __FILE__, __LINE__);
	if (!jaddr)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}
    if (jaddr->type != cJSON_Number)
    {
        EvLog::instance().log_printf(EVL_ERROR, "@@@@@@@@@@@@ 2%s:%d\n", __FILE__, __LINE__);
        return;
    }

	_CONFIG_REQUEST_IMAGE msg;
	u8 addr = jaddr->valueint;
    EvLog::instance().log_printf(EVL_INFO, "Parse Get Clip JSON:addr:%d\n", addr);

    msg.msg_id      = E_DBGP_APP_SET_USER_REQ_IMAGE;
    msg.address.address_type = ADDRESS_INDEX;
    msg.address.address_space.index = addr;
	
    msg.format      = 0xff;
    msg.duration    = 0xff;
    msg.quality     = 0xff;
    msg.resolution  = 0xff;
    msg.color       = 0xff;
	
	msg.action = USER_REQUIRE_TAKE_IMAGE;

	//send to tx queue
	do_start_run(); //require protocol running
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));	
}

//if ((sent_len + CLIP_PACK_SIZE) >= buffer_len)
//{
//    check_size = buffer_len - sent_len;
//}
//else
//{
//    check_size = CLIP_PACK_SIZE;
//}

//index = bit_map->test(sent_len, check_size);

//EvLog::instance().log_printf(EVL_INFO, "[VIDEO] Total len:%d, recv:%d, sent:%d, invalid_index:%d!\n", buffer_len, recv_len, sent_len, index);


int WLVideoClipBuffer::toJSONString(char* json_str, int json_nb)
{
    u32 len;
    cJSON* root = cJSON_CreateObject();
    u8 *pBase64In;
    u8 *pBase64Out;
    u32 inLength;
    u32 outLength;
    Base64 base64;
    u32   index;

    if (!root){ return 0; }

    //check state
    if (!started)
    {   
        if (end_state != VIDEO_Rx_Done)
        {
            EvLog::instance().log_printf(EVL_INFO, "[VIDEO] Not start!\n");
            return 0;
        }
    }

    inLength = 0;
    index = bit_map->getClrHead(sent_len, (buffer_len - sent_len));
    EvLog::instance().log_printf(EVL_INFO, "[VIDEO] Jsn:total len:%d, recv:%d, sent:%d, invalid_index:%d!\n", buffer_len, recv_len, sent_len, index);

    //check vaild data len
    inLength = index - sent_len;

    if (inLength >= CLIP_PACK_SIZE)
    {
        inLength = CLIP_PACK_SIZE;
    }
    else
    {
        //wait the buffer to be filled in other state. So we do not need to send package.
        if (end_state != VIDEO_Rx_Done)
        {
            inLength = 0; 

            EvLog::instance().log_printf(EVL_INFO, "[VIDEO]Wait the buffer to be filled in other state%d\r\n", end_state);
            cJSON_Delete(root);
            return 0;
        }
    }
    
    EvLog::instance().log_printf(EVL_ERROR, "[VIDEO] WLVideoClipBuffer Send inLength :%d\n", inLength);

    if (inLength != 0)
    {
        //prepare jason clip frame
        cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE_RX_DATA);
        cJSON_AddNumberToObject(root, "Device", device_addr);
        pBase64In = &video_buffer[sent_len];
        pBase64Out = new u8[inLength * 2];
        if (!pBase64Out)
        {
            cJSON_Delete(root);
            return 0;
        }
        
        outLength = inLength * 2;
        memset(pBase64Out, 0, outLength);
        
        //convert base64
        base64.Encode((const char *)pBase64In, inLength,(char * )pBase64Out, outLength);
        len = strlen((const char *)pBase64Out);
        
        EvLog::instance().log_printf(EVL_INFO, "Base64 in:%d, out:%d\r\n", inLength, outLength);
        
        cJSON_AddNumberToObject(root, "Length", len);
        cJSON_AddStringToObject(root, "Data", (const char *)pBase64Out);
        delete pBase64Out;
    }
    else
    {
        //check whether to sent clip done frame
        if (end_state == VIDEO_Rx_Done)
        {
            //check if we have send all the receive data.
            if (recv_len > sent_len)
           
{
                //check vaild data len
                inLength = recv_len - sent_len;

                //package data
                if (inLength >= CLIP_PACK_SIZE)
                {
                    inLength = CLIP_PACK_SIZE;
                }

                EvLog::instance().log_printf(EVL_INFO, "Send rest packet for clip length:%d-----------\r\n", inLength);
                //prepare jason clip frame
                cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE_RX_DATA);
                cJSON_AddNumberToObject(root, "Device", device_addr);
                pBase64In = &video_buffer[sent_len];
                pBase64Out = new u8[inLength * 2];
                if (!pBase64Out)
                {
                    cJSON_Delete(root);
                    return 0;
                }
                
                outLength = inLength * 2;
                memset(pBase64Out, 0, outLength);
                
                //convert base64
                base64.Encode((const char *)pBase64In, inLength,(char * )pBase64Out, outLength);
                len = strlen((const char *)pBase64Out);
                
                EvLog::instance().log_printf(EVL_INFO, "Base64 in:%d, out:%d\r\n", inLength, outLength);
                
                cJSON_AddNumberToObject(root, "Length", len);
                cJSON_AddStringToObject(root, "Data", (const char *)pBase64Out);
                
                usleep(50);
                delete pBase64Out;

            }
            else
            {
                //send done frame after we send  all the clip data.
                cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE_RX_STATE);
                cJSON_AddNumberToObject(root, "Device", device_addr);
                cJSON_AddNumberToObject(root, "Code", VIDEO_Rx_Done);

                //reset the clip buffer state.
                end_state = VIDEO_Rx_No_Found;
                sent_len = 0;
                buffer_len = 0;
                recv_len = 0;
                started = 0;
                usleep(50);
                EvLog::instance().log_printf(EVL_INFO, "Send last packet-----------\r\n");
            }

        }
    }

    char* JsonChar = cJSON_Print(root);
    if (!JsonChar)
    {
        cJSON_Delete(root);
        return 0;
    }
    int size = strlen(JsonChar);

    if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
    else size = 0;
    free(JsonChar);
    cJSON_Delete(root);

    /////////
    
    EvLog::instance().log_printf(EVL_INFO, "clip buffer index:%d, base64 send:%d\r\n", sent_len ,len);
    sent_len += inLength;
    ///////
    

    return size;        
}


///////////
void WLRxRequestMonitorProcess::process(cJSON* root)
{
	cJSON* jmode = cJSON_GetObjectItem(root, "Mode");
	cJSON* jPeriod = cJSON_GetObjectItem(root, "Period");
	if (!jmode || !jPeriod || jmode->type != cJSON_Number || jPeriod->type != cJSON_Number)
	{
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}

	u8 mode = jmode->valueint;
	u16 period = jPeriod->valueint;

	if (mode == 1 && period > 0 && period <= 120 || mode == 0)
	{
		_REQUEST_MONITOR_MSG msg;
		msg.msg_id = E_DBGP_APP_SET_AP_MONITOR;
		msg.mode = mode;
		msg.period = period;
		do_start_run();
		_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
	}
}


WLTxMonitorSupervProcess::WLTxMonitorSupervProcess(const u8 * msg_ptr, int msg_nb)
{
	_resp_monitor_superv_ptr = (_RESP_MONITOR_SUPERV_MSG*) msg_ptr;
	blk_size = msg_nb;
}

WLTxMonitorSupervProcess::~WLTxMonitorSupervProcess()
{

}

int WLTxMonitorSupervProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();

	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Status", _resp_monitor_superv_ptr->status);
	char* JsonChar = cJSON_Print(root);
		if (!JsonChar)
		{
			cJSON_Delete(root);
			return 0;
		}
		int size = strlen(JsonChar);
	
		if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
		else size = 0;
		free(JsonChar);
		cJSON_Delete(root);
		return size;	
}

int WLTxQuerySiteIDResponseProcess::toJSONString(char* json_str, int json_nb)
{
	char strTemp[64];
		
	cJSON* root = cJSON_CreateObject();
	
	ConvertHex2String((u8 *)&resp_siteid_msg_ptr->site_id[0], resp_siteid_msg_ptr->length, (u8 *)&strTemp[0], sizeof(strTemp));
	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddStringToObject(root, "SiteID", strTemp);
	char* JsonChar = cJSON_Print(root);
		if (!JsonChar)
		{
			cJSON_Delete(root);
			return 0;
		}
		int size = strlen(JsonChar);
	
		if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
		else size = 0;
		free(JsonChar);
		cJSON_Delete(root);
		return size;	

}
int WLTxQueryDevicesInfoResponseProcess::toJSONString(char * json_str, int json_nb)
{
    static u8 frame_start_flag = 0;
    static cJSON * root;
    static cJSON * DevicesList;
    static u16 count = 0;
    char strTemp[64] = {0};
    
    if(frame_start_flag == 0){
		frame_start_flag = 1;
        root = cJSON_CreateObject();
        DevicesList = cJSON_CreateArray();
        
    	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
    }
    
    
    // device n
    cJSON* item = cJSON_CreateObject();
    
    cJSON_AddNumberToObject(item, "Addr", pInfo->device.index);
    cJSON_AddNumberToObject(item, "Type", pInfo->device.type);
    cJSON_AddNumberToObject(item, "CycleValue", pInfo->device.cycle_value);
    cJSON_AddNumberToObject(item, "FastCycleAllowed", pInfo->device.fastcycleallowed_flag);
    
    sprintf(strTemp, "%02X%02X%02X%02X", pInfo->device.serialnumber[0], pInfo->device.serialnumber[1],
            pInfo->device.serialnumber[2], pInfo->device.serialnumber[3]);
    cJSON_AddStringToObject(item, "SerialNumber", strTemp);
    
    sprintf(strTemp, "%02X%02X", pInfo->device.client[0], pInfo->device.client[1]);
    cJSON_AddStringToObject(item, "ClientId", strTemp);
    
    sprintf(strTemp, "%02X%02X%02X%02X", pInfo->device.version[0], pInfo->device.version[1],
            pInfo->device.version[2], pInfo->device.version[3]);
    cJSON_AddStringToObject(item, "Version", strTemp);
    
    sprintf(strTemp, "%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
            pInfo->device.cryto_key[0], pInfo->device.cryto_key[1], pInfo->device.cryto_key[2], pInfo->device.cryto_key[3], 		
            pInfo->device.cryto_key[4], pInfo->device.cryto_key[5], pInfo->device.cryto_key[6], pInfo->device.cryto_key[7], 		
            pInfo->device.cryto_key[8], pInfo->device.cryto_key[9], pInfo->device.cryto_key[10], pInfo->device.cryto_key[11], 		
            pInfo->device.cryto_key[12], pInfo->device.cryto_key[13], pInfo->device.cryto_key[14], pInfo->device.cryto_key[15]);
    cJSON_AddStringToObject(item, "CryptoKey", strTemp);
    
    sprintf(strTemp, "%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
            pInfo->device.nonce_key[0], pInfo->device.nonce_key[1], pInfo->device.nonce_key[2], pInfo->device.nonce_key[3],
            pInfo->device.nonce_key[4], pInfo->device.nonce_key[5], pInfo->device.nonce_key[6], pInfo->device.nonce_key[7],
            pInfo->device.nonce_key[8], pInfo->device.nonce_key[9], pInfo->device.nonce_key[10], pInfo->device.nonce_key[11],
            pInfo->device.nonce_key[12], pInfo->device.nonce_key[13], pInfo->device.nonce_key[14], pInfo->device.nonce_key[15]);
    cJSON_AddStringToObject(item, "NonceKey", strTemp);
    
    
    //
    cJSON_AddNumberToObject(item, "OutDoor", pInfo->device.out_door);
    //cJSON_AddNumberToObject(item, "BatteryGauge", pInfo->battery_level);
    //cJSON_AddNumberToObject(item, "LQI", pInfo->signal_level);
    cJSON_AddNumberToObject(item, "MeasureCapable", pInfo->device.measurecapable);
    cJSON_AddNumberToObject(item, "H264Capable", pInfo->device.h264capable);
    cJSON_AddNumberToObject(item, "StreamingCapable", pInfo->device.videostreamingcapable);
	cJSON_AddNumberToObject(item, "SupervTime", pInfo->device.device_supervision_interval);
	cJSON_AddNumberToObject(item, "Sensitivity", pInfo->device.pir_sensitivity);
    
    cJSON_AddItemToArray(DevicesList, item);
    printf("Get info xxx %02x.\n",pInfo->device.index);
    
    count ++;
    
    if((pInfo->device.result_type == UPLOAD_DEVICE_INFO)&&(pInfo->device.result_code == 0x01)){// all devices' info and status have been uploaded
    	cJSON_AddNumberToObject(root, "Count", count);
		count = 0;
		frame_start_flag = 0;
        cJSON_AddItemToObject(root, "ADeviceList", DevicesList);
        
        char* JsonChar = cJSON_Print(root);
        if (!JsonChar)
        {
            cJSON_Delete(root);
            return 0;
        }
        int size = strlen(JsonChar);
        
        if ( size < json_nb) 
            strncpy(json_str, JsonChar, json_nb);
        else size = 0;
        
        free(JsonChar);
        
        cJSON_Delete(root);
        
        return size;
		
    }else{

		return 0;
    }
}






WLTxEnrollResponseProcess::WLTxEnrollResponseProcess(const u8 * msg_ptr, int msg_nb)
{
	enroll_resp_ptr = (_DEVICE_INFO_STATUS *) msg_ptr;
	blk_size = msg_nb;
}

int WLTxEnrollResponseProcess::toJSONString(char * json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();
	cJSON* resultItem = cJSON_CreateObject();
	if (!root || !resultItem) { if (root) cJSON_Delete(root); if (resultItem) cJSON_Delete(resultItem); return 0; }

	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddItemToObject(root, "Enroll Result", resultItem);

	cJSON_AddNumberToObject(resultItem, "Error Code", enroll_resp_ptr->device.result_code);
	if (enroll_resp_ptr->device.result_code == 0) //success
	{
		char strSN[64] = {0};
		cJSON* info = cJSON_CreateObject();
		cJSON_AddNumberToObject(info, "Addr", enroll_resp_ptr->device.index);
		cJSON_AddNumberToObject(info, "Type", enroll_resp_ptr->device.type);
		cJSON_AddNumberToObject(info, "CycleValue", enroll_resp_ptr->device.cycle_value);
		cJSON_AddNumberToObject(info, "FastCycleAllowed", enroll_resp_ptr->device.fastcycleallowed_flag);
		sprintf(strSN, "%02X%02X%02X%02X", enroll_resp_ptr->device.serialnumber[0], enroll_resp_ptr->device.serialnumber[1],
											enroll_resp_ptr->device.serialnumber[2], enroll_resp_ptr->device.serialnumber[3]);
		cJSON_AddStringToObject(info, "SerialNumber", strSN);
		sprintf(strSN, "%02X%02X", enroll_resp_ptr->device.client[0], enroll_resp_ptr->device.client[1]);
		cJSON_AddStringToObject(info, "ClientId", strSN);
		sprintf(strSN, "%02X%02X%02X%02X", enroll_resp_ptr->device.version[0], enroll_resp_ptr->device.version[1],
																		enroll_resp_ptr->device.version[2], enroll_resp_ptr->device.version[3]);
		cJSON_AddStringToObject(info, "Version", strSN);

		sprintf(strSN, "%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
					enroll_resp_ptr->device.cryto_key[0], enroll_resp_ptr->device.cryto_key[1], enroll_resp_ptr->device.cryto_key[2], enroll_resp_ptr->device.cryto_key[3], 		
					enroll_resp_ptr->device.cryto_key[4], enroll_resp_ptr->device.cryto_key[5], enroll_resp_ptr->device.cryto_key[6], enroll_resp_ptr->device.cryto_key[7], 		
					enroll_resp_ptr->device.cryto_key[8], enroll_resp_ptr->device.cryto_key[9], enroll_resp_ptr->device.cryto_key[10], enroll_resp_ptr->device.cryto_key[11], 		
					enroll_resp_ptr->device.cryto_key[12], enroll_resp_ptr->device.cryto_key[13], enroll_resp_ptr->device.cryto_key[14], enroll_resp_ptr->device.cryto_key[15]);
		cJSON_AddStringToObject(info, "CryptoKey", strSN);

                sprintf(strSN, "%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
                                        enroll_resp_ptr->device.nonce_key[0], enroll_resp_ptr->device.nonce_key[1], enroll_resp_ptr->device.nonce_key[2], enroll_resp_ptr->device.nonce_key[3],
                                        enroll_resp_ptr->device.nonce_key[4], enroll_resp_ptr->device.nonce_key[5], enroll_resp_ptr->device.nonce_key[6], enroll_resp_ptr->device.nonce_key[7],
                                        enroll_resp_ptr->device.nonce_key[8], enroll_resp_ptr->device.nonce_key[9], enroll_resp_ptr->device.nonce_key[10], enroll_resp_ptr->device.nonce_key[11],
                                        enroll_resp_ptr->device.nonce_key[12], enroll_resp_ptr->device.nonce_key[13], enroll_resp_ptr->device.nonce_key[14], enroll_resp_ptr->device.nonce_key[15]);
                cJSON_AddStringToObject(info, "NonceKey", strSN);

	
		//
		cJSON_AddNumberToObject(info, "OutDoor", enroll_resp_ptr->device.out_door);
		cJSON_AddNumberToObject(info, "MeasureCapable", enroll_resp_ptr->device.measurecapable);
		cJSON_AddNumberToObject(info, "H264Capable", enroll_resp_ptr->device.h264capable);
		cJSON_AddNumberToObject(info, "StreamingCapable", enroll_resp_ptr->device.videostreamingcapable);
		cJSON_AddNumberToObject(info, "BatteryGauge", enroll_resp_ptr->device.battery_level);
		cJSON_AddNumberToObject(info, "LQI", enroll_resp_ptr->device.signal_level);

		cJSON_AddItemToObject(resultItem,"Device Info", info);
	}

	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	
}


WLTxRangeTestResponseProcess::WLTxRangeTestResponseProcess(const u8* msg_ptr, int msg_nb)
{
	resp_range_ptr = (_RESP_RANGETEST_RESULT_MSG*) msg_ptr;
	blk_size = msg_nb;
}

int WLTxRangeTestResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();

	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Device", resp_range_ptr->address.address_space.index);
	cJSON_AddNumberToObject(root, "Status", resp_range_ptr->radio_range);
	cJSON_AddNumberToObject(root, "LQI", resp_range_ptr->signal_level);
	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;		

}
WLTxStatusUpdateEventProcess::WLTxStatusUpdateEventProcess(const u8* msg_ptr, int msg_nb)
{
	status_update_ptr = (_DEVICE_INFO_STATUS *) msg_ptr;
	blk_size = msg_nb;
}

int WLTxStatusUpdateEventProcess::toJSONString(char * json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();
	if (!root){ return 0; }

	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Device", status_update_ptr->device.index);
	cJSON_AddNumberToObject(root, "BatteryFault", status_update_ptr->device.battery_level >= 3?0:1);
	cJSON_AddNumberToObject(root, "BatteryGauge", status_update_ptr->device.battery_level);
	cJSON_AddNumberToObject(root, "Supervision", status_update_ptr->device.radiofailure);
	cJSON_AddNumberToObject(root, "Tamper", status_update_ptr->device.tamper);
	cJSON_AddNumberToObject(root, "Detection", status_update_ptr->device.latched);
	cJSON_AddNumberToObject(root, "Fire", 0);
	cJSON_AddNumberToObject(root, "Test Mode", 0);
	cJSON_AddNumberToObject(root, "Temperature", 0);
	cJSON_AddNumberToObject(root, "LQI", status_update_ptr->device.signal_level);
	cJSON_AddNumberToObject(root, "LQI1", status_update_ptr->device.signal_level_1);

	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;		
	
}


WLTxKeyPressedEventProcess::WLTxKeyPressedEventProcess(const u8 * msg_ptr, int msg_nb)
{
	key_press_msg_ptr = (_RESP_KEYFOB_PRESSED_MSG*)msg_ptr;
	blk_size = msg_nb;
}


int WLTxKeyPressedEventProcess::toJSONString(char * json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();
	if (!root){ return 0; }

	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Device", key_press_msg_ptr->address.address_space.index);
	cJSON_AddNumberToObject(root, "KeyCode", key_press_msg_ptr->key_code);

	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;		
}

WLTxArmedResponseProcess::WLTxArmedResponseProcess(const u8 * msg_ptr, int msg_nb)
{
	_resp_armed_ptr = (_DEVICE_INFO_STATUS*) msg_ptr;
	blk_size = msg_nb;
}

WLTxArmedResponseProcess::~WLTxArmedResponseProcess()
{

}

int WLTxArmedResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();
	if (!root){ return 0; }

	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Device", _resp_armed_ptr->device.index);
	cJSON_AddNumberToObject(root, "Status", _resp_armed_ptr->device.result_code);

	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;
}

WLTxDisarmedResponseProcess::WLTxDisarmedResponseProcess(const u8 * msg_ptr, int msg_nb)
{
	_resp_disarmed_ptr = (_DEVICE_INFO_STATUS *) msg_ptr;
	blk_size = msg_nb;
}

WLTxDisarmedResponseProcess::~WLTxDisarmedResponseProcess()
{

}

int WLTxDisarmedResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();
	if (!root){ return 0; }

	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Device", _resp_disarmed_ptr->device.index);
	cJSON_AddNumberToObject(root, "Status", _resp_disarmed_ptr->device.result_code);

	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;
}

WLTxRemovedResponseProcess::WLTxRemovedResponseProcess(const u8 * msg_ptr, int msg_nb)
{
	_resp_removed_ptr = (_DEVICE_INFO_STATUS*) msg_ptr;
	blk_size = msg_nb;

}
WLTxRemovedResponseProcess::~WLTxRemovedResponseProcess()
{
}
int WLTxRemovedResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();
	if (!root){ return 0; }

	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Device", _resp_removed_ptr->device.index);
	cJSON_AddNumberToObject(root, "Status", _resp_removed_ptr->device.result_code);

	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;
}

int WLTxVideoReadyEventProcess::toJSONString(char* json_str, int json_nb) 
{ 
	cJSON* root = cJSON_CreateObject();
	cJSON* videoInfo = cJSON_CreateObject();

	EvLog::instance().log_printf(EVL_INFO, "[Video]VideoClip Ready: addr = %d, format = %d, size = %d\n", 
									video_ready_msg_ptr->address.address_space.index,	
									video_ready_msg_ptr->format,
									video_ready_msg_ptr->size);
	if (!root)
    {
        return 0; 
    }
    
	if (!videoInfo)
    {
        cJSON_Delete(root);
        return 0; 
    }
    
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Device", video_ready_msg_ptr->address.address_space.index);
	cJSON_AddItemToObject(root, "VideoInfo", videoInfo);
	cJSON_AddNumberToObject(videoInfo, "format", video_ready_msg_ptr->format);
	cJSON_AddNumberToObject(videoInfo, "size", video_ready_msg_ptr->size);
    
	char *JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
        //cJSON_Delete(videoInfo);
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
    
    //cJSON_Delete(videoInfo);
	cJSON_Delete(root);
	return size;
}	

int WLTxQuerySensitivityProcess::toJSONString(char* json_str, int json_nb)
{
    //TBD

    return 0;
}

int WLTxSetSensitivityProcess::toJSONString(char* json_str, int json_nb)
{
    cJSON* root = cJSON_CreateObject();
    if (!root){ return 0; }
    cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
    cJSON_AddNumberToObject(root, "Status", 0);
    char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;
}

int WLTxQuerySensorSupervisionProcess::toJSONString(char* json_str, int json_nb)
{
    //TBD

    return 0;
}

int WLTxSetSensorSupervisionProcess::toJSONString(char* json_str, int json_nb)
{
    cJSON* root = cJSON_CreateObject();
    if (!root){ return 0; }
    cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
    cJSON_AddNumberToObject(root, "Status", 0);
    char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;
}

int WLTxStreamingDataEventProcess::toJSONString(char* json_str, int json_nb) 
{ 
	cJSON* root = cJSON_CreateObject();

	if (!root)
    {
        return 0; 
    }
    
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
    cJSON_AddNumberToObject(root, "Device", video_ready_msg_ptr->address.address_space.index);
    cJSON_AddNumberToObject(root, "BlockID", video_ready_msg_ptr->blockID);
    cJSON_AddNumberToObject(root, "Length", video_ready_msg_ptr->length);
    cJSON_AddStringToObject(root, "Data", (const char *)video_ready_msg_ptr->data);
    
	char *JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
        //cJSON_Delete(videoInfo);
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);

	if ( size < json_nb) strncpy(json_str, JsonChar, json_nb);
	else size = 0;
	free(JsonChar);
    
    //cJSON_Delete(videoInfo);
	cJSON_Delete(root);
	return size;
}	



WLJsonStreamProcessor::WLJsonStreamProcessor(WLScom& wlscom):_wlscom(wlscom)
{
    static const U32 ARRAYSIZE = sizeof(createlist)/sizeof(createlist[0]);
    arrayRxProcesses.reserve(ARRAYSIZE -1);
	
    WLRxProcess & (**createlistP)(WLScom& wlscom) = createlist;
    for (;*createlistP != NULL; ++createlistP)
    {
        arrayRxProcesses.push_back( & (**createlistP)(wlscom) );
    }

}

WLJsonStreamProcessor::~WLJsonStreamProcessor()
{
    std::vector<WLRxProcess *>::const_iterator end = arrayRxProcesses.end();

    for(std::vector<WLRxProcess *>::const_iterator i = arrayRxProcesses.begin(); i != end; ++i)
    {
        delete *i;
    }
    arrayRxProcesses.clear();

}

int WLJsonStreamProcessor::processRx(const char * json_msg)
{
	cJSON* root = cJSON_Parse(json_msg);
	if (!root) //parse fails
	{
		EvLog::instance().log_printf(EVL_ERROR, "JSON parsing failed (%s)\n", json_msg);
		return 0;
	}
    EvLog::instance().log_printf(EVL_INFO, "JSON parsing success (%s)\n", json_msg);
    
	uint32 JsonLen = strlen(json_msg);
	
	cJSON* messageType = cJSON_GetObjectItem(root, "Message Type");
	if (!messageType)
	{
		EvLog::instance().log_printf(EVL_ERROR, "JSON cJSON_GetObjectItem failed\n");
		cJSON_Delete(root);
		return JsonLen;
	}

	uint8 msgType = messageType->valueint;
	
	//char* JsonChar = cJSON_Print(root);
	//if (!JsonChar) {
	//	cJSON_Delete(root);
	//	return 0;
	//}
	//uint32 JsonLen = strlen(JsonChar);
	//free(JsonChar);

	//*result_nb = 0; //reset result count
	std::vector<WLRxProcess*>::const_iterator end = arrayRxProcesses.end();

	for (std::vector<WLRxProcess*>::const_iterator j = arrayRxProcesses.begin(); j != end; ++j)
	{
		if ((*j) != NULL)
		{
			if ((*j)->is4Me(msgType))
			{
				(*j)->process(root);
				break;
			}
		}
	}
	cJSON_Delete(root);
	
	return JsonLen;

}

void CPSetZoneConfigProcess::process(cJSON* root)
{
	int parse_failed_falg = 0;
	cJSON* jChannelNumber = cJSON_GetObjectItem(root, "Channel number");
	cJSON* jChannelSamplingTime = cJSON_GetObjectItem(root, "Channel sampling time");
	cJSON* jShortVoltageThreshold = cJSON_GetObjectItem(root, "Short voltage threshold");
	cJSON* jLowVoltageThreshold = cJSON_GetObjectItem(root, "Low voltage threshold");
	cJSON* jNormalVoltageThreshold = cJSON_GetObjectItem(root, "Normal voltage threshold");
	cJSON* jHighVoltageThreshold = cJSON_GetObjectItem(root, "High voltage threshold");
	cJSON* jOpenVoltageThreshold = cJSON_GetObjectItem(root, "Open voltage threshold");

	do{
		if(!jChannelNumber || jChannelNumber -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
		if(!jChannelSamplingTime || jChannelSamplingTime -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
		if(!jShortVoltageThreshold || jShortVoltageThreshold -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
		if(!jLowVoltageThreshold || jLowVoltageThreshold -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
		if(!jNormalVoltageThreshold || jNormalVoltageThreshold -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
		if(!jHighVoltageThreshold || jHighVoltageThreshold -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
		if(!jOpenVoltageThreshold || jOpenVoltageThreshold -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
	}while(0);

	if(parse_failed_falg == 1){
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}


	
	_SET_ZONE_CONFIG msg;
	
	msg.msg_id = E_DBGP_APP_SET_ZONE_CONFIG;
	msg.channel_number = jChannelNumber->valueint;
	msg.channel_sampling_time = jChannelSamplingTime->valueint;
	msg.short_voltage_threshold = jShortVoltageThreshold->valueint;
	msg.low_voltage_threshold = jLowVoltageThreshold->valueint;
	msg.normal_voltage_threshold = jNormalVoltageThreshold->valueint;
	msg.high_voltage_threshold = jHighVoltageThreshold->valueint;
	msg.open_voltage_threshold = jOpenVoltageThreshold->valueint;
	
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}
void CPSetFireConfigProcess::process(cJSON* root)
{
	int parse_failed_falg = 0;
	cJSON* jFireStatus = cJSON_GetObjectItem(root, "Fire status");
	cJSON* jTimeout = cJSON_GetObjectItem(root, "Timeout");

	do{
		if(!jFireStatus || jFireStatus -> type != cJSON_String){
			parse_failed_falg = 1;
			break;
		}
		if(!jTimeout || jTimeout -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
	}while(0);

	if(parse_failed_falg == 1){
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}


	
	_SET_FIRE_CONFIG msg;
	
	msg.msg_id = E_DBGP_APP_SET_FIRE_CONFIG;
	if(strcmp("on", jFireStatus->valuestring) == 0){
		msg.fire_status = FIRE_STATUS_ON;
	}else if(strcmp("off", jFireStatus->valuestring) == 0){
		msg.fire_status = FIRE_STATUS_OFF;
	}else if(strcmp("reset", jFireStatus->valuestring) == 0){
		msg.fire_status = FIRE_STATUS_RESET;
	}else{
		EvLog::instance().log_printf(EVL_ERROR, "Parameter error.\n");
		return;
	}
	msg.timeout = jTimeout->valueint;
	
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}
void CPSetSirenConfigProcess::process(cJSON* root)
{
	int parse_failed_falg = 0;
	cJSON* jChannelNumber = cJSON_GetObjectItem(root, "Channel number");
	cJSON* jMelodyMode = cJSON_GetObjectItem(root, "Melody mode");

	do{
		if(!jChannelNumber || jChannelNumber -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
		if(!jMelodyMode || jMelodyMode -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
	}while(0);

	if(parse_failed_falg == 1){
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}


	
	_SET_SIREN_CONFIG msg;
	
	msg.msg_id = E_DBGP_APP_SET_SIREN_CONFIG;
	msg.channel_number = jChannelNumber->valueint;
	msg.melody_mode = jMelodyMode->valueint;

	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}
void CPSetTriggerConfigProcess::process(cJSON* root)
{
	int parse_failed_falg = 0;
	cJSON* jChannelNumber = cJSON_GetObjectItem(root, "Channel number");
	cJSON* jTriggerMode = cJSON_GetObjectItem(root, "Trigger mode");

	do{
		if(!jChannelNumber || jChannelNumber -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
		if(!jTriggerMode || jTriggerMode -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
	}while(0);

	if(parse_failed_falg == 1){
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}


	
	_SET_TRIGGER_CONFIG msg;
	
	msg.msg_id = E_DBGP_APP_SET_TRIGGER_CONFIG;
	msg.channel_number = jChannelNumber->valueint;
	msg.trigger_mode = jTriggerMode->valueint;
	
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}
void CPSetAuxenConfigProcess::process(cJSON* root)
{
	int parse_failed_falg = 0;
	cJSON* jAUXENStatus = cJSON_GetObjectItem(root, "AUXEN status");

	do{
		if(!jAUXENStatus || jAUXENStatus -> type != cJSON_String){
			parse_failed_falg = 1;
			break;
		}
	}while(0);

	if(parse_failed_falg == 1){
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}


	
	_SET_AUXEN_CONFIG msg;
	
	msg.msg_id = E_DBGP_APP_SET_AUXEN_CONFIG;
	if(strcmp("on", jAUXENStatus->valuestring) == 0){
		msg.auxen_status = AUXEN_STATUS_ON;
	}else if(strcmp("off", jAUXENStatus->valuestring) == 0){
		msg.auxen_status = AUXEN_STATUS_OFF;
	}else{
		EvLog::instance().log_printf(EVL_ERROR, "Parameter error.\n");
		return;
	}
	
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}
void CPSetAcConfigProcess::process(cJSON* root)
{
	int parse_failed_falg = 0;
	cJSON* jACThreshold = cJSON_GetObjectItem(root, "AC threshold");

	do{
		if(!jACThreshold || jACThreshold -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
	}while(0);

	if(parse_failed_falg == 1){
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}


	
	_SET_AC_CONFIG msg;
	
	msg.msg_id = E_DBGP_APP_SET_AC_CONFIG;
	msg.ac_threshold = jACThreshold->valueint;
	
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}

void CPGetBatteryACProcess::process(cJSON* root)
{
	_GET_BATTERY_AC msg;
	
	msg.msg_id = E_DBGP_APP_GET_BATTERY_AC;
	
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}
void CPGetAUXProcess::process(cJSON* root)
{
	_GET_AUX msg;
	
	msg.msg_id = E_DBGP_APP_GET_AUX;
	
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}
void CPGetEX_LTE_WIFIProcess::process(cJSON* root)
{
	_GET_EX_LTE_WIFI_ID msg;
	
	msg.msg_id = E_DBGP_APP_GET_EX_LTE_WIFI_ID;
	
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}
void CPSetIB2DownloadFrameProcess::process(cJSON* root)
{
	int parse_failed_falg = 0;
	cJSON* jChannelNumber = cJSON_GetObjectItem(root, "Channel number");
	cJSON* jIB2Buffer = cJSON_GetObjectItem(root, "IB2 buffer");

	do{
		if(!jIB2Buffer || jIB2Buffer -> type != cJSON_String){
			parse_failed_falg = 1;
			break;
		}
		if(!jChannelNumber || jChannelNumber -> type != cJSON_Number){
			parse_failed_falg = 1;
			break;
		}
	}while(0);

	if(parse_failed_falg == 1){
		//parse error
		EvLog::instance().log_printf(EVL_ERROR, "Parse JSON object failed %s:%d\n", __FILE__, __LINE__);
		return;
	}


	
	_SET_IB2_DOWNLOAD_FRAME msg;
	
	msg.msg_id = E_DBGP_APP_SET_IB2_DOWNLOAD_FRAME;
	msg.channel_number = jChannelNumber->valueint;
	msg.ib2_length = ConvertString2Hex(jIB2Buffer->valuestring, msg.ib2_buffer, sizeof(msg.ib2_buffer));;
		
	_wlscom.put_tx_msg((const u8*)&msg, (sizeof(msg.msg_id)+sizeof(msg.channel_number)+sizeof(msg.ib2_length)+msg.ib2_length));
}
void CPSetIB2RunProcess::process(cJSON* root)
{
	_SET_IB2_RUN msg;
	
	msg.msg_id = E_DBGP_APP_SET_IB2_RUN;
	
	_wlscom.put_tx_msg((const u8*)&msg, sizeof(msg));
}
int CPSetZoneConfigResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();


	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}
	cJSON_AddNumberToObject(root, "Channel number", pData->channel_number);
	cJSON_AddNumberToObject(root, "Channel sampling time", pData->channel_sampling_time);
	switch(pData->channel_status){
		case CHANNEL_STATUS_SHORT:
			cJSON_AddStringToObject(root, "Channel status", "short");
			break;
		case CHANNEL_STATUS_LOW:
			cJSON_AddStringToObject(root, "Channel status", "low");
			break;
		case CHANNEL_STATUS_NORMAL:
			cJSON_AddStringToObject(root, "Channel status", "normal");
			break;
		case CHANNEL_STATUS_HIGH:
			cJSON_AddStringToObject(root, "Channel status", "high");
			break;
		case CHANNEL_STATUS_OPEN:
			cJSON_AddStringToObject(root, "Channel status", "open");
			break;
		default:
			cJSON_AddStringToObject(root, "Channel status", "");
			break;
	}
	cJSON_AddNumberToObject(root, "Channel voltage", pData->channel_voltage);
	cJSON_AddNumberToObject(root, "Short voltage threshold", pData->short_voltage_threshold);
	cJSON_AddNumberToObject(root, "Low voltage threshold", pData->low_voltage_threshold);
	cJSON_AddNumberToObject(root, "Normal voltage threshold", pData->normal_voltage_threshold);
	cJSON_AddNumberToObject(root, "High voltage threshold", pData->high_voltage_threshold);
	cJSON_AddNumberToObject(root, "Open voltage threshold", pData->open_voltage_threshold);

	
	
	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPSetFireConfigResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}
	switch(pData->fire_status){
		case FIRE_STATUS_ON:
			cJSON_AddStringToObject(root, "Fire status", "on");
			break;
		case FIRE_STATUS_OFF:
			cJSON_AddStringToObject(root, "Fire status", "off");
			break;
		case FIRE_STATUS_RESET:
			cJSON_AddStringToObject(root, "Fire status", "reset");
			break;
		default:
			cJSON_AddStringToObject(root, "Fire status", "");
			break;
	}
	cJSON_AddNumberToObject(root, "Timeout", pData->timeout);



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPSetSirenConfigResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}
	cJSON_AddNumberToObject(root, "Channel number", pData->channel_number);
	cJSON_AddNumberToObject(root, "Siren voltage", pData->siren_voltage);
	cJSON_AddNumberToObject(root, "Melody mode", pData->melody_mode);



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPSetTriggerConfigResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}
	cJSON_AddNumberToObject(root, "Channel number", pData->channel_number);
	cJSON_AddNumberToObject(root, "Trigger mode", pData->trigger_mode);



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPSetAuxenConfigResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}
	if(pData->auxen_status == AUXEN_STATUS_ON){
		cJSON_AddStringToObject(root, "AUXEN status", "on");
	}else if(pData->auxen_status == AUXEN_STATUS_OFF){
		cJSON_AddStringToObject(root, "AUXEN status", "off");
	}else{
		cJSON_AddStringToObject(root, "AUXEN status", "");
	}



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPSetAcConfigResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}
	cJSON_AddNumberToObject(root, "Battery voltage", pData->battery_voltage);
	cJSON_AddNumberToObject(root, "AC voltage", pData->ac_voltage);
	if(pData->ac_status == AC_STATUS_LOSE){
		cJSON_AddStringToObject(root, "AC status", "lose");
	}else if(pData->ac_status == AC_STATUS_ONLINE){
		cJSON_AddStringToObject(root, "AC status", "online");
	}else{
		cJSON_AddStringToObject(root, "AC status", "");
	}
	cJSON_AddNumberToObject(root, "AC threshold", pData->ac_threshold);



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPGetBatteryACResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}
	cJSON_AddNumberToObject(root, "Battery voltage", pData->battery_voltage);
	cJSON_AddNumberToObject(root, "AC voltage", pData->ac_voltage);
	if(pData->ac_status == AC_STATUS_LOSE){
		cJSON_AddStringToObject(root, "AC status", "lose");
	}else if(pData->ac_status == AC_STATUS_ONLINE){
		cJSON_AddStringToObject(root, "AC status", "online");
	}else{
		cJSON_AddStringToObject(root, "AC status", "");
	}
	cJSON_AddNumberToObject(root, "AC threshold", pData->ac_threshold);



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPGetAUXResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}
	cJSON_AddNumberToObject(root, "AUX voltage", pData->aux_voltage);
	cJSON_AddNumberToObject(root, "AUX current", pData->aux_current);



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPGetEX_LTE_WIFIResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}
	cJSON_AddNumberToObject(root, "EX ID voltage", pData->ex_id_voltage);
	cJSON_AddNumberToObject(root, "LTE ID voltage", pData->lte_id_voltage);
	cJSON_AddNumberToObject(root, "WIFI ID voltage", pData->wifi_id_voltage);



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPSetIB2DownloadFrameResponseProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPEvtIB2UploadFrameProcess::toJSONString(char* json_str, int json_nb)
{
	char strTemp[IB2_MAX_BUFFER*2+1];
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Channel number", pData->channel_number);
	ConvertHex2String((u8 *)&pData->ib2_buffer[0], pData->ib2_length, (u8 *)&strTemp[0], sizeof(strTemp));
	cJSON_AddStringToObject(root, "IB2 buffer", strTemp);



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPEvtReportAllProcess::toJSONString(char* json_str, int json_nb)
{
	char strTemp[IB2_MAX_BUFFER*2+1];
	cJSON* root = cJSON_CreateObject();
	cJSON* array = cJSON_CreateArray();
	cJSON* voltage;
	int i;


	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	for(i = 0; i < 8; i++){
		voltage = cJSON_CreateNumber(pData->zone_voltage[i]);
		cJSON_AddItemToArray(array, voltage);
	}
	cJSON_AddItemToObject(root, "Zone voltage", array);
	cJSON_AddNumberToObject(root, "Battery voltage", pData->battery_voltage);
	cJSON_AddNumberToObject(root, "AC voltage", pData->ac_voltage);
	cJSON_AddNumberToObject(root, "AUX voltage", pData->aux_voltage);
	cJSON_AddNumberToObject(root, "AUX current", pData->aux_current);
	cJSON_AddNumberToObject(root, "Siren voltage", pData->siren_voltage);
	cJSON_AddNumberToObject(root, "EX ID voltage", pData->ex_id_voltage);
	cJSON_AddNumberToObject(root, "LTE ID voltage", pData->lte_id_voltage);
	cJSON_AddNumberToObject(root, "WIFI ID voltage", pData->wifi_id_voltage);
	ConvertHex2String((u8 *)&pData->ib2_buffer[0], pData->ib2_length, (u8 *)&strTemp[0], sizeof(strTemp));
	cJSON_AddStringToObject(root, "IB2 frame", strTemp);



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPEvtReportZoneStatusProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();


	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Channel number", pData->channel_number);
	cJSON_AddNumberToObject(root, "Channel sampling time", pData->channel_sampling_time);
	switch(pData->channel_status){
		case CHANNEL_STATUS_SHORT:
			cJSON_AddStringToObject(root, "Channel status", "short");
			break;
		case CHANNEL_STATUS_LOW:
			cJSON_AddStringToObject(root, "Channel status", "low");
			break;
		case CHANNEL_STATUS_NORMAL:
			cJSON_AddStringToObject(root, "Channel status", "normal");
			break;
		case CHANNEL_STATUS_HIGH:
			cJSON_AddStringToObject(root, "Channel status", "high");
			break;
		case CHANNEL_STATUS_OPEN:
			cJSON_AddStringToObject(root, "Channel status", "open");
			break;
		default:
			cJSON_AddStringToObject(root, "Channel status", "");
			break;
	}
	cJSON_AddNumberToObject(root, "Channel voltage", pData->channel_voltage);
	cJSON_AddNumberToObject(root, "Short voltage threshold", pData->short_voltage_threshold);
	cJSON_AddNumberToObject(root, "Low voltage threshold", pData->low_voltage_threshold);
	cJSON_AddNumberToObject(root, "Normal voltage threshold", pData->normal_voltage_threshold);
	cJSON_AddNumberToObject(root, "High voltage threshold", pData->high_voltage_threshold);
	cJSON_AddNumberToObject(root, "Open voltage threshold", pData->open_voltage_threshold);

	
	
	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPEvtReportBellStatusProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();


	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Channel number", pData->channel_number);
	switch(pData->bell_status){
		case BELL_STATUS_SHORT:
			cJSON_AddStringToObject(root, "Bell status", "short");
			break;
		case BELL_STATUS_NORMAL:
			cJSON_AddStringToObject(root, "Bell status", "normal");
			break;
		case BELL_STATUS_OPEN:
			cJSON_AddStringToObject(root, "Bell status", "open");
			break;
		default:
			cJSON_AddStringToObject(root, "Bell status", "");
			break;
	}

	
	
	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPEvtReportACStatusProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	cJSON_AddNumberToObject(root, "Battery voltage", pData->battery_voltage);
	cJSON_AddNumberToObject(root, "AC voltage", pData->ac_voltage);
	if(pData->ac_status == AC_STATUS_LOSE){
		cJSON_AddStringToObject(root, "AC status", "lose");
	}else if(pData->ac_status == AC_STATUS_ONLINE){
		cJSON_AddStringToObject(root, "AC status", "online");
	}else{
		cJSON_AddStringToObject(root, "AC status", "");
	}
	cJSON_AddNumberToObject(root, "AC threshold", pData->ac_threshold);



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}
int CPEvtIB2RunProcess::toJSONString(char* json_str, int json_nb)
{
	cJSON* root = cJSON_CreateObject();



	
	cJSON_AddNumberToObject(root, "Message Type", MESSAGE_TYPE);
	if(pData->result_code == RESULT_CODE_FAIL){
		cJSON_AddStringToObject(root, "Result code", "fail");
	}else if(pData->result_code == RESULT_CODE_SUCCESS){
		cJSON_AddStringToObject(root, "Result code", "success");
	}else{
		cJSON_AddStringToObject(root, "Result code", "");
	}



	
	char* JsonChar = cJSON_Print(root);
	if (!JsonChar)
	{
		cJSON_Delete(root);
		return 0;
	}
	int size = strlen(JsonChar);
	
	if ( size < json_nb) 
		strncpy(json_str, JsonChar, json_nb);
	else 
		size = 0;
	free(JsonChar);
	cJSON_Delete(root);
	return size;	

}

int WLJsonStreamProcessor::processTx(const u8* buffer, int buff_nb, char* json_buffer, int json_buffer_nb)
{
    WLTxProcess* processor = NULL;
    int len = 0;
	
	_DEVICE_INFO_STATUS * ptr;
	ptr = (_DEVICE_INFO_STATUS * )buffer;

	_EVENT_DEFNITION * evt_ptr;
	evt_ptr = (_EVENT_DEFNITION *)buffer;

	_RESP_1_ELEMENT * resp_1_element;
	resp_1_element = (_RESP_1_ELEMENT *)buffer;

	_RESP_REQUEST_STREAMING * rsp_request_stream_ptr;
	rsp_request_stream_ptr = (_RESP_REQUEST_STREAMING *)buffer;
    
    u16 command = 0x0000;
    command = buffer[1];
    command <<= 8;
	command += buffer[0];
	
    assert(buff_nb >= 2);
    
    switch(command)
    {
    case E_DBGP_APP_RSP_BOARD_VERSION:
        processor = new WLTxVersionResponseProcess(buffer, buff_nb);
        break;
    case E_DBGP_APP_RSP_SITE_ADDRESS:
        processor = new WLTxQuerySiteIDResponseProcess(buffer, buff_nb);
        break;
    case E_DBGP_APP_EVT_AP_MONITOR:
        processor = new WLTxMonitorSupervProcess(buffer, buff_nb);
        break;
		
    case E_DBGP_APP_RSP_DEVICE_STATUS:
        processor = new WLTxStatusUpdateEventProcess(buffer, buff_nb);
        break;
		
    case E_DBGP_APP_EVT_DEVICE_UPDATE_INFO:
		if(ptr->device.result_type == ENROLLING_RESULT){
			
			processor = new WLTxEnrollResponseProcess(buffer, buff_nb);
			
		}else if(ptr->device.result_type == DELETE_RESULT){
		
			processor = new WLTxRemovedResponseProcess(buffer, buff_nb);
			
		}else if(ptr->device.result_type == ARM_RESULT){
		
			processor = new WLTxArmedResponseProcess(buffer, buff_nb);

		}else if(ptr->device.result_type == DISARM_RESULT){
		
			processor = new WLTxDisarmedResponseProcess(buffer, buff_nb);
			
		}else{
			
		}
        break;
		
    case E_DBGP_APP_EVT_DEVICE_UPDATE_1STATUS:
		
		if(evt_ptr->index == INDEX_KEYFOB){
			            
        	processor = new WLTxKeyPressedEventProcess(buffer, buff_nb);
			
        }else if(evt_ptr->index == INDEX_RANGE_TEST_RESULT){
                    
        	processor = new WLTxRangeTestResponseProcess(buffer, buff_nb);
			
        }else if (evt_ptr->index == INDEX_VIDEO_READY){
                    
        	processor = new WLTxVideoReadyEventProcess(buffer, buff_nb);
			
        }else if (evt_ptr->index == INDEX_VIDEO_TRANSFER_RESULT){
                    
        	processor = new WLTxVideoStateEventProcess(buffer, buff_nb);
			
        }else if (evt_ptr->index == INDEX_VIDEO_RECEIVE_DATA){
                    
        	processor = new WLTxVideoDataEventProcess(buffer, buff_nb);

        }else{

		}
		break;

    case E_DBGP_APP_EVT_DEVICE_1ELEMENT :
		
		if(resp_1_element->index == INDEX_PIR_SENSITIVITY){
			
			if(CheckNumber(&sen))
        		processor = new WLTxSetSensitivityProcess(buffer, buff_nb);
			
		}else if(resp_1_element->index == INDEX_DEVICE_SUPERVISION_INTERVAL){
			
			if(CheckNumber(&sup))
        		processor = new WLTxSetSensorSupervisionProcess(buffer, buff_nb);
			
		}else{

		}
        break;

	case RES_ID_PIR_QUERY_SENSITIVITY:
        processor = new WLTxQuerySensitivityProcess(buffer, buff_nb);
		break;
    case RES_ID_QUERY_SUPERVISION:
        processor = new WLTxQuerySensorSupervisionProcess(buffer, buff_nb);
        break;
		
    case E_DBGP_APP_EVT_UPLOAD_DEVICE_INFO:
        processor = new WLTxQueryDevicesInfoResponseProcess(buffer, buff_nb);
        break;

	case E_DBGP_APP_EVT_DEVICE_STREAMING_REQ:
		if(rsp_request_stream_ptr->start_stop == START){
			
			processor = new WLTxVSStartResponse(buffer, buff_nb);
		}else if(rsp_request_stream_ptr->start_stop == STOP){
		
			//processor = new WLTxStreamingStopProcess(buffer, buff_nb);
			processor = new WLTxVSStopResponse(buffer, buff_nb);
		}else{
			
		}
		break;
	case E_DBGP_APP_STREAMING_UP_DATA:
		//printf("Event occurs: INDEX_STREAMING_RECEIVE_DATA");
		processor = new WLTxVSStreamData(buffer, buff_nb);
		break;

    case E_DBGP_APP_EVT_ZONE_CONFIG:
		processor = new CPSetZoneConfigResponseProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_FIRE_CONFIG:
		processor = new CPSetFireConfigResponseProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_SIREN_CONFIG:
		processor = new CPSetSirenConfigResponseProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_TRIGGER_CONFIG:
		processor = new CPSetTriggerConfigResponseProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_AUXEN_CONFIG:
		processor = new CPSetAuxenConfigResponseProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_AC_CONFIG:
		processor = new CPSetAcConfigResponseProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_RSP_BATTERY_AC:
		processor = new CPGetBatteryACResponseProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_RSP_AUX:
		processor = new CPGetAUXResponseProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_RSP_EX_LTE_WIFI_ID:
		processor = new CPGetEX_LTE_WIFIResponseProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_IB2_DOWNLOAD_FRAME:
		processor = new CPSetIB2DownloadFrameResponseProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_IB2_UPLOAD_FRAME:
		processor = new CPEvtIB2UploadFrameProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_REPORT_ALL:
		processor = new CPEvtReportAllProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_REPORT_ZONE_STATUS:
		processor = new CPEvtReportZoneStatusProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_REPORT_BELL_STATUS:
		processor = new CPEvtReportBellStatusProcess(buffer, buff_nb);
		break;
    case E_DBGP_APP_EVT_REPORT_AC_STATUS:
		processor = new CPEvtReportACStatusProcess(buffer, buff_nb);
		break;
	case E_DBGP_APP_EVT_IB2_RUN:
		processor = new CPEvtIB2RunProcess(buffer, buff_nb);
		break;
		
    default:
        EvLog::instance().log_printf(EVL_INFO, "Get Message from MCU msgid = 0x%02X%02X\n", buffer[1],buffer[0]);
        break;
    }
    
    if (processor) len = processor->toJSONString( json_buffer, json_buffer_nb);
    
    delete processor;
    
    return len;
}


