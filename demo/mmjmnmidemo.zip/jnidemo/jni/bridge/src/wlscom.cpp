#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "wlscom.h"
#include "evlog.h"
#include "queues.h"
#include "WlMessageProcess.h"
#include "commclient.h"
#include <sys/types.h>
#include <sys/socket.h>

#include <cutils/sockets.h>
#include <netinet/tcp.h>
#include <nativehelper/ScopedUtfChars.h>


#define DEF_CONN_TIMEOUT 	(1*60) //1 min
#define DEF_RETRY_INTERVAL 	3 /* in second */
#define MAX_RETRY_INTERVAL	(3*60) //3 mins
#define DEF_IP_ADDR 		"127.0.0.1"
#define WISELINK_PORT		4002
#define IB2_PORT			5555

WLScom::WLScom(DQueues& dqueues):
_dqueues(dqueues)//,
//_myWLJsonProcessor(*this)
{
	EvLog::instance().log_printf(EVL_INFO, "zlmsg = wlscom.cpp:init");
	printf("zlmsg = wlscom.cpp:init");
	_myWLJsonProcessor = new WLJsonStreamProcessor(*this);
	strncpy(strIPAddr, DEF_IP_ADDR, sizeof(strIPAddr));
	if(get_programmer_mode() == For_Wiselink_Ap){
		nPort = WISELINK_PORT;
	}else{
		nPort = IB2_PORT;
	}
	
	Json_total_send_nb = 0;
	Json_sent_nb = 0;

	Json_parsing_nb = 0;

	scom_started = 0;
}

WLScom::~WLScom()
{

}

int WLScom::start(const char* ip_addr, unsigned short port)
{
	if (scom_started) return scom_started;

	if (ip_addr && strlen(ip_addr)) strncpy(strIPAddr, ip_addr, sizeof(strIPAddr)-1);
	if (port) nPort = port;
	scom_started = true;
	scom_entry_loop();
	
	return 0; //should never enter here, just avoid compiler warning
}
	
int WLScom::start()
{
		EvLog::instance().log_printf(EVL_CRITICAL, "zlmsg = start");
		printf("zlmsg = wlscom.cpp:start printf");
		scom_started = true;

	return 110;
}

char* WLScom::processJson(const char* json){
	cJSON* root = cJSON_Parse(json);
	if(root){
		return "successful";
	}
	return "fail";
}

int WLScom::receiverMessage(const char* message)
{		
		 _myWLJsonProcessor->processRx(message);
	return 0;
}

bool WLScom::do_connect(int sock, int timeout)
{
	fd_set wfds;
	struct timeval tv;
	int rc;

	struct sockaddr_in svr_addr;
	memset(&svr_addr, 0, sizeof(svr_addr));
	svr_addr.sin_family = AF_INET;
	svr_addr.sin_addr.s_addr = inet_addr(strIPAddr);
	svr_addr.sin_port = htons(nPort);

	FD_ZERO(&wfds);
	FD_SET(sock, &wfds);
	tv.tv_sec = timeout;
	tv.tv_usec = 0;

	if (connect(sock, (struct sockaddr*)&svr_addr, sizeof(svr_addr)) == -1 && errno != EINPROGRESS)
	{
		//connect fail
		EvLog::instance().log_printf(EVL_INFO, "socket connect failed (%d:%s)\n", errno, strerror(errno));
		return false;
	}

	//wait connected or error/timeout occur
	do {
		rc = select(sock+1, NULL, &wfds, NULL, &tv);
		if (rc == 1) //connection finished
		{
			int so_err = 0;
			unsigned int err_len = sizeof(so_err);
			//getsockopt(sock, SOL_SOCKET, SO_ERROR, &so_err, &err_len);
			if (so_err == 0)
				return true;
			else
				return false;
		} else if (rc == 0) //connection timeout
		{
			return false;
		}
		else {
			//interrupted by some signals, maybe
			//continue to wait
		}
	}while(1);

}
int WLScom::discard_bad_data(char * ptr) {
  char* check_ptr;
  char* check_p1;
  char* check_p2;
  int check_nb = 0;
  cJSON* root;

  check_ptr = ptr;

  while (1) {
    root = cJSON_Parse(check_ptr);
    if (root != NULL) {
      cJSON_Delete(root);
      return check_nb;
    }

    check_p1 = check_ptr;
    ++check_ptr;
    check_p2 = strchr(check_ptr, '{');
    if (check_p2 != NULL) {
      check_ptr = check_p2;
      check_nb += (check_p2 - check_p1);
    } else {
      return 0;
    }
  }
}

int WLScom::parse_recv_msg(const char * msg_ptr, int msg_nb) {
  char* ptr = Json_parsing_str;
  int nb = 0;
  int len;
  int discard_len = 0;

  if (Json_parsing_nb + msg_nb > JSON_PARSE_BUFF_LENTH) {
    memcpy(Json_parsing_str, msg_ptr, msg_nb);
    Json_parsing_nb = msg_nb;
  } else {
    memcpy(Json_parsing_str + Json_parsing_nb, msg_ptr, msg_nb);
    Json_parsing_nb += msg_nb;
  }
  Json_parsing_str[Json_parsing_nb] = '\0';

  do {
    discard_len = discard_bad_data(ptr);
    if (discard_len > 0) {
      ptr += discard_len;
      nb += discard_len;
    }

    len = _myWLJsonProcessor->processRx(ptr);

    if (len == 0) {
      break;
    }

    ptr += len;
    nb += len;
  } while (nb < Json_parsing_nb);

  if ((nb < Json_parsing_nb) && (nb > 0)) {
    memcpy(Json_parsing_str, ptr, (Json_parsing_nb - nb) + 1);   //+1 means '\0'
  }

  Json_parsing_nb = (nb > Json_parsing_nb) ? 0 : (Json_parsing_nb - nb);

  return nb;
}

int WLScom::put_tx_msg(const u8* buffer, int buff_nb)
{
#if 0 //
	printf("WLScom::put_tx_msg len = %d\n", buff_nb);
	for (int i = 0; i < buff_nb; i++)
	{
		printf("%02X ", buffer[i]);
	}
	printf("\n");
#endif
	return _dqueues.put_tx_msg((const u8 *)buffer, buff_nb);
}


void WLScom::prepare_sending_msg()
{
	WLTxProcess* txProcessor; 
	char buffer[2048];
	int len = _dqueues.get_rx_msg((u8 *)buffer, sizeof(buffer));

	Json_sent_nb = 0;
	
	Json_total_send_nb = _myWLJsonProcessor->processTx((u8 *)buffer, len, Json_sending_str, sizeof(Json_sending_str));

}
void WLScom::recv_and_send_loop(int sock)
{
	bool connected = true;
	//int sent_nb = 0;
	//int total_nb = 0;
	//char* data_ptr = NULL;
	char recvBuff[1024*4+1];

	while (connected)
	{
		fd_set rfds, wfds;
		int max_fd;
		int rc;

		int rx_queue_fd = _dqueues.rx_queue_fd(); 
		max_fd = sock > rx_queue_fd? sock:rx_queue_fd;
		FD_ZERO(&rfds);
		FD_ZERO(&wfds);

		FD_SET(sock, &rfds);

		if (Json_sent_nb < Json_total_send_nb)
        {
			FD_SET(sock, &wfds);
        }      
		else if (WLVideoClipBuffer::instance()->IsClipPackageReady())
        {
            EvLog::instance().log_printf(EVL_ERROR, "Clip ready\n");
            FD_SET(rx_queue_fd, &wfds);
        }      
        else    
        {      
			FD_SET(rx_queue_fd, &rfds);
        }

		rc = select(max_fd + 1, &rfds, &wfds, NULL, NULL);
		if (rc > 0)
		{
			if (FD_ISSET(sock, &rfds))
			{
				//data arrived or error
				int r = recv(sock, recvBuff, sizeof(recvBuff)-1, 0);
				if (r == 0)
				{
					EvLog::instance().log_printf(EVL_ERROR, "Server closed connection\n");
					connected = false;
					break;
				} else if (r > 0)
				{
					recvBuff[r] = 0; //add terminal
					EvLog::instance().log_printf(EVL_INFO, "Socket recvd data len = %d\n", r);
					parse_recv_msg(recvBuff, r);
				}
			} else if (FD_ISSET(sock, &wfds))
			{
				//writable
				if (Json_sent_nb < Json_total_send_nb)
				{
					int r = send(sock, Json_sending_str + Json_sent_nb, Json_total_send_nb - Json_sent_nb, 0);
					if (r >= 0) 
					{
						EvLog::instance().log_printf(EVL_INFO, "Socket sent out data len = %d\n", r);
						Json_sent_nb += r;
					}
					else if (r != EAGAIN && r != EWOULDBLOCK)
					{
						//error
						EvLog::instance().log_printf(EVL_ERROR, "Send data error(%d:%s)\n", errno, strerror(errno));
						connected = false;
						break;
					}
				}
			} 
            else if (FD_ISSET(rx_queue_fd, &wfds))
            {
            
                Json_sent_nb = 0;
                Json_total_send_nb = WLVideoClipBuffer::instance()->toJSONString(Json_sending_str, sizeof(Json_sending_str));
                
                EvLog::instance().log_printf(EVL_ERROR, "Clip ready process\n");
                
            }
            else if (FD_ISSET(rx_queue_fd, &rfds))
			{
				prepare_sending_msg();
			}
		}

	} //end while

}
void WLScom::scom_entry_loop()
{
	unsigned int retry_conn_interval = DEF_RETRY_INTERVAL;
	bool loop = true;

	while ( loop )
	{
		int rc;
		bool network_ok = false;
		int sock = socket(AF_INET, SOCK_STREAM, 0);
		if (sock == -1)
		{
			EvLog::instance().log_printf(EVL_CRITICAL, "Create socket error(%d:%s)\n", errno, strerror(errno));
			break; //unrecoverable error
		}

		//set socket nonblocking mode
		rc = fcntl(sock, F_SETFL, fcntl(sock, F_GETFL, 0)|O_NONBLOCK);
		if (rc == -1)
		{
			EvLog::instance().log_printf(EVL_CRITICAL, "Set socket nonblock mode error(%d:%s)\n", errno, strerror(errno));
			close(sock);
			break; //unrecoverable error
		}


		EvLog::instance().log_printf(EVL_INFO, "Trying to connect server(ip=%s,port=%d)\n", strIPAddr, nPort);


		if (do_connect(sock, DEF_CONN_TIMEOUT) == false)
		{
			/* connect fail */
			retry_conn_interval = retry_conn_interval*2;
			if (retry_conn_interval > MAX_RETRY_INTERVAL) retry_conn_interval = MAX_RETRY_INTERVAL;
			
		} else {
			//connection established
			network_ok = true;
			retry_conn_interval = DEF_RETRY_INTERVAL; // retry interval reset;
			EvLog::instance().log_printf(EVL_INFO, "Connected server successfully\n");
		}

		/* data recv & send  loop */
		//while (network_ok)
		//{
		//	network_ok = recv_and_send(sock);
		//}
		if (network_ok) recv_and_send_loop(sock);

		close(sock); //close socket, will next reconnect
		EvLog::instance().log_printf(EVL_ERROR, "Connection closed, and will reconnect after %d seconds\n", retry_conn_interval);
		sleep( retry_conn_interval); //try to wait some time before reconnecting.
		
	}
	
}


