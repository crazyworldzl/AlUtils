/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <utils/Log.h>
#include <nativehelper/jni.h>
#include <nativehelper/JNIHelp.h>
#include <android_runtime/AndroidRuntime.h>

using namespace android;

static jint
init_jni(JNIEnv *env, jobject thiz)
{
    ALOGV("init_jni   zlmsg = ");
    return 0;
}

static jstring
postJSON_jni(JNIEnv *env, jobject thiz, jstring json) {
    ALOGV("postJSONJNI   zlmsg = ");
    jstring jstr = env->NewStringUTF("hello");
    return jstr;
}

// Dalvik VM type signatures
static JNINativeMethod gMethods[] = {
    { "init", "()I", (void*)init_jni },
    { "postJSON", "(Ljava/lang/String;)Ljava/lang/String;", (void*)postJSON_jni },
};

static const char* const kClassPathName = "com/huaqin/wlscom/WLScom";

jint JNI_OnLoad(JavaVM* vm, void* /* reserved */)
{
    JNIEnv* env = NULL;
    jint result = -1;
    jclass clazz;

    if (vm->GetEnv((void**) &env, JNI_VERSION_1_4) != JNI_OK) {
        ALOGE("ERROR: GetEnv failed\n");
        return result;
    }
    assert(env != NULL);

    if (AndroidRuntime::registerNativeMethods(env, kClassPathName, gMethods, NELEM(gMethods)) < 0)
        return result;
    return JNI_VERSION_1_4;
}
