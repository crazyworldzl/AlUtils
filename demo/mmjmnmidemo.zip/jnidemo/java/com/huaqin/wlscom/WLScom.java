package com.huaqin.wlscom;


import android.os.RemoteException;

import com.huaqin.dbgp.aidl.IDBGPListener;

public class WLScom extends IDBGPListener.Stub {
  static { System.loadLibrary("wlscom_jni"); }




  
  public native int init();
  
  public native String postJSON(String json);
  


    @Override
    public void listener() throws RemoteException {

    }
}