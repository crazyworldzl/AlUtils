package com.huaqin.dbgp.server;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.RemoteException;

import com.huaqin.dbgp.aidl.DBGPAIDL;
import com.huaqin.wlscom.WLScom;
import android.util.Log;

/**
 * create by zhanglong
 * DATE:5/23/19  11:36 AM
 * DESCRIBE:
 */
public class DBGPServer extends Service {

  private MAIDL maidl;
  private WLScom wlScom;
  @Override
  public IBinder onBind(Intent intent) {
    maidl = new MAIDL();
    Log.i("DBGPServer", "zlmsg = onBind");
    return (IBinder)maidl;
  }

  @Override
  public void onCreate() {
    super.onCreate();
    wlScom = new WLScom();

    }
  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    Log.i("DBGPServer", "zlmsg = onStartCommand");
    return START_STICKY;
  }

  public class MAIDL extends DBGPAIDL.Stub{
      @Override
      public void postJSON(int type, String json) throws RemoteException {
          Log.i("DBGPServer", "zlmsg = type=" + type + "   json=" + json);
          String back = wlScom.postJSON(json);
          Log.i("DBGPServer", "zlmsg = back=" + back);
      }
  }
 
}
